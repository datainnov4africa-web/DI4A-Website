#!/usr/bin/env bash
# ---------------------------------------------------------------------------
#  Prépare l'environnement Python du projet sous Linux et macOS.
#
#  C'est le pendant de preparer.ps1 : il choisit l'interpréteur lui-même,
#  écarte conda, repart d'un .venv vide si celui qui existe a été créé par un
#  autre Python, installe les dépendances et JupyterLab, puis vérifie que tout
#  s'importe. Il ne dépend d'aucun environnement actif.
#
#  Usage, depuis le dossier du projet :
#      bash preparer.sh
#      bash preparer.sh --recreer                 # efface .venv et recommence
#      bash preparer.sh --python /usr/bin/python3.12
# ---------------------------------------------------------------------------
set -euo pipefail

RACINE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="$RACINE/.venv"
EXE="$VENV/bin/python"
MINIMALE_MAJ=3
MINIMALE_MIN=10

PYTHON=""
RECREER=0
while [ $# -gt 0 ]; do
    case "$1" in
        --python)  PYTHON="${2:-}"; shift 2 ;;
        --recreer) RECREER=1; shift ;;
        -h|--help) sed -n '2,14p' "$0"; exit 0 ;;
        *) echo "option inconnue : $1" >&2; exit 2 ;;
    esac
done

version_ok() {
    "$1" -c "import sys; sys.exit(0 if sys.version_info >= ($MINIMALE_MAJ, $MINIMALE_MIN) else 1)" 2>/dev/null
}

trouver_python() {
    local candidats=()
    [ -n "$PYTHON" ] && candidats+=("$PYTHON")
    candidats+=(python3.13 python3.12 python3.11 python3.10 python3 python)
    local c chemin
    for c in "${candidats[@]}"; do
        chemin="$(command -v "$c" 2>/dev/null || true)"
        [ -n "$chemin" ] || continue
        # On écarte conda : son Python fonctionne, mais il entraîne le défaut
        # d'environnement actif que ce script existe pour éviter.
        case "$chemin" in *anaconda*|*miniconda*|*/envs/*) continue ;; esac
        if version_ok "$chemin"; then echo "$chemin"; return 0; fi
    done
    return 1
}

echo "=== Préparation de l'environnement ==="
echo "Projet : $RACINE"

if [ -n "${CONDA_DEFAULT_ENV:-}" ]; then
    echo
    echo "Environnement conda actif : $CONDA_DEFAULT_ENV"
    echo "Il est ignoré : ce script choisit son interprète lui-même."
fi

if ! CHOISI="$(trouver_python)"; then
    echo
    echo "Aucun Python $MINIMALE_MAJ.$MINIMALE_MIN+ hors conda n'a été trouvé." >&2
    echo "Installez-en un (python.org, apt, brew), ou indiquez-le :" >&2
    echo "    bash preparer.sh --python /chemin/vers/python3" >&2
    exit 1
fi
VERSION="$("$CHOISI" -c 'import sys; print(sys.version.split()[0])')"
echo
echo "Interprète : $CHOISI  (Python $VERSION)"

if [ -d "$VENV" ]; then
    MAISON=""
    [ -f "$VENV/pyvenv.cfg" ] && MAISON="$(sed -n 's/^home = //p' "$VENV/pyvenv.cfg")"
    DOSSIER_CHOISI="$(dirname "$("$CHOISI" -c 'import sys; print(sys.executable)')")"
    if [ "$RECREER" = 1 ] || { [ -n "$MAISON" ] && [ "$MAISON" != "$DOSSIER_CHOISI" ]; }; then
        if [ "$RECREER" != 1 ]; then
            echo
            echo "Le .venv existant pointe vers un autre interprète :"
            echo "    $MAISON"
            echo "Un venv ne se réécrit pas en place : on le supprime et on recommence."
        fi
        rm -rf "$VENV"
    else
        echo "Environnement déjà présent et cohérent."
    fi
fi

if [ ! -d "$VENV" ]; then
    echo
    echo "Création de .venv ..."
    "$CHOISI" -m venv "$VENV"
fi

"$EXE" -c "import ssl, sys; print('venv  : Python', sys.version.split()[0], '|', ssl.OPENSSL_VERSION)"

echo
echo "Installation des paquets (quelques minutes la première fois) ..."
"$EXE" -m pip install --quiet --upgrade pip
"$EXE" -m pip install --quiet -r "$RACINE/requirements.txt"
"$EXE" -m pip install --quiet pytest openpyxl jupyterlab

echo
echo "Vérification ..."
"$EXE" -c "import pandas, duckdb, plotly, pyarrow, pydantic; print('  paquets : ok')"
if [ -f "$RACINE/src/pipeline.py" ]; then
    (cd "$RACINE" && "$EXE" -B -c "import src.pipeline, src.index; print('  code    : ok')")
fi
JUP="$("$VENV/bin/jupyter" --version 2>/dev/null | grep -E '^jupyterlab\s*:' || true)"
case "$JUP" in
    ""|*"not installed"*)
        echo ">>> JupyterLab n'est pas installé dans .venv." >&2; exit 1 ;;
esac
echo "  $JUP"

N="$("$EXE" -m pip list --format=freeze | wc -l | tr -d ' ')"
echo
echo "=== Prêt : $N paquets ==="
echo
echo "Lancez JupyterLab depuis ce dossier :"
echo "    .venv/bin/jupyter lab"
echo
echo "Pour vérifier davantage (dépôt complet seulement) :"
echo "    .venv/bin/python -m pytest -q"
echo "    .venv/bin/python scripts/verifier_notebooks.py"
