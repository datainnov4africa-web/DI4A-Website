"""Couche HTTP « polie » : robots.txt, rythme des requêtes, reprises, cache disque.

Toutes les requêtes du projet passent par `Fetcher.get()`. Cette fonction :
  1. vérifie que l'URL est autorisée par le robots.txt du site (règles Google : jokers `*`,
     ancre `$`, la règle la plus longue l'emporte, égalité = autorisation) ;
  2. espace les requêtes vers un même hôte (délai + aléa, ou `Crawl-delay` s'il est plus long) ;
  3. réessaie avec un délai exponentiel sur les erreurs 429/5xx et les coupures réseau, en
     respectant l'en-tête `Retry-After` ;
  4. met les réponses en cache sur disque pour ne jamais retélécharger une page inutilement.

Le transport est injectable : en mode test, `fixture.FixtureTransport` simule un site Jumia
complet sans réseau, ce qui permet d'exécuter tout le notebook hors ligne.
"""
from __future__ import annotations

import hashlib
import json
import logging
import random
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional, Protocol
from urllib.parse import urljoin, urlsplit

log = logging.getLogger("jumia_cpi.fetch")

RETRY_STATUSES = {429, 500, 502, 503, 504}


class RobotsDisallowed(Exception):
    """L'URL est interdite par robots.txt : on ne la télécharge pas."""


class FetchError(Exception):
    pass


@dataclass
class Response:
    url: str
    status: int
    text: str = ""
    headers: dict = field(default_factory=dict)
    elapsed: float = 0.0
    history: list = field(default_factory=list)
    from_cache: bool = False
    error: Optional[str] = None
    # Les octets bruts, pour ce qui n'est pas du texte. `text` ne peut pas
    # porter un PDF : le decodage puis le re-encodage remplacent tout octet
    # non-UTF-8 par U+FFFD. Sur la note IPSM de l'ARTP, c'est 359 375 octets
    # sur 1,7 Mo qui disparaissaient — le PDF arrivait entier et illisible.
    # Le cache disque ne les conserve pas : il est fait pour du texte.
    octets: bytes = b""

    @property
    def ok(self) -> bool:
        return self.error is None and 200 <= self.status < 300



# ------------------------------------------------------------------------------------
# Chaîne de certificats incomplète
# ------------------------------------------------------------------------------------
#
# Plusieurs sites institutionnels — cie.ci, artp.sn — présentent un certificat
# parfaitement valide mais **omettent d'envoyer leur certificat intermédiaire**.
# Un navigateur va le chercher tout seul à l'adresse inscrite dans l'extension
# AIA du certificat ; un client Python ne le fait pas, et échoue sur
# « unable to get local issuer certificate ».
#
# La réparation fait ce que fait le navigateur : elle récupère l'intermédiaire
# manquant et l'ajoute au magasin de confiance. **La vérification reste
# entière** — rien n'est désactivé, aucun contrôle n'est contourné. C'est la
# correction d'un défaut de configuration du serveur, pas un passage en force.
#
# L'ordre compte et il est délibéré : on tente d'abord la vérification normale,
# et la réparation n'intervient que sur ce message précis, qui désigne une
# chaîne incomplète et rien d'autre. Un nom qui ne correspond pas, un certificat
# auto-signé ou expiré remontent tels quels. À aucun moment `verify=False`
# n'apparaît ici.

MESSAGE_CHAINE_INCOMPLETE = "unable to get local issuer certificate"
_MAGASINS: dict = {}


def _aia_du_site(hote: str, port: int = 443):
    """Adresse de l'intermédiaire manquant, lue dans le certificat du site.

    Rend ``None`` si le certificat ne déclare pas d'AIA : il n'y a alors rien à
    réparer, et l'échec vient d'ailleurs.
    """
    import socket
    import ssl

    from cryptography import x509
    from cryptography.hazmat.backends import default_backend

    contexte = ssl.create_default_context()
    contexte.check_hostname = False
    contexte.verify_mode = ssl.CERT_NONE
    with socket.create_connection((hote, port), timeout=20) as brut:
        with contexte.wrap_socket(brut, server_hostname=hote) as canal:
            der = canal.getpeercert(binary_form=True)

    certificat = x509.load_der_x509_certificate(der, default_backend())
    try:
        extension = certificat.extensions.get_extension_for_class(
            x509.AuthorityInformationAccess).value
    except x509.ExtensionNotFound:
        return None
    for acces in extension:
        if acces.access_method._name == "caIssuers":
            return acces.access_location.value
    return None


def _magasin(url_aia: str) -> str:
    """certifi + l'intermédiaire que le serveur omet. Un seul téléchargement."""
    import tempfile
    from pathlib import Path

    if url_aia in _MAGASINS and Path(_MAGASINS[url_aia]).exists():
        return _MAGASINS[url_aia]

    import certifi
    import requests
    from cryptography import x509
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives.serialization import Encoding

    der = requests.get(url_aia, timeout=30).content
    intermediaire = x509.load_der_x509_certificate(der, default_backend())

    fichier = tempfile.NamedTemporaryFile("wb", suffix=".pem", delete=False)
    fichier.write(Path(certifi.where()).read_bytes())
    fichier.write(b"\n")
    fichier.write(intermediaire.public_bytes(Encoding.PEM))
    fichier.close()
    _MAGASINS[url_aia] = fichier.name
    return fichier.name


class Transport(Protocol):
    def get(self, url: str, headers: dict, timeout: float) -> Response: ...


class RequestsTransport:
    """Transport réel fondé sur requests.Session (connexions réutilisées)."""

    def __init__(self):
        import requests

        self._requests = requests
        self.session = requests.Session()

    def get(self, url: str, headers: dict, timeout: float) -> Response:
        t0 = time.perf_counter()
        try:
            r = self._avec_chaine_reparee(url, headers, timeout)
        except self._requests.exceptions.SSLError as e:
            return Response(url, 0, elapsed=time.perf_counter() - t0, error=f"ssl: {type(e).__name__}")
        except self._requests.exceptions.ConnectionError as e:
            msg = str(e)
            kind = "dns" if ("Name or service not known" in msg or "getaddrinfo" in msg
                             or "NameResolution" in msg) else "connection"
            return Response(url, 0, elapsed=time.perf_counter() - t0, error=kind)
        except self._requests.exceptions.Timeout:
            return Response(url, 0, elapsed=time.perf_counter() - t0, error="timeout")
        except self._requests.exceptions.RequestException as e:
            return Response(url, 0, elapsed=time.perf_counter() - t0, error=type(e).__name__)
        return Response(r.url, r.status_code, r.text, dict(r.headers), time.perf_counter() - t0,
                        [h.url for h in r.history], octets=r.content)

    def _avec_chaine_reparee(self, url, headers, timeout):
        """GET normal ; répare la chaîne si — et seulement si — elle est incomplète."""
        try:
            return self.session.get(url, headers=headers, timeout=timeout,
                                    allow_redirects=True)
        except self._requests.exceptions.SSLError as erreur:
            if MESSAGE_CHAINE_INCOMPLETE not in str(erreur):
                raise
        hote = urlsplit(url).netloc.split(":")[0]
        adresse = _aia_du_site(hote)
        if not adresse:
            raise self._requests.exceptions.SSLError(
                "{} : chaîne incomplète et aucun AIA déclaré, rien à réparer "
                "— l'échec vient d'ailleurs.".format(hote))
        log.info("%s : chaîne de certificats réparée par l'AIA déclarée", hote)
        return self.session.get(url, headers=headers, timeout=timeout,
                                allow_redirects=True, verify=_magasin(adresse))



# --------------------------------------------------------------------------------------
# robots.txt
# --------------------------------------------------------------------------------------


def _pattern_to_regex(pattern: str) -> re.Pattern:
    anchored = pattern.endswith("$")
    if anchored:
        pattern = pattern[:-1]
    rx = "".join(".*" if c == "*" else re.escape(c) for c in pattern)
    return re.compile("^" + rx + ("$" if anchored else ""))


class RobotsPolicy:
    """Interprète un robots.txt selon la RFC 9309 (jokers, règle la plus spécifique)."""

    def __init__(self, text: Optional[str], user_agent: str = "JumiaCPI-Research",
                 allow_all: bool = False, disallow_all: bool = False, source_status: int = 200):
        self.text = text or ""
        self.allow_all = allow_all
        self.disallow_all = disallow_all
        self.source_status = source_status
        self.sitemaps: list[str] = []
        self.comments: list[str] = []
        self.crawl_delay: Optional[float] = None
        self.rules: list[tuple[str, str, re.Pattern]] = []  # (allow|disallow, motif, regex)
        self.group_name = "*"
        if text:
            self._parse(text, user_agent.split("/")[0].lower())

    def _parse(self, text: str, token: str) -> None:
        groups: list[dict] = []
        current = None
        last_was_agent = False
        for raw in text.splitlines():
            line = raw.strip()
            if line.startswith("#"):
                c = line.lstrip("#").strip()
                if c:
                    self.comments.append(c)
                continue
            line = line.split("#", 1)[0].strip()
            if ":" not in line:
                continue
            key, value = (s.strip() for s in line.split(":", 1))
            key = key.lower()
            if key == "user-agent":
                if not last_was_agent or current is None:
                    current = {"agents": [], "rules": [], "delay": None}
                    groups.append(current)
                current["agents"].append(value.lower())
                last_was_agent = True
                continue
            last_was_agent = False
            if key == "sitemap":
                self.sitemaps.append(value)
            elif current is None:
                continue
            elif key in ("allow", "disallow"):
                if value:
                    current["rules"].append((key, value))
            elif key == "crawl-delay":
                try:
                    current["delay"] = float(value)
                except ValueError:
                    pass

        chosen, best = None, -1
        for g in groups:
            for a in g["agents"]:
                if a != "*" and a in token and len(a) > best:
                    chosen, best = g, len(a)
        if chosen is None:
            chosen = next((g for g in groups if "*" in g["agents"]), None)
            self.group_name = "*"
        else:
            self.group_name = chosen["agents"][0]
        if chosen:
            self.rules = [(k, v, _pattern_to_regex(v)) for k, v in chosen["rules"]]
            self.crawl_delay = chosen["delay"]

    def can_fetch(self, url_or_path: str) -> bool:
        if self.disallow_all:
            return False
        if self.allow_all or not self.rules:
            return True
        parts = urlsplit(url_or_path)
        path = (parts.path or "/") + (f"?{parts.query}" if parts.query else "")
        verdict, length = "allow", -1
        for kind, pat, rx in self.rules:
            if rx.match(path):
                plen = len(pat)
                if plen > length or (plen == length and kind == "allow"):
                    verdict, length = kind, plen
        return verdict == "allow"

    def matching_rule(self, url_or_path: str) -> Optional[str]:
        parts = urlsplit(url_or_path)
        path = (parts.path or "/") + (f"?{parts.query}" if parts.query else "")
        hits = [(len(p), k, p) for k, p, rx in self.rules if rx.match(path)]
        if not hits:
            return None
        hits.sort(key=lambda h: (h[0], h[1] == "allow"))
        _, k, p = hits[-1]
        return f"{k.capitalize()}: {p}"

    def summary(self) -> dict:
        return {
            "groupe": self.group_name,
            "règles": len(self.rules),
            "interdictions": sum(1 for k, *_ in self.rules if k == "disallow"),
            "crawl_delay": self.crawl_delay,
            "sitemaps": len(self.sitemaps),
            "politique (commentaires)": " | ".join(self.comments[:6]),
        }


# --------------------------------------------------------------------------------------
# Fetcher
# --------------------------------------------------------------------------------------


class Fetcher:
    def __init__(self, user_agent: str, delay: float = 2.0, jitter: float = 0.5, timeout: float = 25.0,
                 max_retries: int = 4, transport: Optional[Transport] = None,
                 cache_dir: Optional[Path] = None, cache_ttl_hours: float = 12.0,
                 respect_robots: bool = True, sleep: Callable[[float], None] = time.sleep,
                 accept_language: str = "fr,en;q=0.8"):
        self.user_agent = user_agent
        self.delay = delay
        self.jitter = jitter
        self.timeout = timeout
        self.max_retries = max_retries
        self.transport = transport or RequestsTransport()
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_ttl = cache_ttl_hours * 3600
        self.respect_robots = respect_robots
        self.sleep = sleep
        self.accept_language = accept_language
        self._robots: dict[str, RobotsPolicy] = {}
        self._last: dict[str, float] = {}
        self.stats = {"requêtes": 0, "cache": 0, "reprises": 0, "bloquées_robots": 0, "erreurs": 0,
                      "octets": 0}
        self.cache_tag = ""  # ex. date de collecte : sépare les caches de deux relevés

    @property
    def headers(self) -> dict:
        """Les en-tetes envoyes, garantis transportables.

        Un en-tete HTTP ne transporte pas d'UTF-8. Un caractere non-ASCII y
        part en octet brut et fait refuser la requete par un pare-feu
        applicatif - avec un 403 qui se lit « le site nous bloque », alors que
        la cause est chez nous. La garde est posee ici, au dernier endroit par
        lequel tout passe, plutot qu'a chaque appelant.
        """
        import unicodedata

        def transportable(valeur):
            decompose = unicodedata.normalize("NFKD", str(valeur))
            return "".join(c for c in decompose if ord(c) < 128)

        bruts = {"User-Agent": self.user_agent,
                 "Accept-Language": self.accept_language,
                 "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
        return {cle: transportable(valeur) for cle, valeur in bruts.items()}

    # robots -----------------------------------------------------------------------------
    def robots_for(self, url: str) -> RobotsPolicy:
        parts = urlsplit(url)
        host = f"{parts.scheme}://{parts.netloc}"
        if host not in self._robots:
            r = self._raw_get(urljoin(host, "/robots.txt"))
            if r.error:
                # Site injoignable : prudence, rien n'est autorisé.
                pol = RobotsPolicy(None, disallow_all=True, source_status=0)
            elif r.status == 200:
                pol = RobotsPolicy(r.text, self.user_agent, source_status=200)
            elif 400 <= r.status < 500 and r.status != 429:
                pol = RobotsPolicy(None, allow_all=True, source_status=r.status)
            else:
                pol = RobotsPolicy(None, disallow_all=True, source_status=r.status)
            self._robots[host] = pol
        return self._robots[host]

    def allowed(self, url: str) -> bool:
        return (not self.respect_robots) or self.robots_for(url).can_fetch(url)

    # cache ------------------------------------------------------------------------------
    def _cache_path(self, url: str) -> Optional[Path]:
        if not self.cache_dir:
            return None
        h = hashlib.sha256(f"{self.cache_tag}|{url}".encode()).hexdigest()[:32]
        return self.cache_dir / f"{h}.json"

    def _cache_read(self, url: str) -> Optional[Response]:
        p = self._cache_path(url)
        if not p or not p.exists():
            return None
        if self.cache_ttl and time.time() - p.stat().st_mtime > self.cache_ttl and not self.cache_tag:
            return None
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return Response(**d, from_cache=True)

    def _cache_write(self, url: str, r: Response) -> None:
        p = self._cache_path(url)
        if not p or not r.ok:
            return
        d = {"url": r.url, "status": r.status, "text": r.text, "headers": {}, "elapsed": r.elapsed,
             "history": r.history}
        p.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")

    # requêtes ---------------------------------------------------------------------------
    def _wait(self, host: str, min_delay: float) -> None:
        last = self._last.get(host)
        if last is not None:
            wait = min_delay + random.uniform(0, self.jitter if min_delay > 0 else 0) - (time.monotonic() - last)
            if wait > 0:
                self.sleep(wait)
        self._last[host] = time.monotonic()

    def _raw_get(self, url: str) -> Response:
        host = urlsplit(url).netloc
        pol = self._robots.get(f"{urlsplit(url).scheme}://{host}")
        min_delay = max(self.delay, (pol.crawl_delay or 0) if pol else 0)
        attempt = 0
        while True:
            self._wait(host, min_delay)
            self.stats["requêtes"] += 1
            r = self.transport.get(url, self.headers, self.timeout)
            retryable = (r.error in {"connection", "timeout"}) or r.status in RETRY_STATUSES
            if not retryable or attempt >= self.max_retries:
                if r.error or r.status >= 400:
                    self.stats["erreurs"] += 1
                self.stats["octets"] += len(r.text or "")
                return r
            attempt += 1
            self.stats["reprises"] += 1
            backoff = max(1.0, self.delay) * (2 ** attempt)
            ra = (r.headers or {}).get("Retry-After") or (r.headers or {}).get("retry-after")
            if ra and str(ra).isdigit():
                backoff = max(backoff, float(ra))
            log.warning("HTTP %s sur %s : nouvel essai %d/%d dans %.1fs", r.status or r.error, url,
                        attempt, self.max_retries, backoff)
            self.sleep(min(backoff, 120))

    def get(self, url: str, check_robots: bool = True, use_cache: bool = True) -> Response:
        if check_robots and self.respect_robots and not self.allowed(url):
            self.stats["bloquées_robots"] += 1
            raise RobotsDisallowed(f"{url} est interdit par robots.txt "
                                   f"({self.robots_for(url).matching_rule(url)})")
        if use_cache:
            cached = self._cache_read(url)
            if cached:
                self.stats["cache"] += 1
                return cached
        r = self._raw_get(url)
        if use_cache:
            self._cache_write(url, r)
        return r


def render_with_playwright(url: str, user_agent: str, timeout_ms: int = 30000,
                           attendre: str = "domcontentloaded",
                           pause_ms: int = 6000, defiler: int = 4000,
                           pause_apres_defilement_ms: int = 4000) -> Optional[str]:
    """Repli pour les pages rendues côté client. Rend le HTML, ou None sans Playwright.

    L'appelant doit avoir vérifié robots.txt avant.

    `attendre` valait « networkidle », et c'était un mauvais défaut : sur un site
    chargé de publicités et de mouchards, le réseau ne devient jamais inactif, la
    tentative expire et l'on récupère la page **non rendue** — ce qui ressemble à
    « le site n'a pas d'annonces » alors qu'elles n'ont simplement pas eu le temps
    d'arriver. Mesuré sur meqasa.com : 160 593 caractères avec « networkidle »,
    367 641 avec « domcontentloaded » suivi d'une pause et d'un défilement.

    Le défilement est nécessaire là où les vignettes n'arrivent qu'au scroll ;
    `defiler=0` le désactive.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        log.warning("Playwright non installé : pip install playwright && playwright install chromium")
        return None
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(user_agent=user_agent)
        try:
            page.goto(url, timeout=timeout_ms, wait_until=attendre)
            if pause_ms:
                page.wait_for_timeout(pause_ms)
            if defiler:
                page.mouse.wheel(0, defiler)
                page.wait_for_timeout(pause_apres_defilement_ms)
            html = page.content()
        finally:
            browser.close()
    return html
