"""jumia-cpi : collecte de prix en ligne sur Jumia et indices de prix à la consommation."""
from .config import VERSION as __version__  # noqa: F401
