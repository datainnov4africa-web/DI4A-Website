# -*- coding: utf-8 -*-
"""Des tableaux officiels au format du panel.

Les lecteurs de :mod:`src.officiel` rendent chacun la forme de sa publication :
un relevé de marché n'a pas la même structure qu'une grille tarifaire. Le
notebook d'analyse, lui, n'en connaît qu'une. La correspondance est faite ici,
explicitement, plutôt que par un renommage automatique qui marcherait jusqu'au
jour où une colonne change de nom sans prévenir.

Trois sorties, et la séparation est volontaire
----------------------------------------------
* **les relevés** — des prix, agrégeables avec ceux de l'e-commerce ;
* **les indices** — déjà construits, et qui ne sont pas des prix. Les mêler aux
  relevés reviendrait à calculer un indice d'indices, ce qui n'a pas de sens :
  ils se raccordent au niveau de la division ;
* **le journal** — ce que chaque source a donné, y compris quand elle n'a rien
  donné. Une source muette est une information, pas un silence.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime
from inspect import signature

import pandas as pd

from . import loyers, officiel


@dataclass(frozen=True)
class SourceOfficielle:
    """Une publication institutionnelle, et ce qu'elle apporte au panier."""
    nom: str
    pays: str
    division: str                 # division COICOP alimentée
    intitule: str
    collecteur: str               # nom d'une fonction de `src.officiel`
    url: str
    devise: str
    nature: str = "prix"          # « prix » ou « indice »
    note: str = ""
    # Un lecteur partage entre plusieurs pays a besoin de savoir lequel il
    # lit. Un tuple de couples plutot qu'un dict : la classe est gelee.
    parametres: tuple = ()


SOURCES = (
    SourceOfficielle(
        "ocpv", "CI", "01", "Prix de détail sur les marchés",
        "collecter_ocpv", "https://infoprixocpv.com/", "XOF",
        note="Prix relevés sur les marchés réels, pas en ligne — le complément "
             "exact de l'e-commerce, et la réponse à la réserve « les acheteurs "
             "en ligne sont urbains et connectés ». Interrogée sans filtre de "
             "dates, la plateforme ne rend que 194 lignes ; sur un an, plus de "
             "deux mille. Le filtre élargit la couverture au lieu de la "
             "restreindre — l'inverse de ce qu'on attendrait."),
    SourceOfficielle(
        "sikafinance", "CI", "01", "Prix de grande consommation, six villes",
        "collecter_sikafinance",
        "https://www.sikafinance.com/conso/liste_des_prix", "XOF",
        note="Quatre-vingts produits dans six villes, servis en forme large — "
             "une colonne par ville. Lire le tableau sans le déplier ferait "
             "disparaître la dimension géographique, et « Riz local » "
             "ressortirait à six prix tous étiquetés pareil."),
    SourceOfficielle(
        "anare", "CI", "04", "Tarifs d'électricité du régulateur",
        "tarifs_electricite",
        "https://anare.ci/le-marche/prix-de-lelectricite/", "XOF",
        note="Prix administrés : il n'y a pas de marché à relever, ils sont "
             "arrêtés et publiés. La division 04 — logement, eau, électricité, "
             "gaz — est hors de portée de toute collecte marchande."),
    SourceOfficielle(
        "crse", "SN", "04", "Grille tarifaire de l'électricité",
        "collecter_crse", "https://www.crse.sn/secteurs/secteur-electricite/",
        "XOF",
        note="Même nature que l'ANARE : des tarifs réglementés, publiés par le "
             "régulateur sénégalais."),
    SourceOfficielle(
        "ipsm_sn", "SN", "08", "Indice des prix des services mobiles",
        "collecter_ipsm",
        "https://www.artp.sn/indice-des-prix-des-services-mobiles-ispm", "",
        nature="indice",
        note="Ce n'est PAS un prix : c'est un indice déjà construit, base 100 "
             "en 2023 — la même base que l'IHPC officiel, donc comparable sans "
             "raccord. La division 08 pèse 7,46 % du panier sénégalais et "
             "aucune collecte marchande ne peut la mesurer : les opérateurs "
             "vendent des forfaits dont le prix unitaire n'a pas de sens sans "
             "profil de consommation."),
) + tuple(
    # Prix alimentaires du PAM — une seule et même source pour sept des huit
    # pays où Jumia est actif. Elle existe parce que la voie nationale ne
    # menait nulle part : quinze candidates sondées le 16/10/2026, aucune
    # exploitable (voir `src/pam.py` et `scripts/prospecter.py`).
    SourceOfficielle(
        "pam_" + iso.lower(), iso, "01",
        "Prix de détail sur les marchés (PAM)",
        "collecter_wfp",
        "https://data.humdata.org/dataset/wfp-food-prices-for-" + slug,
        devise,
        note="Relevés de terrain mensuels, par marché et par produit, sous "
             "licence CC BY-IGO. C'est le complément exact de l'e-commerce : "
             "la réponse à la réserve « les acheteurs en ligne sont urbains "
             "et connectés ». Ce n'est pas un panier IPC — le PAM relève ce "
             "qui compte pour la sécurité alimentaire.",
        parametres=(("pays", iso),) + extra)
    for iso, slug, devise, extra in (
        ("CI", "cote-d-ivoire", "XOF", ()), ("SN", "senegal", "XOF", ()),
        ("NG", "nigeria", "NGN", ()), ("KE", "kenya", "KES", ()),
        # La série ghanéenne s'arrête en juillet 2023 : sur la fenêtre de
        # 24 mois, elle ne rend rien. On l'ouvre à cinq ans pour qu'elle
        # serve d'historique — elle ne peut pas alimenter un indice courant.
        ("GH", "ghana", "GHS", (("mois", 60),)),
        ("UG", "uganda", "UGX", ()), ("EG", "egypt", "EGP", ()),
    )
) + tuple(
    # Loyers — division 04, groupe 04.1. C'est le poste non alimentaire le plus
    # lourd d'un panier africain : 10,65 % de l'IHPC ivoirien, deuxième groupe
    # de tout l'indice. Il est absent du commerce en ligne, d'où ces sources
    # d'annonces. Le détail des sites, leurs pièges et les refus rencontrés
    # sont dans `src/loyers.py`.
    SourceOfficielle(
        "loyers_" + source.pays.lower(), source.pays, "04",
        source.intitule, "collecter_loyers", source.urls[0], source.devise,
        note="Annonces de location. Un prix demandé n'est pas un loyer "
             "pratiqué : sur la Côte d'Ivoire, l'écart mesuré entre un indice "
             "d'annonces et l'enquête de terrain allait de +3,8 % en mai 2024 "
             "à +5,3 % en juillet, et il se creusait. Complément à instruire, "
             "non substitut. Les rayons mélangent ventes et locations ; le tri "
             "se fait à l'analyse, sur la colonne « nature ».",
        parametres=(("pays", source.pays),))
    for source in loyers.SOURCES
)

# Divisions qu'aucune source du registre ne couvre. Les taire laisserait croire
# à une couverture complète ; un indice doit savoir dire ce qu'il ne mesure pas.
DIVISIONS_HORS_ATTEINTE = {
    "02": "Boissons alcoolisées et tabac — partiellement en ligne, non instrumenté",
    "06": "Santé — deux ressources instruites en Côte d'Ivoire, aucune exploitable",
    "07": "Transports — aucune source ; demande un relevé de terrain",
    "10": "Enseignement — aucune source",
    "11": "Restaurants et hébergement — aucune source",
    "12": "Assurances et services financiers — aucune source",
}


def sources_du_pays(pays: str, nature: str = "") -> tuple:
    code = (pays or "").upper()
    return tuple(s for s in SOURCES if s.pays == code
                 and (not nature or s.nature == nature))


def pays_couverts() -> tuple:
    return tuple(sorted({s.pays for s in SOURCES}))


def _cle(source: str, *morceaux) -> str:
    """Identifiant stable d'un relevé institutionnel.

    Un tarif n'a pas de référence produit : la clé est construite à partir de ce
    qui le désigne — le marché, la ville, la tranche. Elle doit être **stable
    d'un mois sur l'autre**, sinon le modèle apparié ne retrouve rien et
    l'indice ne peut pas se calculer.
    """
    propres = [re.sub(r"\s+", " ", str(m)).strip().lower()
               for m in morceaux if m is not None and str(m).strip()]
    return "{}:{}".format(source, "|".join(propres)) if propres else source


def vers_panel(table: pd.DataFrame, source: SourceOfficielle,
               jour: str) -> pd.DataFrame:
    """Met un tableau officiel au format que le notebook d'analyse attend."""
    if table is None or len(table) == 0:
        return pd.DataFrame()
    lignes = []

    if source.nom.startswith("loyers_"):
        # Une annonce de location devient un releve de prix comme un autre, a
        # ceci pres qu'on garde sa nature (location / vente / indeterminee) et
        # le texte du prix dans le libelle : sans eux, un indice melerait des
        # loyers mensuels a des prix de vente et des loyers annuels.
        for _, r in table.iterrows():
            montant = r.get("loyer")
            if montant is None or pd.isna(montant):
                continue
            nature = r.get("nature") or "indeterminee"
            lignes.append({
                "sku": _cle(source.nom, r.get("url"), r.get("loyer")),
                "name": "{} [{}] {}".format(
                    str(r.get("titre") or "")[:150], nature,
                    str(r.get("prix_texte") or "")[:70]),
                "jumia_category": source.intitule,
                "category_name": "Loyers — {}".format(nature),
                "price": float(montant),
                "currency": r.get("devise") or source.devise,
                "seller": r.get("source") or source.nom,
                "collect_date": str(r.get("date_collecte") or jour)[:10],
            })

    elif source.nom in ("ocpv", "sikafinance") or source.nom.startswith("pam_"):
        for _, r in table.iterrows():
            prix = r.get("prix_moyen")
            if prix is None or pd.isna(prix):
                continue
            lieu = r.get("marche") or r.get("ville") or ""
            stade = r.get("stade") or ""
            lignes.append({
                "sku": _cle(source.nom, r.get("produit"), lieu, stade),
                "name": " ".join(str(x) for x in (r.get("produit"), r.get("unite")) if x),
                "jumia_category": source.intitule,
                "category_name": "{} — {}".format(source.intitule, lieu or "ensemble"),
                "price": float(prix),
                "currency": r.get("unite_monetaire") or source.devise,
                "seller": source.nom,
                "collect_date": str(r.get("date_prix") or jour)[:10],
            })

    elif source.nom == "anare":
        for _, r in table.iterrows():
            ttc = r.get("ttc")
            if ttc is None or pd.isna(ttc):
                continue
            lignes.append({
                "sku": _cle(source.nom, r.get("categorie"), r.get("designation")),
                "name": "{} — {}".format(r.get("categorie"), r.get("designation")),
                "jumia_category": source.intitule,
                "category_name": "Électricité — {}".format(r.get("categorie")),
                "price": float(ttc),
                "currency": source.devise,
                "seller": "ANARE-CI",
                "collect_date": jour,
            })

    elif source.nom == "crse":
        for _, r in table.iterrows():
            prix = r.get("prix")
            if prix is None or pd.isna(prix):
                continue
            lignes.append({
                "sku": _cle(source.nom, r.get("segment"), r.get("categorie"),
                            r.get("tranche")),
                "name": " — ".join(str(x) for x in (r.get("categorie"),
                                                    r.get("tranche")) if x),
                "jumia_category": source.intitule,
                "category_name": "Électricité — {}".format(r.get("segment") or "ensemble"),
                "price": float(prix),
                "currency": source.devise,
                "seller": "CRSE",
                "collect_date": jour,
            })

    if not lignes:
        return pd.DataFrame()
    out = pd.DataFrame(lignes)
    out["brand"] = None
    out["old_price"] = None
    out["country"] = source.pays
    out["division_hint"] = source.division
    out["category_slug"] = source.nom
    out["category_depth"] = 1
    out["parse_method"] = "tableau officiel"
    out["collected_at"] = datetime.now().isoformat(timespec="seconds")
    out["n_ratings"] = 0
    out["rating"] = None
    out["discount_pct"] = None
    out["is_buyable"] = True
    out["url"] = source.url
    out["page"] = 1
    out["availability"] = "publié"
    return out


def collecter(pays: str, fetcher, sources=None, jour: str | None = None,
              courriel: str = "") -> dict:
    """Collecte les sources institutionnelles d'un pays.

    Une source qui échoue n'arrête pas les autres : son incident est journalisé
    et le parcours continue. Un régulateur qui refond sa page ne doit pas
    emporter la collecte entière.
    """
    officiel.preparer(fetcher)
    jour = jour or date.today().isoformat()
    retenues = tuple(sources) if sources is not None else sources_du_pays(pays)
    releves, indices, journal = [], [], []

    # Un pays sans source instruite rendait une archive vide sans rien dire.
    # Le carnet, lui, affiche un message ; un script appelant cette fonction
    # directement n'avait aucun moyen de distinguer « rien à collecter » de
    # « la collecte n'a rien donné ».
    if not retenues:
        journal.append(
            "[{}] aucune source institutionnelle instruite — rien à "
            "collecter. Pays couverts : {}.".format(
                (pays or "?").upper(), ", ".join(pays_couverts()) or "aucun"))

    for source in retenues:
        fonction = getattr(officiel, source.collecteur, None)
        if fonction is None:
            journal.append("[{}] collecteur « {} » introuvable"
                           .format(source.nom, source.collecteur))
            continue
        arguments = dict(source.parametres)
        # Certaines publications exigent que l'appelant s'identifie — HDX
        # HAPI, par exemple, refuse une requete anonyme. On ne transmet le
        # courriel qu'aux lecteurs qui le demandent.
        if courriel and "courriel" in signature(fonction).parameters:
            arguments["courriel"] = courriel
        incidents = []
        try:
            brut = fonction(incidents=incidents, **arguments)
        except Exception as erreur:
            journal.append("[{}] échec : {} — {}".format(
                source.nom, type(erreur).__name__, str(erreur)[:160]))
            continue
        journal.extend(incidents)

        if brut is None or len(brut) == 0:
            journal.append("[{}] aucune ligne — la publication a peut-être "
                           "changé de forme".format(source.nom))
            continue

        if source.nature == "indice":
            table = brut.copy()
            table["source"] = source.nom
            table["pays"] = source.pays
            table["division"] = source.division
            indices.append(table)
            journal.append("[{}] {} ligne(s) d'indice, division {}"
                           .format(source.nom, len(table), source.division))
        else:
            mis = vers_panel(brut, source, jour)
            if len(mis) == 0:
                journal.append("[{}] {} ligne(s) lues, aucune exploitable "
                               "(prix manquants)".format(source.nom, len(brut)))
                continue
            releves.append(mis)
            journal.append("[{}] {} relevé(s), division {}, {} lieu(x)".format(
                source.nom, len(mis), source.division,
                mis["category_name"].nunique()))

    return {
        "releves": pd.concat(releves, ignore_index=True) if releves else pd.DataFrame(),
        "indices": pd.concat(indices, ignore_index=True) if indices else pd.DataFrame(),
        "journal": journal,
        "sources": retenues,
    }


def couverture(releves=None, indices=None, divisions_ecommerce=()) -> pd.DataFrame:
    """Quelles divisions sont atteintes, par quelle voie, et lesquelles ne le sont pas.

    C'est le tableau qui dit ce que vaut l'ensemble. Un indice qui ne couvre que
    cinq divisions sur treize n'est pas faux : il est partiel, et il doit le
    dire lui-même.
    """
    from .config import COICOP_DIVISIONS

    par_division = {}
    for d in divisions_ecommerce:
        par_division.setdefault(str(d), []).append("e-commerce")
    if releves is not None and len(releves) and "division_hint" in releves:
        for d in releves["division_hint"].dropna().unique():
            par_division.setdefault(str(d), []).append("prix administrés")
    if indices is not None and len(indices) and "division" in indices:
        for d in indices["division"].dropna().unique():
            par_division.setdefault(str(d), []).append("indice institutionnel")

    lignes = []
    for code, libelle in sorted(COICOP_DIVISIONS.items()):
        voies = sorted(set(par_division.get(code, [])))
        lignes.append({
            "division": code,
            "intitulé": libelle,
            "couverte": "oui" if voies else "non",
            "par": ", ".join(voies) or "—",
            "pourquoi pas": "" if voies else DIVISIONS_HORS_ATTEINTE.get(
                code, "aucune source instruite"),
        })
    return pd.DataFrame(lignes)
