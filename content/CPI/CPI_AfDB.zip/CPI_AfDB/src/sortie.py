"""D'où part la requête — et pourquoi cela change la lecture d'un refus.

Ce module existe à cause d'un constat vérifiable. Le 13/10/2026, ce pipeline a
testé 14 sites Jumia depuis Google Colab : **dix ont répondu HTTP 403, en 14 à
20 millisecondes**. Une requête qui part d'un centre de données européen vers
Abidjan et revient en 15 ms n'a jamais atteint un serveur Jumia ; elle a été
refusée par le nœud CDN le plus proche, sur la seule base de l'adresse de
sortie. Le contraste interne au même tableau le montre : les quatre marchés
réellement fermés répondaient en 735 à 742 ms, parce qu'ils faisaient un vrai
aller-retour avant de rediriger.

Le même jour, depuis un poste de travail ordinaire, jumia.ci et jumia.sn ont
servi 11 358 lignes de catalogue.

Autrement dit : **huit sites ouverts ont été classés « restreints »**, et le
message affiché à l'utilisateur — « vérifiez votre connexion » — l'envoyait
chercher au mauvais endroit. Sa connexion allait très bien ; c'était son point
de sortie.

La distinction qui compte
-------------------------
Deux refus se ressemblent et n'ont rien à voir :

* le `robots.txt` **a été lu** et il interdit la page d'accueil. C'est une
  décision publiée de l'éditeur. Elle vaut depuis n'importe quel réseau, et il
  n'y a rien à revérifier — c'est le cas de l'Algérie et de la Tunisie, que
  Jumia a quittées ;
* le site répond **403 sur tout, `robots.txt` compris**. On n'a alors lu aucune
  règle : on ne sait pas ce que l'éditeur autorise, on sait seulement qu'on
  n'est pas le bienvenu **d'ici**.

Le second cas, depuis un centre de données, ne permet pas de conclure. Le
verdict devient « indéterminé », et la conduite est de revérifier depuis le
réseau de l'institut — jamais de contourner.

Ce module ne contourne rien
---------------------------
Savoir qu'on sort d'un centre de données sert à **interpréter** un refus, pas à
le franchir. Le `robots.txt` de Jumia vise nommément la parade qu'on serait
tenté d'essayer : *« bots trying to use too many IPs to increase performance may
also be blocked »*. Changer d'adresse pour échapper à un comptage est une
décision d'éditeur contournée, pas un problème technique résolu.
"""
from __future__ import annotations

import os
import platform
import socket
import sys
import time

# Fabricants déclarés par la machine, lus dans le DMI. Grossier, mais sans
# réseau, et suffisant pour la question posée : poste de travail ou
# infrastructure ?
VENDEURS_NUAGE = ("google", "amazon", "ec2", "microsoft", "azure", "digitalocean",
                  "hetzner", "ovh", "scaleway", "alibaba", "oracle", "vultr",
                  "linode", "xen", "qemu", "kvm")

# Suffixes de résolution inverse qui désignent une adresse d'infrastructure.
SUFFIXES_NUAGE = ("googleusercontent.com", "compute.amazonaws.com",
                  "cloudapp.azure.com", "compute.internal", "hetzner.com",
                  "ovh.net", "scw.cloud", "digitalocean.com",
                  "linodeusercontent.com")

SERVICES_IP = ("https://api.ipify.org", "https://ifconfig.me/ip",
               "https://icanhazip.com")

# En dessous de ce temps de réponse, un refus venant d'un autre continent n'a
# pas atteint le serveur d'origine : il a été rendu par le nœud CDN le plus
# proche. Mesuré à 14-20 ms sur les dix refus de Colab, contre 735-742 ms sur
# les quatre marchés réellement fermés. C'est un indice rapporté, pas un
# critère : un CDN peut légitimement être proche.
MS_REFUS_EN_BORDURE = 80

# Codes qui traduisent un refus d'accès plutôt qu'une absence de ressource.
CODES_REFUS = (401, 403, 429, 503)


def sur_colab() -> bool:
    """Tourne-t-on dans Google Colab.

    ``find_spec("google.colab")`` **lève** quand le paquet parent ``google``
    n'existe pas, parce qu'il importe le parent pour chercher l'enfant. On
    regarde donc ``sys.modules`` d'abord — Colab y a déjà chargé le module — et
    on n'interroge le système d'import qu'ensuite, sous garde.
    """
    if "google.colab" in sys.modules:
        return True
    try:
        import importlib.util

        return importlib.util.find_spec("google.colab") is not None
    except Exception:
        return False


def _vendeur_machine() -> str:
    for chemin in ("/sys/class/dmi/id/sys_vendor", "/sys/class/dmi/id/product_name"):
        try:
            with open(chemin, encoding="utf-8", errors="replace") as fichier:
                valeur = fichier.read().strip().lower()
            if valeur:
                return valeur
        except OSError:
            continue
    return ""


def adresse_publique(timeout: float = 6.0):
    """Adresse de sortie vue par un tiers, ou ``None``. Demande le réseau."""
    import requests

    for service in SERVICES_IP:
        try:
            r = requests.get(service, timeout=timeout)
            if r.status_code == 200:
                brut = r.text.strip()
                if brut and len(brut) <= 45:
                    return brut
        except Exception:
            continue
    return None


def _resolution_inverse(adresse: str) -> str:
    try:
        return socket.gethostbyaddr(adresse)[0].lower()
    except Exception:
        return ""


def contexte(sonder_reseau: bool = False) -> dict:
    """Ce qu'on peut établir de l'endroit d'où partent les requêtes.

    Sans ``sonder_reseau``, aucune requête n'est émise : on rend ce que la
    machine déclare d'elle-même. La clé qui compte est ``centre_de_donnees``,
    et elle vaut ``True`` sur Colab sans aucune sonde — Colab *est* un centre
    de données, il n'y a rien à vérifier.

    ``None`` signifie « indéterminé » et se distingue de ``False`` : supposer
    un poste de travail là où on ne sait pas ferait conclure trop vite qu'un
    refus vient du site.
    """
    colab = sur_colab()
    vendeur = _vendeur_machine()
    conteneur = os.path.exists("/.dockerenv")

    etat = {
        "colab": colab,
        "conteneur": conteneur,
        "vendeur_machine": vendeur or None,
        "systeme": platform.system(),
        "python": sys.version.split()[0],
        "fuseau": time.strftime("%Z") or None,
        "adresse_publique": None,
        "resolution_inverse": None,
        # L'agent voyage avec le contexte : c'est lui qui permet de voir une
        # cause de refus qui serait chez nous plutot que chez l'editeur.
        "agent": "",
        "reseau_sonde": bool(sonder_reseau),
    }

    if colab or conteneur or any(i in vendeur for i in VENDEURS_NUAGE):
        etat["centre_de_donnees"] = True
    else:
        etat["centre_de_donnees"] = None

    if sonder_reseau:
        adresse = adresse_publique()
        etat["adresse_publique"] = adresse
        if adresse:
            nom = _resolution_inverse(adresse)
            etat["resolution_inverse"] = nom or None
            if nom and any(nom.endswith(s) for s in SUFFIXES_NUAGE):
                etat["centre_de_donnees"] = True
            elif etat["centre_de_donnees"] is None and nom:
                etat["centre_de_donnees"] = False

    etat["ou"] = ("Google Colab" if colab else
                  ("un conteneur" if conteneur else
                   ("une infrastructure hébergée" if etat["centre_de_donnees"]
                    else ("un poste de travail" if etat["centre_de_donnees"] is False
                          else "un point de sortie non qualifié"))))
    etat["avertissement"] = _avertissement(etat)
    return etat


def _avertissement(etat: dict) -> str:
    """Le fait, et sa conséquence. Un fait sans conséquence est ignoré."""
    if etat["centre_de_donnees"] is True:
        return (
            "Les requêtes partent de {}. Un HTTP 403 ou un défi anti-robot ne "
            "permet alors PAS de conclure que le site est fermé : le "
            "13/10/2026, dix sites Jumia ont répondu 403 en 15 ms depuis "
            "Colab, et deux d'entre eux ont servi 11 358 lignes le même jour "
            "depuis un poste de travail. La collecte doit se faire depuis le "
            "réseau de l'institut.".format(etat["ou"]))
    if etat["centre_de_donnees"] is None:
        if etat["reseau_sonde"]:
            return ("Point de sortie non qualifié : la sonde réseau a bien eu "
                    "lieu, mais la résolution inverse n'a rien rendu — c'est "
                    "le cas courant d'un accès grand public. Un refus restera "
                    "donc ambigu.")
        return ("Point de sortie indéterminé : appeler contexte("
                "sonder_reseau=True) pour le qualifier, sinon un refus restera "
                "ambigu.")
    return ""


# ----------------------------------------------------------- requalification

VERDICT_INDETERMINE = "undetermined"
ETIQUETTE_INDETERMINE = "❔ indéterminé d'ici"


def refus_non_concluant(http, robots_http, raison: str = "") -> bool:
    """Ce refus laisse-t-il la question ouverte, ou tranche-t-il ?

    Il tranche quand le ``robots.txt`` a été lu : la règle est publiée, elle
    vaut depuis n'importe quel réseau. Il laisse la question ouverte quand le
    site refuse **aussi** son ``robots.txt`` — on n'a alors lu aucune règle.
    """
    est_refus = (http in CODES_REFUS) or ("anti-robot" in (raison or ""))
    if not est_refus:
        return False
    # robots.txt lu avec succès : la règle publiée tranche, où qu'on soit.
    return robots_http != 200


def cause_locale(ctx: dict) -> str:
    """Un défaut de NOTRE requête qui expliquerait un refus. Vide sinon.

    Né d'un cas réel, le 13/10/2026 : le User-Agent portait « à des fins
    statistiques ». Un en-tête HTTP ne transporte pas d'UTF-8 ; le « à »
    partait en octet brut 0xE0 et le pare-feu applicatif refusait. Dix sites
    sur dix en HTTP 403, et le tableau accusait les éditeurs.

        avec l'accent   -> HTTP 403,     5 482 octets
        sans l'accent   -> HTTP 200, 1 609 506 octets

    D'où l'ordre de lecture d'un refus : **d'abord notre requête**, ensuite le
    réseau, ensuite seulement l'éditeur. C'est le moins coûteux à vérifier et
    c'est ce sur quoi nous pouvons agir.
    """
    agent = ctx.get("agent") or ""
    if agent and not agent.isascii():
        hors = sorted({c for c in agent if not c.isascii()})
        return ("le User-Agent contient des caractères non-ASCII ({}) : un "
                "en-tête HTTP ne les transporte pas, et un pare-feu "
                "applicatif refuse la requête. C'est une cause de refus qui "
                "est chez nous, pas chez l'éditeur."
                .format(" ".join(hors)))
    return ""


def requalifier(ligne: dict, ctx: dict) -> dict:
    """Ajuste un verdict de validation quand le refus ne tranche pas.

    Un refus ne tranche pas lorsque le site a refusé **jusqu'à son
    ``robots.txt``** : aucune règle n'a alors été lue, et trois causes restent
    ouvertes — notre requête, notre point de sortie, ou une décision de
    l'éditeur. Les deux premières sont à notre portée, et il faut les écarter
    avant d'accuser la troisième.

    La version précédente de cette fonction ne requalifiait que depuis un
    centre de données **confirmé**. Elle a donc laissé passer un cas où le
    point de sortie était « non qualifié » et où la cause était un accent dans
    le User-Agent : le tableau annonçait dix sites fermés, et concluait que ces
    verdicts valaient « depuis n'importe quel réseau ». Ils ne valaient rien.

    Tout le reste est rendu tel quel : un site réellement redirigé, un domaine
    mort, ou un ``robots.txt`` lu qui interdit restent ce qu'ils sont.
    """
    sortie = dict(ligne)
    sortie.setdefault("requalifié", False)
    if ligne.get("verdict") != "restricted":
        return sortie
    if not refus_non_concluant(ligne.get("http"), ligne.get("robots_http"),
                               ligne.get("raison", "")):
        return sortie

    indices = []
    temps = ligne.get("temps_ms")
    try:
        if temps is not None and float(temps) <= MS_REFUS_EN_BORDURE:
            indices.append("refus en {:.0f} ms, soit avant d'atteindre le "
                           "serveur d'origine".format(float(temps)))
    except (TypeError, ValueError):
        pass
    if ligne.get("robots_http") not in (200, None):
        indices.append("robots.txt lui-même refusé ({}), donc aucune règle "
                       "publiée n'a pu être lue".format(ligne.get("robots_http")))

    locale = cause_locale(ctx)
    if locale:
        conduite = "À vérifier EN PREMIER : {} Corriger cela avant toute "                    "autre hypothèse.".format(locale)
    elif ctx.get("centre_de_donnees"):
        conduite = ("Les requêtes partent de {} : un refus peut venir de là. "
                    "Revérifier depuis le réseau de l'institut."
                    .format(ctx.get("ou", "un centre de données")))
    else:
        conduite = ("Vérifier d'abord notre propre requête (en-têtes, agent), "
                    "puis rejouer depuis un autre réseau. N'écarter ce site "
                    "qu'ensuite.")

    sortie["verdict"] = VERDICT_INDETERMINE
    sortie["requalifié"] = True
    sortie["raison"] = "{}{}".format(
        "; ".join(indices) + ". " if indices else "", conduite)
    return sortie


def appliquer(validated, ctx: dict):
    """Requalifie un tableau de validation entier. Rend une copie.

    Ajoute la colonne ``requalifié`` : une ligne dont le verdict a été changé
    doit pouvoir être repérée, sinon la requalification est une correction
    invisible — et une correction invisible ne se relit pas.
    """
    import pandas as pd

    if validated is None or len(validated) == 0:
        return validated
    lignes = [requalifier(r, ctx) for r in validated.to_dict("records")]
    out = pd.DataFrame(lignes, index=validated.index)
    etiquettes = {"active": "✅ actif", "restricted": "⚠️ restreint",
                  "closed": "❌ fermé / redirigé",
                  VERDICT_INDETERMINE: ETIQUETTE_INDETERMINE}
    etiquette = out["verdict"].map(etiquettes)
    # On ne retombe sur l'ancienne étiquette que si elle existe : `fillna(None)`
    # lève, et un tableau sans colonne « état » est parfaitement légitime -
    # c'est le cas d'un extrait reconstruit pour un test ou un rejeu.
    if "état" in out.columns:
        etiquette = etiquette.fillna(out["état"])
    out["état"] = etiquette
    return out


def resume(validated, ctx: dict) -> str:
    """Une phrase à afficher quand aucun site n'est exploitable.

    Remplace « vérifiez votre connexion », qui envoyait chercher au mauvais
    endroit : la connexion n'est pas en cause, le point de sortie l'est.
    """
    if validated is None or len(validated) == 0:
        return "Aucun site n'a pu être testé."
    compte = validated["verdict"].value_counts().to_dict()
    n_ind = compte.get(VERDICT_INDETERMINE, 0)
    n_act = compte.get("active", 0)
    if n_act:
        return "{} site(s) actif(s).".format(n_act)
    if n_ind:
        locale = cause_locale(ctx)
        if locale:
            return ("Aucun site actif, mais {} site(s) sont **indéterminés** — "
                    "et la cause est probablement chez nous : {} "
                    "Corrigez cela et relancez : il est très probable que ces "
                    "sites soient ouverts.".format(n_ind, locale))
        return (
            "Aucun site actif, mais {} site(s) sont **indéterminés** : ils ont "
            "refusé jusqu'à leur robots.txt, donc aucune règle n'a été lue et "
            "trois causes restent ouvertes — notre requête, notre point de "
            "sortie ({}), ou une décision de l'éditeur. "
            "Vérifiez les deux premières avant d'accuser la troisième. "
            "Ne cherchez pas à contourner : le robots.txt de Jumia interdit "
            "nommément de changer d'adresse pour échapper au comptage."
            .format(n_ind, ctx.get("ou", "non qualifié")))
    return ("Aucun site actif. Les sites testés sont fermés, redirigés, ou "
            "interdisent la collecte par leur robots.txt — ces verdicts-là "
            "valent depuis n'importe quel réseau.")
