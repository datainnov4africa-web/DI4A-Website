"""Étape 3 : collecte responsable des catégories et des pages de liste Jumia.

Trois méthodes d'extraction, de la plus fiable à la plus fragile :
  1. l'état JSON embarqué dans la page (`window.__STORE__`) ;
  2. les attributs `data-gtm-*` / `data-ga4-*` des cartes produit ;
  3. le texte visible des cartes (`.name`, `.prc`, `.old`, `.bdg._dsct`, `.stars`).
Chaque ligne indique la méthode utilisée (`parse_method`) pour suivre la qualité dans le temps.

La collecte est reprise là où elle s'est arrêtée : chaque page traitée est notée dans un point
de contrôle et ses produits sont ajoutés à un fichier de transit.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin, urlsplit

import pandas as pd
from bs4 import BeautifulSoup
from tqdm.auto import tqdm

from .classification import category_division
from .fetch import Fetcher, RobotsDisallowed, render_with_playwright
from .utils import now_utc, parse_percent, parse_price, sku_from_url

log = logging.getLogger("jumia_cpi.scraper")

STORE_RX = re.compile(r"window\.__STORE__\s*=\s*(\{.*?\})\s*;?\s*</script>", re.S)
PAGE_RX = re.compile(r"[?&]page=(\d+)")
SINGLE_SEGMENT = re.compile(r"^/[a-z0-9][a-z0-9\-]*/?$", re.I)

FIELDS = ["sku", "name", "brand", "jumia_category", "price", "old_price", "discount_pct", "is_buyable",
          "rating", "n_ratings", "url", "image", "parse_method"]


# --------------------------------------------------------------------------------------
# Catégories
# --------------------------------------------------------------------------------------


def _single_segment_links(html: str, base_url: str) -> list[tuple[str, str]]:
    soup = BeautifulSoup(html, "lxml")
    host = urlsplit(base_url).netloc
    out, seen = [], set()
    for a in soup.find_all("a", href=True):
        href = urljoin(base_url, a["href"])
        parts = urlsplit(href)
        if parts.netloc != host or parts.query or not SINGLE_SEGMENT.match(parts.path):
            continue
        slug = parts.path.strip("/")
        text = a.get_text(" ", strip=True)
        if slug in seen or not text or slug.endswith(".html"):
            continue
        seen.add(slug)
        out.append((slug, text))
    return out


def discover_categories(fetcher: Fetcher, site_url: str, max_children: int = 40,
                        explore_children: bool = True) -> pd.DataFrame:
    """Arborescence à deux niveaux : menu de la page d'accueil, puis sous-catégories."""
    home = fetcher.get(site_url)
    if not home.ok:
        raise RuntimeError(f"Page d'accueil inaccessible ({home.status or home.error})")
    rows = []
    top = _single_segment_links(home.text, site_url)
    top_slugs = {s for s, _ in top}
    for slug, name in top:
        url = urljoin(site_url, f"/{slug}/")
        rows.append({"slug": slug, "name": name, "parent": None, "depth": 1, "url": url,
                     "allowed": fetcher.allowed(url),
                     "robots_rule": fetcher.robots_for(url).matching_rule(url)})
    if explore_children:
        for r in [r for r in rows if r["allowed"] and category_division(r["name"], r["slug"])]:
            try:
                page = fetcher.get(r["url"])
            except RobotsDisallowed:
                continue
            if not page.ok:
                continue
            n = 0
            for slug, name in _single_segment_links(page.text, r["url"]):
                if slug in top_slugs or any(x["slug"] == slug for x in rows) or n >= max_children:
                    continue
                url = urljoin(site_url, f"/{slug}/")
                rows.append({"slug": slug, "name": name, "parent": r["slug"], "depth": 2, "url": url,
                             "allowed": fetcher.allowed(url),
                             "robots_rule": fetcher.robots_for(url).matching_rule(url)})
                n += 1
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["division_hint"] = [category_division(n, s) for n, s in zip(df["name"], df["slug"])]
    return df


def _repartir_par_division(ok: pd.DataFrame, max_categories: int) -> pd.DataFrame:
    """Prend une catégorie dans chaque division COICOP à tour de rôle.

    Un tri alphabétique suivi d'un `head(25)` ne livre pas un panier mais une
    tranche d'alphabet : sur jumia.com.eg les 25 premiers slugs commençaient tous
    par « a » — air-conditioning, air-fryers, automobile-… — et le panier
    égyptien n'a jamais vu ni alimentation ni habillement. Ailleurs c'étaient les
    « baby-… » qui saturaient le quota. Un indice des prix doit couvrir les
    divisions de la nomenclature, pas les premières lettres du dictionnaire.

    À l'intérieur d'une division, les feuilles passent avant les parents : elles
    sont plus homogènes, donc plus comparables d'une période à l'autre.
    """
    ok = ok.sort_values(["division_hint", "depth", "slug"],
                        ascending=[True, False, True])
    files = {d: list(g.index) for d, g in ok.groupby("division_hint", sort=True)}
    retenues: list = []
    while len(retenues) < max_categories and any(files.values()):
        for division in sorted(files):
            if files[division] and len(retenues) < max_categories:
                retenues.append(files[division].pop(0))
    return ok.loc[retenues].sort_values(["depth", "slug"]).reset_index(drop=True)


def select_categories(cats: pd.DataFrame, wanted="auto", max_categories: int = 25) -> pd.DataFrame:
    """'auto' : catégories autorisées par robots.txt et rattachables au panier de l'IPC."""
    if cats.empty:
        return cats
    ok = cats[cats["allowed"]].copy()
    if wanted == "auto" or not wanted:
        ok = ok[ok["division_hint"].notna()]
        return ok if ok.empty else _repartir_par_division(ok, max_categories)
    wanted = [w.strip("/").lower() for w in (wanted if isinstance(wanted, (list, tuple)) else [wanted])]
    ok = ok[ok["slug"].str.lower().isin(wanted)]
    # Liste explicite : on respecte le choix de l'appelant, feuilles d'abord.
    ok = ok.sort_values(["depth", "slug"], ascending=[False, True])
    return ok.head(max_categories).sort_values(["depth", "slug"]).reset_index(drop=True)


# --------------------------------------------------------------------------------------
# Pages de liste
# --------------------------------------------------------------------------------------


def _find_products(obj) -> list[dict]:
    if isinstance(obj, list) and obj and all(isinstance(x, dict) for x in obj[:3]) \
            and any("sku" in x for x in obj[:3]) and any(("prices" in x or "price" in x) for x in obj[:3]):
        return obj
    if isinstance(obj, dict):
        for v in obj.values():
            found = _find_products(v)
            if found:
                return found
    elif isinstance(obj, list):
        for v in obj:
            found = _find_products(v)
            if found:
                return found
    return []


def _from_store(html: str, base_url: str) -> dict[str, dict]:
    m = STORE_RX.search(html)
    if not m:
        return {}
    try:
        data = json.loads(m.group(1))
    except json.JSONDecodeError:
        return {}
    out = {}
    for p in _find_products(data):
        prices = p.get("prices") or {}
        price = parse_price(prices.get("rawPrice") or prices.get("price") or p.get("price"))
        old = parse_price(prices.get("rawOldPrice") or prices.get("oldPrice") or p.get("oldPrice"))
        rating = p.get("rating") or {}
        sku = str(p.get("sku") or "")
        if not sku or price is None:
            continue
        out[sku] = {
            "sku": sku, "name": p.get("name") or p.get("displayName"), "brand": p.get("brand"),
            "jumia_category": p.get("categories") if isinstance(p.get("categories"), str)
            else " / ".join(p.get("categories") or []),
            "price": price, "old_price": old if old and old > price else None,
            "discount_pct": parse_percent(prices.get("discount")),
            "is_buyable": p.get("isBuyable"),
            "rating": rating.get("average") if isinstance(rating, dict) else None,
            "n_ratings": rating.get("totalRatings") if isinstance(rating, dict) else None,
            "url": urljoin(base_url, p.get("url") or ""), "image": p.get("image"), "parse_method": "store_json",
        }
    return out


def _from_cards(soup: BeautifulSoup, base_url: str) -> dict[str, dict]:
    out = {}
    for art in soup.select("article.prd, article.c-prd"):
        a = art.select_one("a.core") or art.find("a", href=True)
        if not a:
            continue
        url = urljoin(base_url, a.get("href", ""))
        sku = a.get("data-gtm-id") or a.get("data-ga4-item_id") or a.get("data-id") or sku_from_url(url)
        name_el = art.select_one(".name")
        prc_el = art.select_one(".prc")
        old_el = art.select_one(".old")
        disc_el = art.select_one(".bdg._dsct") or art.select_one("._dsct")
        stars_el = art.select_one(".stars")
        rev_el = art.select_one(".rev")
        img = art.select_one("img")
        price = parse_price(prc_el.get_text(" ", strip=True) if prc_el else None) \
            or parse_price(a.get("data-gtm-price") or a.get("data-ga4-price"))
        if not sku or price is None:
            continue
        method = "gtm_attributes" if a.get("data-gtm-name") else "html_text"
        old = parse_price(old_el.get_text(" ", strip=True)) if old_el else None
        n_rat = None
        if rev_el:
            m = re.search(r"\((\d[\d,\s]*)\)", rev_el.get_text(" ", strip=True))
            n_rat = int(re.sub(r"\D", "", m.group(1))) if m else None
        rating = None
        if stars_el:
            m = re.search(r"(\d+(?:[.,]\d+)?)", stars_el.get_text(" ", strip=True))
            rating = float(m.group(1).replace(",", ".")) if m else None
        out[str(sku)] = {
            "sku": str(sku),
            "name": a.get("data-gtm-name") or a.get("data-ga4-item_name") or (name_el.get_text(" ", strip=True) if name_el else None),
            "brand": a.get("data-gtm-brand") or a.get("data-ga4-item_brand"),
            "jumia_category": a.get("data-gtm-category") or a.get("data-ga4-item_category"),
            "price": price, "old_price": old if old and old > price else None,
            "discount_pct": parse_percent(disc_el.get_text(" ", strip=True)) if disc_el else None,
            "is_buyable": None, "rating": rating, "n_ratings": n_rat, "url": url,
            "image": (img.get("data-src") or img.get("src")) if img else None, "parse_method": method,
        }
    return out


def parse_listing(html: str, base_url: str) -> tuple[list[dict], dict]:
    """Produits d'une page de liste + métadonnées (méthode, dernière page, page JS vide ?)."""
    soup = BeautifulSoup(html, "lxml")
    store = _from_store(html, base_url)
    cards = _from_cards(soup, base_url)
    merged = {}
    for sku in list(store) + [s for s in cards if s not in store]:
        row = dict(cards.get(sku, {}))
        for k, v in store.get(sku, {}).items():
            if v not in (None, "", []):
                row[k] = v
        merged[sku] = {f: row.get(f) for f in FIELDS}
    pages = [int(x) for x in PAGE_RX.findall(html)]
    meta = {
        "n_products": len(merged),
        "method": "store_json" if store else ("cards" if cards else "none"),
        "last_page": max(pages) if pages else 1,
        "js_shell": not merged and len(soup.get_text(strip=True)) < 400,
    }
    return list(merged.values()), meta


def parse_product_page(html: str) -> dict:
    """Vendeur, disponibilité et note depuis le JSON-LD d'une fiche produit."""
    soup = BeautifulSoup(html, "lxml")
    out = {"seller": None, "availability": None, "ld_price": None}
    for sc in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(sc.string or "")
        except (json.JSONDecodeError, TypeError):
            continue
        items = data if isinstance(data, list) else [data]
        for d in items:
            if not isinstance(d, dict) or d.get("@type") != "Product":
                continue
            offers = d.get("offers") or {}
            if isinstance(offers, list):
                offers = offers[0] if offers else {}
            seller = offers.get("seller") or {}
            out["seller"] = seller.get("name") if isinstance(seller, dict) else seller
            av = offers.get("availability") or ""
            out["availability"] = av.rsplit("/", 1)[-1] if av else None
            out["ld_price"] = parse_price(offers.get("price"))
    if not out["seller"]:
        m = re.search(r"(?:Vendu par|Sold by)\s*:?\s*([^\n<]{2,60})", soup.get_text("\n"))
        out["seller"] = m.group(1).strip() if m else None
    return out


# --------------------------------------------------------------------------------------
# Collecte
# --------------------------------------------------------------------------------------


@dataclass
class Checkpoint:
    path: Path
    rows_path: Path

    def load(self) -> set:
        if self.path.exists():
            return set(json.loads(self.path.read_text(encoding="utf-8")).get("done", []))
        return set()

    def save(self, done: set) -> None:
        self.path.write_text(json.dumps({"done": sorted(done), "updated": now_utc()}), encoding="utf-8")

    def append_rows(self, rows: list[dict]) -> None:
        with self.rows_path.open("a", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False, default=str) + "\n")

    def read_rows(self) -> list[dict]:
        if not self.rows_path.exists():
            return []
        return [json.loads(l) for l in self.rows_path.read_text(encoding="utf-8").splitlines() if l.strip()]

    def clear(self) -> None:
        for p in (self.path, self.rows_path):
            if p.exists():
                p.unlink()


def collect(fetcher: Fetcher, site, categories: pd.DataFrame, collect_date: str, max_pages: int,
            checkpoint_dir: Path, details_sample: int = 0, use_playwright: bool = False,
            progress: bool = True, collected_at: Optional[str] = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Collecte un relevé daté. Retourne (produits, journal des pages)."""
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    ck = Checkpoint(checkpoint_dir / f"{collect_date}.json", checkpoint_dir / f"{collect_date}.jsonl")
    done = ck.load()
    pages_log = []
    fetcher.cache_tag = collect_date
    collected_at = collected_at or now_utc()
    bar = tqdm(total=len(categories) * max_pages, desc=f"Collecte {collect_date}", disable=not progress)
    for cat in categories.itertuples():
        known_last = [int(k.split("=")[1]) for k in done if k.startswith(f"{cat.slug}|last=")]
        last_page = min([max_pages] + known_last)
        for page in range(1, max_pages + 1):
            key = f"{cat.slug}|{page}"
            if page > last_page:
                bar.update(max_pages - page + 1)
                break
            if key in done:
                bar.update(1)
                continue
            url = cat.url if page == 1 else f"{cat.url}?page={page}"
            entry = {"date": collect_date, "catégorie": cat.slug, "page": page, "url": url}
            try:
                r = fetcher.get(url)
            except RobotsDisallowed as e:
                pages_log.append({**entry, "statut": "interdit (robots.txt)", "produits": 0})
                log.info(str(e))
                bar.update(max_pages - page + 1)
                break
            if not r.ok:
                pages_log.append({**entry, "statut": f"échec {r.status or r.error}", "produits": 0})
                bar.update(max_pages - page + 1)
                break
            products, meta = parse_listing(r.text, url)
            if not products and meta["js_shell"] and use_playwright:
                html = render_with_playwright(url, fetcher.user_agent)
                if html:
                    products, meta = parse_listing(html, url)
                    meta["method"] = "playwright+" + meta["method"]
            for p in products:
                p.update(collect_date=collect_date, collected_at=collected_at, category_slug=cat.slug,
                         category_name=cat.name, category_depth=int(cat.depth), division_hint=cat.division_hint,
                         page=page)
            ck.append_rows(products)
            done.add(key)
            ck.save(done)
            pages_log.append({**entry, "statut": f"HTTP {r.status}" + (" (cache)" if r.from_cache else ""),
                              "produits": len(products), "méthode": meta["method"]})
            bar.update(1)
            last_page = min(max_pages, meta["last_page"])
            done = {k for k in done if not k.startswith(f"{cat.slug}|last=")} | {f"{cat.slug}|last={last_page}"}
            ck.save(done)
            if not products:
                bar.update(max_pages - page)
                break
    bar.close()

    df = pd.DataFrame(ck.read_rows())
    if df.empty:
        return df, pd.DataFrame(pages_log)
    # Un produit peut figurer dans une catégorie et dans sa sous-catégorie : on garde la plus fine.
    df = df.sort_values(["sku", "category_depth"]).drop_duplicates("sku", keep="last")
    df["currency"] = site.currency
    df["country"] = site.iso2
    df["seller"] = None
    df["availability"] = None
    if details_sample:
        sample = df.sample(min(details_sample, len(df)), random_state=0)
        for idx, row in tqdm(sample.iterrows(), total=len(sample), desc="Fiches produit", disable=not progress):
            try:
                r = fetcher.get(row["url"])
            except RobotsDisallowed:
                continue
            if r.ok:
                d = parse_product_page(r.text)
                df.loc[idx, "seller"] = d["seller"]
                df.loc[idx, "availability"] = d["availability"]
    return df.reset_index(drop=True), pd.DataFrame(pages_log)
