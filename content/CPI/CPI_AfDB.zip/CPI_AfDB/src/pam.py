# -*- coding: utf-8 -*-
"""Prix de marché du Programme alimentaire mondial, via l'API HDX HAPI.

Pourquoi cette source plutôt que les régulateurs nationaux
----------------------------------------------------------
Compléter l'e-commerce pays par pays supposait d'écrire un lecteur par
institution : une page de régulateur n'a pas la forme de la suivante. La
prospection du 16/10/2026 a sondé quinze candidates — régulateurs de
l'électricité, opérateurs historiques et instituts de statistique du Nigéria,
du Kenya, du Ghana, de l'Ouganda, de l'Égypte et du Maroc. **Aucune ne rend un
tableau de tarifs exploitable** : trois sont interdites par leur robots.txt,
trois répondent 404 ou 500, les autres servent des pages de présentation sans
le moindre tableau. Le relevé est reproductible par `scripts/prospecter.py`.

La base de prix du PAM couvre 98 pays **au même format**. Un seul lecteur
suffit donc là où il en aurait fallu une quinzaine.

Pourquoi l'API et non le fichier CSV
------------------------------------
Le CSV se télécharge depuis `data.humdata.org`, dont le robots.txt publié
interdit à la fois `/api/` et `/*.csv$`. Nous ne passons pas outre : c'est une
décision d'éditeur, et le projet s'interdit de l'ignorer.

HDX publie pour cela un hôte distinct, **HAPI**, destiné à l'accès
programmatique. Il ne publie aucun robots.txt — aucune restriction ne s'y
applique — et il **exige** que l'appelant s'identifie par son nom et son
courriel. C'est la voie que l'éditeur a construite pour cet usage, et elle
demande exactement la discipline que le projet pratique déjà.

Ce que cette source est, et ce qu'elle n'est pas
-----------------------------------------------
Ce sont des **prix de détail relevés sur les marchés**, mensuels, par marché et
par produit : le complément exact de l'e-commerce, et la réponse à la réserve
« les acheteurs en ligne sont urbains et connectés ». Ce n'est pas un indice,
et ce n'est pas un panier : le PAM relève ce qui compte pour la sécurité
alimentaire, pas ce qui pèse dans un IPC national.
"""
from __future__ import annotations

import base64
import json
import logging
from datetime import date

import pandas as pd

from .officiel import _lire

log = logging.getLogger("jumia_cpi.pam")

HAPI = "https://hapi.humdata.org/api/v2"
PRIX = HAPI + "/food-security-nutrition-poverty/food-prices-market-monitor"
DOC = "https://hdx-hapi.readthedocs.io/"

ATTRIBUTION = ("Source : World Food Programme, via HDX HAPI "
               "(Humanitarian Data Exchange). Licence CC BY-IGO.")

# HAPI identifie les pays en ISO-3.
ISO3 = {"CI": "CIV", "SN": "SEN", "NG": "NGA", "KE": "KEN", "GH": "GHA",
        "UG": "UGA", "EG": "EGY"}

# Le Maroc n'a pas de relevés du PAM — il n'y a pas d'opération dans le pays.
# C'est une absence, pas un défaut de nommage, et le dispositif doit le dire
# plutôt que de rendre un tableau vide.
SANS_RELEVES = {"MA": "le PAM n'a pas d'opération au Maroc"}

PAGE = 10000          # plafond que l'API annonce
COLONNES = {
    "reference_period_start": "date_prix", "market_name": "marche",
    "admin1_name": "region", "commodity_name": "produit", "unit": "unite",
    "price_type": "stade", "currency_code": "unite_monetaire",
    "price": "prix_moyen", "commodity_category": "categorie",
}


def identifiant(nom_app: str, courriel: str) -> str:
    """L'identifiant que HAPI exige : base64(« nom:courriel »).

    L'éditeur demande à savoir qui l'interroge. On le lui dit, avec la même
    adresse que celle inscrite dans le User-Agent.
    """
    brut = "{}:{}".format(nom_app, courriel)
    return base64.b64encode(brut.encode("utf-8")).decode("ascii")


def pays_servis() -> tuple:
    return tuple(sorted(ISO3))


def _depuis_quand(base: dict, stade: str) -> str:
    """Le dernier relevé connu, quand la fenêtre demandée est vide.

    Sert uniquement à rédiger un diagnostic exact : « la série s'arrête en
    juillet 2023 » se corrige, « aucune donnée » laisse chercher.
    """
    try:
        params = {k: v for k, v in base.items() if k != "start_date"}
        params["limit"] = 1
        charge = json.loads(_lire(PRIX, params=params, timeout=60).text)
        lot = charge.get("data") or []
        if not lot:
            return " — ce pays n'est pas relevé par le PAM"
        vu = str(lot[0].get("reference_period_start") or "")[:7]
        # L'échantillon n'est pas trié : il atteste que la série existe, il
        # ne dit pas où elle s'arrête. Ne pas prétendre le contraire.
        return (" — la série existe hors de cette fenêtre (un relevé vu en "
                "{}) : élargissez `mois`".format(vu or "?"))
    except Exception:
        return ""


def collecter_wfp(pays: str = "CI", courriel: str = "", mois: int = 24,
                  stade: str = "Retail", incidents=None) -> pd.DataFrame:
    """Les relevés de prix du PAM pour un pays, sur les `mois` derniers mois.

    `mois` borne volontairement la profondeur : la base remonte à 2000 pour
    certains pays, et un indice n'a pas besoin de vingt ans d'historique pour
    se chaîner. `mois=0` rend tout ce que l'API veut bien donner.
    """
    code = (pays or "").upper()
    if code in SANS_RELEVES:
        raise RuntimeError("aucun relevé du PAM pour « {} » : {}."
                           .format(code, SANS_RELEVES[code]))
    iso3 = ISO3.get(code)
    if not iso3:
        raise ValueError("pays « {} » hors de la base du PAM. Servis : {}."
                         .format(pays, ", ".join(pays_servis())))
    if not courriel:
        raise ValueError(
            "HAPI exige que l'appelant s'identifie : renseignez le courriel "
            "de contact. C'est la condition posée par l'éditeur, pas une "
            "option du projet.")

    base = {"app_identifier": identifiant("jumia-cpi", courriel),
            "location_code": iso3, "output_format": "json", "limit": PAGE}
    if stade:
        # « Retail » est le prix payé par le ménage. « Wholesale » ne l'est
        # pas et n'a rien à faire dans un indice à la consommation.
        base["price_type"] = stade
    if mois:
        depart = pd.Timestamp(date.today()) - pd.DateOffset(months=mois)
        base["start_date"] = depart.strftime("%Y-%m-%d")

    lignes, decalage = [], 0
    while True:
        params = dict(base, offset=decalage)
        reponse = _lire(PRIX, params=params, timeout=90)
        reponse.raise_for_status()
        charge = json.loads(reponse.text)
        lot = charge.get("data", charge if isinstance(charge, list) else [])
        lignes.extend(lot)
        if len(lot) < PAGE:
            break
        decalage += PAGE
        if decalage > 20 * PAGE:      # garde-fou : 200 000 lignes suffisent
            if incidents is not None:
                incidents.append("[pam/{}] arrêt à {} lignes — bornez `mois`"
                                 .format(code.lower(), decalage))
            break

    if not lignes:
        # Une fenêtre vide peut vouloir dire deux choses très différentes :
        # le pays n'est pas relevé, ou sa série s'est arrêtée. On le demande
        # plutôt que de laisser l'exploitant deviner.
        raise RuntimeError("aucun relevé « {} » pour {} sur les {} derniers "
                           "mois{}".format(stade, code, mois,
                                           _depuis_quand(base, stade)))

    brut = pd.DataFrame(lignes)
    manquantes = [c for c in COLONNES if c not in brut.columns]
    if manquantes:
        raise RuntimeError("HAPI a changé de forme : colonnes absentes {}. "
                           "Voir {}".format(", ".join(manquantes), DOC))

    table = brut[list(COLONNES)].rename(columns=COLONNES)
    table["date_prix"] = pd.to_datetime(table["date_prix"], errors="coerce")
    table["prix_moyen"] = pd.to_numeric(table["prix_moyen"], errors="coerce")
    avant = len(table)
    table = table.dropna(subset=["date_prix", "prix_moyen", "produit"])
    table = table.sort_values("date_prix")
    table["date_prix"] = table["date_prix"].dt.strftime("%Y-%m-%d")

    if incidents is not None:
        incidents.append(
            "[pam/{}] {} relevé(s) « {} » sur {} rendus — {} marché(s), "
            "{} produit(s), du {} au {}".format(
                code.lower(), len(table), stade, avant,
                table["marche"].nunique(), table["produit"].nunique(),
                table["date_prix"].min(), table["date_prix"].max()))
    return table.reset_index(drop=True)
