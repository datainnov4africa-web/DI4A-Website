# -*- coding: utf-8 -*-
"""Prix administrés et institutionnels — ce que l'e-commerce ne peut pas voir.

Pourquoi ce module
------------------
Un panier de prix à la consommation compte treize divisions COICOP. Une
collecte en ligne en atteint cinq : l'alimentaire, l'habillement, l'équipement
ménager, l'information-communication et les soins personnels. **Huit divisions
restent hors de portée** — et avec elles l'essentiel de ce qu'un ménage dépense
vraiment.

Deux d'entre elles sont pourtant publiées, et par les institutions elles-mêmes.

* **Division 04** — logement, eau, électricité, gaz. Les tarifs d'électricité
  sont **administrés** : il n'y a pas de marché à relever, ils sont arrêtés et
  publiés. L'ANARE en Côte d'Ivoire et la CRSE au Sénégal les mettent en ligne.
* **Division 01** — alimentaire, mais relevé sur les **marchés réels** et non
  en ligne. L'OCPV publie des prix de détail, de gros et de bord-champ par
  marché ; Sikafinance publie quatre-vingts produits dans six villes. C'est le
  complément exact de Jumia : mêmes produits, autre circuit, autres acheteurs —
  et c'est ce qui répond à la réserve « les acheteurs en ligne sont urbains et
  connectés ».

Une troisième source ne publie pas des prix mais un **indice déjà construit** :
l'ARTP sénégalaise publie l'indice des prix des services mobiles, base 100 en
2023 — la même base que l'IHPC officiel. La division 08 pèse **7,46 % du panier
sénégalais** et aucune collecte marchande ne peut la mesurer : les opérateurs
vendent des forfaits dont le prix unitaire n'a pas de sens sans profil de
consommation.

Ce qui reste hors d'atteinte
----------------------------
Quatre divisions, et aucune source ne les couvre : **07** transports, **10**
enseignement, **11** restauration et hébergement, **12** assurances. Elles
demandent un relevé de terrain ou un échange institutionnel. Le dire vaut mieux
que de laisser croire à une couverture complète.

Lecture et politesse
--------------------
Tout passe par le `Fetcher` du projet : robots.txt analysé selon la RFC 9309,
délai adaptatif, reprises, cache disque, et réparation de chaîne de certificats
pour les sites qui omettent leur intermédiaire. Aucune requête n'est émise ici
en dehors de lui.

Origine
-------
Ces lecteurs viennent du projet `ihpc-cae`, où ils tournent en production sur
quatre pays. Les constats chiffrés qu'ils portent en commentaire — la fenêtre
de l'OCPV, la forme large de Sikafinance, les deux pièges de la note ARTP — ont
été établis sur les publications réelles, pas supposés.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta

import pandas as pd

from .fetch import Fetcher

log = logging.getLogger("jumia_cpi.officiel")


def _lire(url: str, params: dict | None = None, fetcher: Fetcher | None = None,
          timeout: int = 45):
    """GET par le Fetcher du projet. Rend un objet au contrat de `requests`.

    Les lecteurs repris d'`ihpc-cae` attendent une reponse `requests` : on leur
    en presente une, pour ne pas avoir a les reecrire. Le Fetcher, lui, apporte
    le robots.txt, le delai, le cache et la reparation de chaine TLS.
    """
    fetcher = fetcher or _FETCHER[0]
    if fetcher is None:
        raise RuntimeError("aucun Fetcher : appelez `preparer(fetcher)` d'abord.")
    adresse = url
    if params:
        from urllib.parse import urlencode
        adresse = "{}{}{}".format(url, "&" if "?" in url else "?", urlencode(params))
    reponse = fetcher.get(adresse, use_cache=False)

    class _Reponse:
        status_code = reponse.status or 0
        text = reponse.text or ""
        url = reponse.url
        # Les octets bruts si le transport les porte ; sinon, le texte
        # re-encode. Pour un PDF, seuls les premiers conviennent.
        content = getattr(reponse, "octets", b"") or (
            reponse.text or "").encode("utf-8", "replace")

        def raise_for_status(self):
            if not (200 <= self.status_code < 300):
                raise RuntimeError("HTTP {} sur {}".format(self.status_code, adresse))

    return _Reponse()


_FETCHER = [None]


def preparer(fetcher: Fetcher) -> None:
    """Fixe le Fetcher employe par tous les lecteurs de ce module."""
    _FETCHER[0] = fetcher



def _autorise(url: str) -> bool:
    """Le robots.txt du site autorise-t-il cette adresse.

    Le contrôle passe par le Fetcher du projet, qui analyse le fichier selon la
    RFC 9309 — jokers compris. C'est le même contrôle que pour les sources
    marchandes : une publication institutionnelle n'est pas une dispense.
    """
    fetcher = _FETCHER[0]
    if fetcher is None:
        raise RuntimeError("aucun Fetcher : appelez `preparer(fetcher)` d'abord.")
    return fetcher.allowed(url)


def soupe(html: str):
    """Analyse un document HTML, avec un parseur de secours.

    `lxml` abandonne en cours de document sur certains HTML mal formes, **sans
    lever d'exception** : l'arbre rendu ressemble alors a une page valide dont
    les selecteurs ne trouvent rien. On compare donc le nombre d'elements
    obtenus au nombre de balises, et on relit avec le parseur tolerant quand
    l'ecart est manifeste.
    """
    from bs4 import BeautifulSoup

    try:
        arbre = BeautifulSoup(html, "lxml")
    except Exception:
        return BeautifulSoup(html, "html.parser")
    balises = html.count("<")
    if balises < 40:
        return arbre
    obtenus = len(arbre.find_all(True))
    if obtenus >= balises * 0.25:
        return arbre
    secours = BeautifulSoup(html, "html.parser")
    return secours if len(secours.find_all(True)) > obtenus else arbre


# ----------------------------------------------------------------------------
# CONSTANTES
SCHEMA_RELEVE = [
    "date_collecte", "source", "date_prix", "stade", "marche", "ville",
    "produit", "unite", "prix_min", "prix_moyen", "prix_max", "unite_monetaire",
]

# Stades de commercialisation de l'OCPV. Seul « detail » releve d'un indice des
# prix a la consommation ; les deux autres sont conserves parce qu'ils eclairent
# la formation du prix.
STADES = {
    "detail": "tableauprix_details",
    "gros": "tableauprix_gros",
    "bord_champ": "tableauprix",
}

OCPV = "https://infoprixocpv.com/"
SIKAFINANCE = "https://www.sikafinance.com/conso/liste_des_prix"
ANARE_TARIFS = "https://anare.ci/le-marche/prix-de-lelectricite/"

# Villes couvertes par le tableau de Sikafinance, dans l'ordre des colonnes.
VILLES_SIKA = ("Abidjan", "Bouaké", "Korhogo", "Man", "San-Pédro", "Yamoussoukro")

_MAGASINS = {}


# ----------------------------------------------------------------------------
# LECTURE

def lire_tableau(html: str, selecteur: str) -> list:
    """Transforme un tableau HTML en liste de dictionnaires.

    Les en-tetes servent de cles. Une ligne dont le nombre de cellules ne
    correspond pas a l'en-tete est ignoree : c'est le plus souvent une ligne
    « aucun resultat » ou une ligne de total.
    """
    from bs4 import BeautifulSoup

    table = soupe(html).select_one(selecteur)
    if table is None:
        return []

    lignes = table.select("tr")
    if not lignes:
        return []
    entetes = [" ".join(c.get_text(" ", strip=True).split())
               for c in lignes[0].select("th,td")]

    sortie = []
    for ligne in lignes[1:]:
        cellules = [" ".join(c.get_text(" ", strip=True).split())
                    for c in ligne.select("td")]
        if len(cellules) != len(entetes) or not any(cellules):
            continue
        sortie.append(dict(zip(entetes, cellules)))
    return sortie


def nombre(texte):
    """Lit un montant ivoirien : espaces de milliers, virgule decimale."""
    if texte is None:
        return float("nan")
    propre = re.sub(r"[^\d,.\-]", "", str(texte)).replace(" ", "")
    if not propre or propre in ("-", ".", ","):
        return float("nan")
    # Une virgule suivie de 1 ou 2 chiffres est une decimale ; sinon un millier.
    if re.search(r",\d{1,2}$", propre):
        propre = propre.replace(".", "").replace(",", ".")
    else:
        propre = propre.replace(",", "").replace(" ", "")
    try:
        return float(propre)
    except ValueError:
        return float("nan")


def _unite_du_libelle(libelle: str):
    """« SUCRE BLANC (kg) » -> ("SUCRE BLANC", "kg")."""
    trouve = re.search(r"\(([^)]{1,18})\)\s*$", libelle or "")
    if not trouve:
        return (libelle or "").strip(), ""
    return libelle[:trouve.start()].strip(), trouve.group(1).strip().lower()


def cadrer(lignes: list) -> pd.DataFrame:
    df = pd.DataFrame(lignes)
    for colonne in SCHEMA_RELEVE:
        if colonne not in df.columns:
            df[colonne] = None
    return df[SCHEMA_RELEVE]


# ---------------------------------------------------------------------- OCPV

# Fenetre interrogee quand l'appelant n'en fixe aucune. Sans intervalle, la
# plateforme ne rend que 194 lignes ; sur un an, plus de deux mille, et sur des
# couples marche-produit tous distincts. Le filtre elargit la couverture au lieu
# de la restreindre - l'inverse de ce qu'on attendrait.

# ----------------------------------------------------------------------------
# OCPV
FENETRE_OCPV_JOURS = 365

# Une page vide ne suffit pas a conclure a la fin de la pagination : la
# plateforme en intercale de temps a autre. Le 05/10/2026, s'arreter a la
# premiere a ramene 20 releves au lieu de 194.
PAGES_VIDES_AVANT_ARRET = 3


def collecter_ocpv(stade: str = "detail", pages_max: int = 400,
                   depuis: str = "", jusqu_a: str = "",
                   incidents=None) -> pd.DataFrame:
    """Releves de l'OCPV pour un stade de commercialisation.

    La plateforme pagine par dix et accepte un intervalle de dates. Faute
    d'intervalle fourni, on interroge la derniere annee : c'est ce qui donne la
    couverture la plus large, et non le contraire.

    L'arret se fait sur plusieurs pages vides consecutives, pas sur
    ``pages_max`` : le volume varie d'un mois a l'autre, demander des pages qui
    n'existent pas coute au site sans rien rapporter, et une page vide isolee
    n'est pas la fin.
    """

    if stade not in STADES:
        raise ValueError("stade inconnu : {} (attendus : {})".format(
            stade, ", ".join(STADES)))
    incidents = incidents if incidents is not None else []
    url = OCPV + STADES[stade]

    if not _autorise(url):
        incidents.append("{} : exclu par robots.txt".format(url))
        return cadrer([])

    from datetime import timedelta

    aujourd_hui = date.today().isoformat()
    # La fenetre par defaut sert a interroger, pas a dater : la plateforme ne
    # donne pas de date ligne par ligne, et presenter ces prix comme ceux du
    # dernier jour de la fenetre serait une affirmation qu'elle ne soutient pas.
    fenetre_debut = depuis or (
        date.today() - timedelta(days=FENETRE_OCPV_JOURS)).isoformat()
    fenetre_fin = jusqu_a or aujourd_hui
    lignes, echecs, vides = [], 0, 0

    for page in range(1, pages_max + 1):
        params = {"page": page, "dateDebut": fenetre_debut,
                  "dateFin": fenetre_fin}
        try:
            reponse = _lire(url, params=params)
            reponse.raise_for_status()
        except Exception as erreur:
            echecs += 1
            incidents.append("[ocpv] page {} : {}".format(page, erreur))
            if echecs >= 3:
                incidents.append("[ocpv] pagination interrompue apres 3 echecs")
                break
            continue

        brutes = lire_tableau(reponse.text, "table#example")
        if not brutes:
            vides += 1
            if vides >= PAGES_VIDES_AVANT_ARRET:
                break                  # fin de la pagination, cette fois sure
            continue
        vides = 0

        for brute in brutes:
            produit, unite = _unite_du_libelle(brute.get("Produit", ""))
            lignes.append({
                "date_collecte": aujourd_hui,
                "source": "ocpv",
                "date_prix": jusqu_a or "",
                "stade": stade,
                # Le tableau « bord champ » n'a pas de colonne Marche.
                "marche": brute.get("Marche", ""),
                "ville": "",
                "produit": produit,
                "unite": unite,
                "prix_min": nombre(brute.get("Prix Mini")),
                "prix_moyen": nombre(brute.get("Prix Moyen")),
                "prix_max": nombre(brute.get("Prix Maxi")),
                "unite_monetaire": "XOF",
            })

    return cadrer(lignes)


# --------------------------------------------------------------- Sikafinance


# ----------------------------------------------------------------------------
# SIKAFINANCE
def collecter_sikafinance(incidents=None) -> pd.DataFrame:
    """Prix de grande consommation dans six villes.

    Le tableau est en forme large - une colonne par ville - et chaque ligne
    porte **sa propre date de releve**. Ces dates s'echelonnent sur plusieurs
    annees : filtrer sur ``date_prix`` n'est pas une precaution, c'est une
    condition de validite.
    """
    incidents = incidents if incidents is not None else []

    if not _autorise(SIKAFINANCE):
        incidents.append("{} : exclu par robots.txt".format(SIKAFINANCE))
        return cadrer([])

    try:
        reponse = _lire(SIKAFINANCE)
        reponse.raise_for_status()
    except Exception as erreur:
        incidents.append("[sikafinance] {}".format(erreur))
        return cadrer([])

    aujourd_hui = date.today().isoformat()
    lignes = []
    for brute in lire_tableau(reponse.text, "table#tblconso"):
        produit, unite = _unite_du_libelle(brute.get("Produit", ""))
        jour = _date_courte(brute.get("Date prix", ""))
        for ville in VILLES_SIKA:
            valeur = nombre(brute.get(ville))
            if pd.isna(valeur):
                continue               # la ville n'a pas releve ce produit
            lignes.append({
                "date_collecte": aujourd_hui,
                "source": "sikafinance",
                "date_prix": jour,
                "stade": "detail",
                "marche": "",
                "ville": ville,
                "produit": produit,
                "unite": unite,
                "prix_min": valeur,
                "prix_moyen": valeur,
                "prix_max": valeur,
                "unite_monetaire": "XOF",
            })
    return cadrer(lignes)


def _date_courte(texte: str) -> str:
    """« 19/07/26 » -> « 2026-07-19 ». Rend la chaine brute si elle resiste."""
    try:
        return datetime.strptime(texte.strip(), "%d/%m/%y").date().isoformat()
    except (ValueError, AttributeError):
        return (texte or "").strip()


# ------------------------------------------------------- tarifs d'electricite

@dataclass(frozen=True)
class Tarif:
    categorie: str
    designation: str
    ht: float
    tva: float
    ttc: float



# ----------------------------------------------------------------------------
# ANARE
def tarifs_electricite(incidents=None) -> pd.DataFrame:
    """Tarifs d'electricite publies par l'ANARE-CI, le regulateur du secteur.

    Prix administres : ils sont publies, pas releves. La page en porte une
    vingtaine de tableaux, un par categorie tarifaire, avec le prix hors taxe,
    la TVA et le prix toutes taxes comprises.
    """
    from bs4 import BeautifulSoup

    incidents = incidents if incidents is not None else []
    try:
        reponse = _lire(ANARE_TARIFS)
        reponse.raise_for_status()
    except Exception as erreur:
        incidents.append("[anare] {}".format(erreur))
        return pd.DataFrame(columns=["categorie", "designation", "ht", "tva", "ttc"])

    arbre = soupe(reponse.text)
    lignes = []
    for table in arbre.select("table"):
        rangs = table.select("tr")
        if not rangs:
            continue
        entete = [" ".join(c.get_text(" ", strip=True).split())
                  for c in rangs[0].select("th,td")]
        if not entete:
            continue
        categorie = entete[0]
        # Un tableau de tarifs porte trois colonnes de montants ; les autres
        # sont des exemples de facture, a la structure differente.
        if len(entete) < 4:
            continue
        for rang in rangs[1:]:
            cellules = [" ".join(c.get_text(" ", strip=True).split())
                        for c in rang.select("td")]
            if len(cellules) < 4 or not cellules[0]:
                continue
            lignes.append({
                "categorie": categorie,
                "designation": cellules[0],
                "ht": nombre(cellules[1]),
                "tva": nombre(cellules[2]),
                "ttc": nombre(cellules[3]),
            })
    return pd.DataFrame(lignes, columns=["categorie", "designation", "ht", "tva", "ttc"])


def grille(table) -> list:
    """Developpe un tableau HTML fusionne en grille rectangulaire.

    ``lire_tableau`` suppose que chaque ligne porte autant de cellules que
    l'en-tete. Les tableaux tarifaires ne respectent jamais cette regle : une
    categorie couvre huit lignes par ``rowspan``, un prix unique couvre trois
    tranches par ``colspan``. Lues naivement, ces lignes se decalent et les
    prix atterrissent sous la mauvaise colonne - sans erreur, avec des chiffres
    plausibles.

    On reconstruit donc la grille que le navigateur affiche : une cellule
    fusionnee est recopiee dans chaque case qu'elle occupe. Un ``colspan`` sur
    un prix signifie bien que ce prix vaut pour chacune des tranches couvertes.
    """
    occupe: dict = {}
    lignes = []
    for rangee, tr in enumerate(table.select("tr")):
        colonne = 0
        courante = []
        for cellule in tr.find_all(["th", "td"], recursive=False):
            while (rangee, colonne) in occupe:
                courante.append(occupe.pop((rangee, colonne)))
                colonne += 1
            texte = " ".join(cellule.get_text(" ", strip=True).split())
            try:
                hauteur = max(1, int(cellule.get("rowspan") or 1))
                largeur = max(1, int(cellule.get("colspan") or 1))
            except (TypeError, ValueError):
                hauteur = largeur = 1
            for dy in range(hauteur):
                for dx in range(largeur):
                    if dy == 0 and dx == 0:
                        continue
                    occupe[(rangee + dy, colonne + dx)] = texte
            for _ in range(largeur):
                courante.append(texte)
                colonne += 1
        while (rangee, colonne) in occupe:
            courante.append(occupe.pop((rangee, colonne)))
            colonne += 1
        lignes.append(courante)

    largeur = max((len(l) for l in lignes), default=0)
    return [l + [""] * (largeur - len(l)) for l in lignes]


# ------------------------------------------------------------------- STEG


# ----------------------------------------------------------------------------
# CRSE

CRSE_ELECTRICITE = "https://www.crse.sn/secteurs/secteur-electricite/"

COLONNES_CRSE = ["segment", "categorie", "tranche", "unite", "prix",
                 "prime_fixe", "bareme"]

# Une colonne de prix de l'energie se reconnait a son en-tete de second
# niveau : une tranche de consommation, ou un poste horaire.
MOTIF_COLONNE_PRIX = re.compile(r"tranche|heures?\s", re.I)


def _bareme(table) -> str:
    """Intitule qui precede le tableau : « Basse Tension Generale », etc.

    Sans lui, deux baremes aux memes libelles de secteur se confondraient —
    et leurs prix seraient apparies d'un mois sur l'autre alors qu'ils ne
    designent pas la meme chose.
    """
    precedent = table.find_previous(["h1", "h2", "h3", "h4", "strong"])
    if precedent is None:
        return ""
    return " ".join(precedent.get_text(" ", strip=True).split())[:80]


def _colonne(entetes: list, termes: tuple):
    """Rang de la premiere colonne dont l'en-tete contient l'un des termes.

    Rend `None` quand aucune ne correspond : la grille du regulateur ne porte
    pas toujours de prime fixe, et son absence n'est pas une erreur. Ce
    petit utilitaire manquait — il etait reste dans `ihpc-cae` lors de
    l'extraction des lecteurs, et le defaut n'est apparu qu'a la premiere
    collecte reelle, le 19/10/2026.
    """
    for rang, entete in enumerate(entetes):
        texte = (entete or "").lower()
        if any(terme in texte for terme in termes):
            return rang
    return None


def _est_ligne_de_section(rangee: list) -> bool:
    """Une rangee qui ne porte qu'un intitule, repete sur toute sa largeur.

    La CRSE ouvre chaque bloc ainsi : « Usage Domestique (UD) » occupe les
    cinq colonnes par un colspan. Une fois la grille developpee, la valeur est
    recopiee partout - c'est justement ce qui permet de la reconnaitre.
    """
    remplies = [c for c in rangee if c.strip()]
    if len(remplies) < 2:
        return False
    return len(set(remplies)) == 1 and nombre(remplies[0]) != nombre(remplies[0])


def collecter_crse(incidents=None) -> pd.DataFrame:
    """Grille tarifaire de l'electricite publiee par la CRSE, au Senegal.

    Prix administres, comme l'ANARE en Cote d'Ivoire et la STEG en Tunisie :
    ils sont publies, pas releves. Ils comptent parce que l'electricite releve
    de la division 04 de la NCOA, qui pese 9,16 % du panier senegalais, et
    qu'aucune collecte marchande ne peut les atteindre.

    La Commission de Regulation du Secteur de l'Electricite regule aussi
    l'aval des hydrocarbures, mais ses structures de prix des carburants sont
    servies par une liste chargee en JavaScript : elles ne sont pas lues ici.
    """

    incidents = incidents if incidents is not None else []
    if not _autorise(CRSE_ELECTRICITE):
        incidents.append("[crse] robots.txt ecarte " + CRSE_ELECTRICITE)
        return pd.DataFrame(columns=COLONNES_CRSE)

    try:
        reponse = _lire(CRSE_ELECTRICITE, timeout=90)
        reponse.raise_for_status()
    except Exception as erreur:
        incidents.append("[crse] {}".format(erreur))
        return pd.DataFrame(columns=COLONNES_CRSE)

    arbre = soupe(reponse.text)
    lignes = []
    for table in arbre.select("table"):
        cases = grille(table)
        if len(cases) < 3:
            continue
        haut, bas = cases[0], cases[1]
        # Seules les grilles tarifaires nous interessent : la page porte aussi
        # les tranches en kWh et les chiffres cles du secteur, qui ne sont pas
        # des prix.
        if not any("prix de l" in c.lower() for c in haut):
            continue
        entetes = [(b or h) for h, b in zip(haut, bas)]
        colonnes_prix = [i for i, e in enumerate(entetes)
                         if MOTIF_COLONNE_PRIX.search(e or "")]
        if not colonnes_prix:
            continue
        colonne_prime = _colonne(entetes, ("prime fixe",))
        bareme = _bareme(table)

        segment = ""
        for rangee in cases[2:]:
            if _est_ligne_de_section(rangee):
                segment = rangee[0]
                continue
            categorie = rangee[0].strip()
            if not categorie or categorie == entetes[0]:
                continue
            prime = nombre(rangee[colonne_prime]) if colonne_prime is not None else float("nan")
            for i in colonnes_prix:
                montant = nombre(rangee[i])
                if montant != montant:      # NaN : cellule vide ou « - »
                    continue
                lignes.append({
                    "segment": segment,
                    "categorie": categorie,
                    "tranche": entetes[i],
                    "unite": "FCFA/kWh",
                    "prix": montant,
                    "prime_fixe": prime,
                    "bareme": bareme,
                })
    return pd.DataFrame(lignes, columns=COLONNES_CRSE).drop_duplicates()


# --------------------------------------------------- description declarative
#
# L'ecran Sources et la commande `ihpc scraping verifier` listent les sources
# de `sources.py`. Celles-ci ont une autre forme - un tableau au lieu de cartes
# produit - mais elles doivent figurer aux memes endroits : une source qu'on
# collecte sans la montrer finit par etre oubliee, et son selecteur casse sans
# que personne ne le voie.


# Categories admises pour une source en tableau. Declarees ici plutot que
# figees dans un test : ajouter une categorie doit etre un geste deliberé a un
# seul endroit, et le garde-fou contre la faute de frappe reste en place.
#
#   prix        - prix de detail releves par une institution (OCPV, Sikafinance)
#   administres - tarifs fixes par decision publique (ANARE, STEG, CRSE)
#   indices     - un indice deja agrege, publie par l'institution (IPSM)
#   loyers      - loyers, si une institution venait a en publier

# ----------------------------------------------------------------------------
# IPSM

ARTP = "https://www.artp.sn"
IPSM_PAGE = ARTP + "/indice-des-prix-des-services-mobiles-ispm"

# Les quatre operateurs du marche mobile senegalais, plus la ligne d'ensemble.
# Les nommer evite de prendre pour une ligne de donnees un fragment de phrase
# qui ressemblerait a un tableau.
IPSM_LIGNES = ("ORANGE", "YAS", "EXPRESSO", "PROMOBILE", "IPSM GLOBAL",
               "IDM GLOBAL")

# Ecart tolere entre l'indice d'ensemble publie et la somme ponderee des
# operateurs. Un pour mille : les indices sont publies a une decimale, et les
# ponderations a une decimale aussi, ce qui borne l'arrondi cumule.
IPSM_ECART_TOLERE = 0.001


def _texte_pdf(contenu: bytes) -> str:
    """Texte d'un PDF, aplati.

    Deux lecteurs sont acceptes. `pdfplumber` d'abord : c'est celui que le
    carnet 2 installe, et il lit mieux les tableaux. `pypdf` ensuite, s'il se
    trouve la. Le message d'erreur nommait auparavant un paquet d'`ihpc-cae`
    qui n'existe pas dans ce projet — il envoyait donc chercher une solution
    introuvable.
    """
    import io as _io

    try:
        import pdfplumber

        with pdfplumber.open(_io.BytesIO(contenu)) as doc:
            return " ".join(" ".join((page.extract_text() or "").split())
                            for page in doc.pages)
    except ImportError:
        pass

    try:
        import pypdf
    except ImportError as erreur:                      # pragma: no cover
        raise RuntimeError(
            "La lecture des notes en PDF demande pdfplumber : "
            "python -m pip install pdfplumber. Detail : {}".format(erreur)
        ) from erreur

    lecteur = pypdf.PdfReader(_io.BytesIO(contenu))
    return " ".join(" ".join((page.extract_text() or "").split())
                    for page in lecteur.pages)


def note_ipsm_la_plus_recente() -> dict:
    """Adresse de la derniere note IPSM, lue sur la page qui les publie.

    On ne devine pas l'adresse. Le fichier porte le trimestre dans son nom et
    le mois de publication dans son chemin
    (``/sites/default/files/2026-08/NOTE IPSM T2 2026_0.pdf``) : un suffixe
    ``_0`` et un dossier mensuel qu'aucune regle ne permet de reconstruire.

    Le certificat de ``artp.sn`` omet son intermediaire, d'ou l'usage de
    :func:`lire` plutot que d'une session ordinaire. La verification TLS n'est
    pas desactivee : l'intermediaire est recupere a l'adresse que le certificat
    declare lui-meme.
    """
    from urllib.parse import urljoin

    reponse = _lire(IPSM_PAGE, timeout=45)
    reponse.raise_for_status()
    arbre = soupe(reponse.text)
    candidates = []
    for lien in arbre.select("a[href]"):
        adresse = lien.get("href") or ""
        if not adresse.lower().endswith(".pdf"):
            continue
        if "ipsm" not in adresse.lower() and "ipsm" not in lien.get_text().lower():
            continue
        candidates.append({
            "url": urljoin(IPSM_PAGE, adresse),
            "libelle": " ".join(lien.get_text(" ", strip=True).split())[:160],
        })
    if not candidates:
        raise ValueError(
            "aucune note IPSM liee sur {} : la page a change de forme".format(
                IPSM_PAGE))
    return candidates[0]


def _lignes_tableau_ipsm(zone: str, trimestres: list, intitule: str,
                         numero: str) -> list:
    """Lignes d'un tableau d'annexe, pour les trimestres de son en-tete."""
    # Motif d'un nombre a la francaise. Nomme `forme_nombre` et non
    # `nombre` : ce module expose deja une fonction `nombre()`, et la
    # masquer la rendait inappelable dans la meme portee.
    forme_nombre = r"-?\d{1,3}(?:,\d{1,2})?"
    motif = re.compile(
        r"(" + "|".join(IPSM_LIGNES) + r"|\b[1-9]\b)\s+"
        r"(" + forme_nombre + r")%\s+"
        + r"\s+".join("(" + forme_nombre + ")" for _ in trimestres))
    lignes = []
    for trouve in motif.finditer(zone):
        groupes = trouve.groups()
        libelle = groupes[0]
        for trimestre, valeur in zip(trimestres, groupes[2:]):
            lignes.append({
                "tableau": numero,
                "intitule": intitule,
                "serie": libelle if libelle in IPSM_LIGNES
                         else "profil " + libelle,
                "ponderation_pct": nombre(groupes[1]),
                "trimestre": trimestre,
                "indice": nombre(valeur),
            })
    return lignes


def collecter_ipsm(incidents=None) -> pd.DataFrame:
    """Indice des Prix des Services Mobiles du Senegal, publie par l'ARTP.

    Pourquoi cette source compte
    ----------------------------
    La division 08 « information et communication » pese **7,46 % du panier
    senegalais** et aucune source ne l'atteignait : les operateurs vendent des
    forfaits dont le prix unitaire n'a pas de sens sans un profil de
    consommation, et les boutiques en ligne ne vendent que des terminaux.

    L'ARTP calcule exactement ce qui manquait : un indice de **Laspeyres, base
    100 en 2023** - la meme base que l'IHPC officiel senegalais, donc
    comparable sans raccord - pondere par les depenses des clients, sur neuf
    profils de consommation. La note l'ecrit elle-meme parmi ses objectifs :
    « pour les instituts nationaux de statistiques : disposer d'un indicateur
    plus pertinent sur les services de telephonie mobile notamment pour le
    calcul de l'inflation ».

    Ce n'est pas une source tierce : la note porte « Source : ARTP et Donnees
    operateurs, Analyse Bureaux des prix, **ANSD** » et nomme le comite de
    production de l'ANSD - l'institut dont ce projet lit deja l'IHPC officiel.

    Deux pieges, tous deux du genre qui donne des valeurs plausibles et fausses
    ---------------------------------------------------------------------------
    La note publie **deux** indices : l'IPSM, a volumes figes a 2023, qui
    isole l'effet prix ; et l'IDM, l'indice de depense minimale, dont les
    volumes sont actualises chaque trimestre et qui melange donc prix et
    volume. Les deux tableaux sont internement coherents et rien dans les
    chiffres ne dit lequel est lequel : au deuxieme trimestre 2026, ORANGE vaut
    72,0 en IPSM et 76,2 en IDM. Pour un indice des prix, c'est l'IPSM. La
    lecture est donc **ancree sur les intitules des tableaux**, pas sur un
    balayage du document.

    Les tableaux par operateur repetent la ligne d'ensemble de l'operateur :
    un balayage global rendait treize lignes la ou le tableau 1 en a cinq.

    Cadence
    -------
    Trimestrielle, diffusee au plus tard quarante-cinq jours apres la fin du
    trimestre. C'est plus grossier qu'un indice mensuel, et cela se dit : la
    valeur rendue vaut pour le trimestre, pas pour un mois.
    """
    note = note_ipsm_la_plus_recente()
    reponse = _lire(note["url"], timeout=90)
    reponse.raise_for_status()
    texte = _texte_pdf(reponse.content)

    morceaux = texte.split("ANNEXE", 1)
    if len(morceaux) < 2:
        raise ValueError(
            "la note {} ne porte pas d'annexe : les tableaux chiffres y sont, "
            "les graphiques du corps ne sont pas lisibles".format(note["url"]))
    zone = morceaux[-1]

    bornes = list(re.finditer(
        r"Tableau\s+(\d+)\s*:\s*(.{0,90}?)(?=\s+(?:Op[eé]rateurs|Profils))",
        zone))
    if not bornes:
        raise ValueError(
            "aucun intitule « Tableau N : » dans l'annexe de {}".format(
                note["url"]))

    lignes = []
    for rang, borne in enumerate(bornes):
        debut = borne.end()
        fin = bornes[rang + 1].start() if rang + 1 < len(bornes) else len(zone)
        segment = zone[debut:fin]
        intitule = " ".join(borne.group(2).split())
        trimestres = re.findall(r"T\d-\d{2}", segment[:260])
        if not trimestres:
            if incidents is not None:
                incidents.append(
                    "[ipsm] tableau {} sans trimestre en en-tete : {}".format(
                        borne.group(1), intitule[:60]))
            continue
        lignes.extend(_lignes_tableau_ipsm(segment, trimestres, intitule,
                                           borne.group(1)))

    if not lignes:
        raise ValueError(
            "annexe lue mais aucune ligne reconnue dans {}".format(note["url"]))

    df = pd.DataFrame(lignes)
    # Nommer l'indice dans une colonne, plutot que de laisser l'utilisateur
    # chercher « IPSM » dans un intitule. Les deux indices ne mesurent pas la
    # meme chose et les confondre donne des valeurs plausibles et fausses :
    # l'IPSM isole l'effet prix, l'IDM y melange l'effet volume.
    df["indice_type"] = df["intitule"].str.contains(
        "IDM", case=False, na=False).map({True: "IDM", False: "IPSM"})
    df["source_note"] = note["libelle"]
    df["url_note"] = note["url"]
    # L'indice est l'information ; `prix` existe pour que les ecrans et les
    # controles de qualite, qui cherchent une colonne de montant, trouvent
    # quelque chose plutot que de conclure « aucun montant ».
    df["prix"] = df["indice"]
    df["unite"] = "indice base 100 = 2023"

    for souci in verifier_coherence_ipsm(df):
        if incidents is not None:
            incidents.append(souci)
    return df


def verifier_coherence_ipsm(df) -> list:
    """L'indice d'ensemble doit retrouver la somme ponderee des operateurs.

    Controle arithmetique, pas de precision : il attrape une ponderation mal
    lue ou une colonne decalee d'un cran - l'erreur la plus facile a commettre
    sur un tableau aplati par l'extraction PDF, et la plus difficile a voir,
    puisque toutes les valeurs restent du bon ordre de grandeur.
    """
    souffrances = []
    tableau_un = df[df["tableau"] == "1"]
    if tableau_un.empty:
        return ["[ipsm] tableau 1 absent : rien a recouper"]
    operateurs = tableau_un[tableau_un["serie"].isin(
        ("ORANGE", "YAS", "EXPRESSO", "PROMOBILE"))]
    ensembles = tableau_un[tableau_un["serie"] == "IPSM GLOBAL"]
    for trimestre in sorted(ensembles["trimestre"].unique()):
        lot = operateurs[operateurs["trimestre"] == trimestre]
        publie = ensembles[ensembles["trimestre"] == trimestre]["indice"]
        if lot.empty or publie.empty:
            continue
        poids = lot["ponderation_pct"].sum()
        if not poids:
            continue
        calcule = float((lot["indice"] * lot["ponderation_pct"]).sum() / poids)
        attendu = float(publie.iloc[0])
        if attendu and abs(calcule - attendu) / attendu > IPSM_ECART_TOLERE:
            souffrances.append(
                "[ipsm] {} : somme ponderee des operateurs {:.2f} contre {:.2f} "
                "publie - une ponderation ou une colonne a pu etre mal lue"
                .format(trimestre, calcule, attendu))
    return souffrances


# ----------------------------------------------------------------------------
# Le lecteur du PAM vit dans son propre module — il n'a rien de national. Mais
# `collecter()` cherche les collecteurs ici : on le rend visible sous ce nom,
# en fin de module pour que `_lire` soit deja defini quand `pam` l'importe.
from .pam import collecter_wfp  # noqa: E402,F401

# Les loyers vivent aussi dans leur propre module : ils ne viennent pas d'une
# publication institutionnelle mais de sites d'annonces. Meme exposition, pour
# que `collecter()` les trouve sous le nom declare au registre.
from .loyers import collecter_loyers  # noqa: E402,F401
