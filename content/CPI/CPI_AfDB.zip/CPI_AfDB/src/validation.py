"""Étape 2 : validation de l'accessibilité de chaque site.

Pour chaque domaine : robots.txt, page d'accueil (statut, redirections, temps de réponse),
certificat TLS, présence d'un catalogue de produits. Un verdict synthétique en découle :
✅ actif, ⚠️ restreint, ❌ fermé ou redirigé.
"""
from __future__ import annotations

import logging
import re
import socket
import ssl
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlsplit

import pandas as pd
from tqdm.auto import tqdm

from .fetch import Fetcher, RobotsDisallowed

log = logging.getLogger("jumia_cpi.validation")

PRODUCT_LINK = re.compile(r'href="[^"]*-\d{5,}\.html"')
CHALLENGE = re.compile(r"(captcha|cf-chl|challenge-platform|access denied|attention required)", re.I)

# « undetermined » est ajouté par `sortie.appliquer` : un refus reçu depuis un
# centre de donnees ne tranche pas, et le confondre avec « restreint » a fait
# ecarter huit sites ouverts le 13/10/2026. Voir src/sortie.py.
VERDICTS = {"active": "✅ actif", "restricted": "⚠️ restreint", "closed": "❌ fermé / redirigé",
            "undetermined": "❔ indéterminé d'ici"}


def check_ssl(host: str, timeout: float = 8.0) -> dict:
    """Lit le certificat TLS (émetteur, expiration). Peut échouer derrière un proxy."""
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((host, 443), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ss:
                cert = ss.getpeercert()
        exp = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
        issuer = dict(x[0] for x in cert.get("issuer", ()))
        return {"ssl_valide": True, "ssl_jours_restants": (exp - datetime.now(timezone.utc)).days,
                "ssl_émetteur": issuer.get("organizationName", "?")}
    except ssl.SSLCertVerificationError as e:
        return {"ssl_valide": False, "ssl_jours_restants": None, "ssl_émetteur": f"invalide : {e.reason}"}
    except Exception as e:  # DNS, proxy, délai…
        return {"ssl_valide": None, "ssl_jours_restants": None, "ssl_émetteur": f"non vérifié ({type(e).__name__})"}


def validate_site(fetcher: Fetcher, domain: str, url: str, ssl_check: bool = True) -> dict:
    row = {"domain": domain}
    robots = fetcher.robots_for(url)
    row["robots_http"] = robots.source_status or "injoignable"
    row["robots_autorise_accueil"] = robots.can_fetch("/")
    row["robots_interdictions"] = sum(1 for k, *_ in robots.rules if k == "disallow")
    row["crawl_delay"] = robots.crawl_delay
    row["politique_robots"] = " ".join(robots.comments[:2])[:220]
    row["catégories_testées_interdites"] = ", ".join(
        p for p in ("/catalog/?q=riz", "/mlp-electromenager/", "/epicerie/") if not robots.can_fetch(p))

    try:
        r = fetcher.get(url, check_robots=robots.source_status != 0, use_cache=False)
    except RobotsDisallowed:
        r = None
    if r is None:
        row.update(http=None, url_finale=None, redirigé=False, temps_ms=None, liens_produits=0,
                   verdict="restricted", raison="robots.txt interdit la page d'accueil")
    else:
        final_host = urlsplit(r.url).netloc.lower().removeprefix("www.")
        redirected_away = bool(r.history) and final_host != domain
        n_products = len(PRODUCT_LINK.findall(r.text or "")) + (40 if "__STORE__" in (r.text or "") else 0)
        row.update(http=r.status or None, url_finale=r.url, redirigé=redirected_away,
                   temps_ms=round(r.elapsed * 1000), liens_produits=n_products, erreur=r.error)
        if r.error in ("dns", "connection", "timeout", "ssl: SSLError"):
            row.update(verdict="closed", raison={"dns": "domaine introuvable (DNS)",
                                                 "timeout": "aucune réponse (délai dépassé)"}.get(r.error, f"connexion impossible ({r.error})"))
        elif redirected_away:
            row.update(verdict="closed", raison=f"redirigé vers {final_host}")
        elif r.status in (404, 410):
            row.update(verdict="closed", raison=f"HTTP {r.status}")
        elif r.status in (401, 403, 429, 503) or CHALLENGE.search((r.text or "")[:3000]):
            row.update(verdict="restricted", raison=f"accès refusé ou protection anti-robot (HTTP {r.status})")
        elif not row["robots_autorise_accueil"]:
            row.update(verdict="restricted", raison="robots.txt interdit la collecte")
        elif r.ok and n_products >= 5:
            row.update(verdict="active", raison="catalogue détecté")
        elif r.ok:
            row.update(verdict="restricted", raison="page servie mais catalogue non détecté (rendu JavaScript ?)")
        else:
            row.update(verdict="restricted", raison=f"HTTP {r.status}")

    if ssl_check and row["verdict"] != "closed":
        row.update(check_ssl(domain))
    elif not ssl_check:
        row.update(ssl_valide=None, ssl_jours_restants=None, ssl_émetteur="non vérifié (mode test)")
    else:
        row.update(ssl_valide=None, ssl_jours_restants=None, ssl_émetteur="—")
    return row


def validate_sites(fetcher: Fetcher, registry: pd.DataFrame, ssl_check: bool = True) -> pd.DataFrame:
    rows = []
    retries, fetcher.max_retries = fetcher.max_retries, 1  # un site mort ne doit pas bloquer la boucle
    for _, s in tqdm(registry.iterrows(), total=len(registry), desc="Validation des sites"):
        try:
            rows.append(validate_site(fetcher, s["domain"], s["url"], ssl_check=ssl_check))
        except Exception as e:  # un site défaillant ne doit pas arrêter la boucle
            log.exception("Validation de %s", s["domain"])
            rows.append({"domain": s["domain"], "verdict": "restricted", "raison": f"erreur : {e}"})
    fetcher.max_retries = retries
    res = pd.DataFrame(rows)
    out = registry.merge(res, on="domain", how="left")
    out["état"] = out["verdict"].map(VERDICTS)
    for c in ("http", "temps_ms", "liens_produits", "robots_interdictions", "ssl_jours_restants"):
        if c in out:
            out[c] = pd.to_numeric(out[c], errors="coerce").astype("Int64")
    return out


def active_choices(validated: pd.DataFrame) -> list[tuple[str, str]]:
    """Options (libellé, code ISO2) pour le sélecteur : sites actifs uniquement."""
    act = validated[validated["verdict"] == "active"].sort_values("country_fr")
    return [(f"{r.country_fr} — {r.domain}", r.iso2) for r in act.itertuples()]
