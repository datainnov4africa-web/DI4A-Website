"""Le fichier qui relie les deux notebooks — et pourquoi ce n'est pas un Excel.

La collecte se fait depuis le réseau de l'institut ; l'analyse se fait où l'on
veut, Colab compris. Entre les deux, un fichier. C'est **la** décision de
conception de ce dispositif : si ce fichier est mal choisi, les deux notebooks
divergeront sans que personne ne le voie.

Pourquoi pas Excel pour la machine
----------------------------------
Sur un projet voisin, un classeur Excel a typé un code de division en entier et
un code de groupe en flottant, et une troncature a réduit **970 produits à 130**
— silencieusement. Le compte restait plausible, l'indice se calculait, et le
défaut n'a été vu que parce qu'une mesure d'assise avait été ajoutée la veille.

Excel reformate, retype et tronque sans rien dire. Le format machine est donc
**Parquet** : types préservés, codes intacts, rapide à cent mille lignes. Une
copie Excel est produite à côté, pour qu'un humain puisse regarder — elle n'est
jamais relue par le programme.

Pourquoi un seul fichier
------------------------
Le destinataire n'installera jamais Python. On ne peut pas lui demander de
déposer trois fichiers dans le bon ordre. :func:`exporter` écrit donc **une
archive unique** qui porte les relevés, leur copie lisible et le manifeste ;
:func:`importer` accepte cette archive, mais aussi un Parquet, un CSV ou un
Excel nus — parce qu'un utilisateur dépose ce qu'il a sous la main, et que lui
répondre « mauvais format » serait une mauvaise réponse.

Le manifeste n'est pas décoratif
--------------------------------
Sans lui, le notebook d'analyse calcule un indice sur des données dont il ne
peut pas dire l'origine : quelle version du code, quel jour, depuis quel point
de sortie, combien de pages. C'est la première question d'un relecteur, et elle
doit avoir une réponse dans le fichier lui-même.
"""
from __future__ import annotations

import hashlib
import io
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from .config import VERSION

# Sans ces colonnes, aucun indice n'est calculable. Une absence doit être dite
# par son nom : « il manque la colonne des prix » se corrige, « KeyError » non.
COLONNES_REQUISES = {
    "sku": "l'identifiant du produit",
    "name": "le libellé du produit",
    "price": "le prix relevé",
    "collect_date": "la date du relevé",
}

# Utiles mais non bloquantes : leur absence dégrade l'analyse sans l'empêcher,
# et le notebook doit dire laquelle manque et ce qu'on y perd.
COLONNES_UTILES = {
    "old_price": "le prix barré — sans lui, la part de promotions n'est pas mesurable",
    "n_ratings": "le nombre d'avis — sans lui, le GEKS pondéré n'est pas calculable",
    "brand": "la marque",
    "jumia_category": "le rayon d'origine, utile à la classification COICOP",
    "category_slug": "la rubrique interrogée",
    "currency": "la devise — sans elle, les montants n'ont pas d'unité",
    "country": "le pays",
    "parse_method": "la méthode d'extraction, qui sert à suivre les refontes du site",
}

NOM_PARQUET = "panel.parquet"
NOM_MANIFESTE = "manifeste.json"
NOM_EXCEL = "panel_lisible.xlsx"

# Excel accepte un peu plus d'un million de lignes, mais en écrire cent mille
# prend des minutes pour une copie que personne ne lira en entier. La copie
# lisible est donc un échantillon, et elle le dit.
LIGNES_EXCEL_MAX = 50_000


def empreinte(donnees: bytes) -> str:
    return hashlib.sha256(donnees).hexdigest()


def manifeste(df: pd.DataFrame, pays: str, contexte_sortie: dict | None = None,
              parametres: dict | None = None, extra: dict | None = None) -> dict:
    """Ce qu'il faut pour répondre à « d'où viennent ces prix »."""
    periodes = sorted(pd.to_datetime(df["collect_date"]).dt.to_period("M")
                      .astype(str).unique()) if len(df) else []
    dates = sorted(pd.Series(df["collect_date"]).astype(str).unique()) if len(df) else []
    ctx = contexte_sortie or {}
    return {
        "projet": "jumia-cpi",
        "version_code": VERSION,
        "généré_le": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "pays": pays,
        "observations": int(len(df)),
        "produits": int(df["sku"].nunique()) if "sku" in df else None,
        "dates_de_relevé": dates,
        "mois_couverts": periodes,
        "colonnes": list(df.columns),
        "collecte_depuis": {
            "point_de_sortie": ctx.get("ou"),
            "centre_de_donnees": ctx.get("centre_de_donnees"),
            "adresse_publique": ctx.get("adresse_publique"),
            "fuseau": ctx.get("fuseau"),
        },
        "paramètres": parametres or {},
        **(extra or {}),
    }


def exporter(df: pd.DataFrame, destination, pays: str,
             contexte_sortie: dict | None = None, parametres: dict | None = None,
             extra: dict | None = None, copie_excel: bool = True) -> Path:
    """Écrit l'archive unique à déposer dans le notebook d'analyse.

    Rend le chemin de l'archive. Le manifeste y porte l'empreinte du Parquet :
    une archive dont le Parquet aurait été remplacé se repère.
    """
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)

    tampon = io.BytesIO()
    df.to_parquet(tampon, index=False)
    octets_parquet = tampon.getvalue()

    contenu = manifeste(df, pays, contexte_sortie, parametres, extra)
    contenu["fichiers"] = [{"nom": NOM_PARQUET, "octets": len(octets_parquet),
                            "sha256": empreinte(octets_parquet)}]

    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(NOM_PARQUET, octets_parquet)
        z.writestr(NOM_MANIFESTE,
                   json.dumps(contenu, ensure_ascii=False, indent=2, default=str))
        if copie_excel:
            extrait = df.head(LIGNES_EXCEL_MAX)
            tampon_xl = io.BytesIO()
            try:
                extrait.to_excel(tampon_xl, index=False, sheet_name="relevés")
                z.writestr(NOM_EXCEL, tampon_xl.getvalue())
            except Exception:
                # Une copie de confort absente n'empêche rien : le Parquet est
                # la donnée, l'Excel n'est qu'un regard dessus.
                pass
        z.writestr("LISEZ-MOI.txt", _lisez_moi(contenu))
    return destination


def _lisez_moi(contenu: dict) -> str:
    return (
        "Relevés de prix Jumia — {pays}\n"
        "{obs} observations, {prod} produits, {n} date(s) de relevé.\n"
        "Généré le {date} par jumia-cpi {version}.\n\n"
        "Déposez CETTE ARCHIVE telle quelle dans le notebook d'analyse.\n"
        "Ne la décompressez pas et ne modifiez pas panel.parquet : c'est la\n"
        "donnée. Le fichier {excel} est une copie lisible, limitée aux\n"
        "{max} premières lignes ; il n'est jamais relu par le programme.\n"
        .format(pays=contenu.get("pays"), obs=contenu.get("observations"),
                prod=contenu.get("produits"),
                n=len(contenu.get("dates_de_relevé") or []),
                date=contenu.get("généré_le"), version=contenu.get("version_code"),
                excel=NOM_EXCEL, max=LIGNES_EXCEL_MAX))


# --------------------------------------------------------------- relecture

def verifier(df: pd.DataFrame) -> dict:
    """Ce fichier permet-il de calculer un indice, et sinon pourquoi.

    Rend des phrases, pas des codes d'erreur : le destinataire n'installera
    jamais Python et n'a aucun moyen de traduire une exception.
    """
    bloquants, reserves = [], []
    if df is None or len(df) == 0:
        return {"utilisable": False,
                "bloquants": ["Le fichier ne contient aucune ligne."],
                "réserves": [], "observations": 0}

    for colonne, role in COLONNES_REQUISES.items():
        if colonne not in df.columns:
            bloquants.append("Colonne « {} » absente : c'est {}. Sans elle, "
                             "aucun indice n'est calculable.".format(colonne, role))
    for colonne, role in COLONNES_UTILES.items():
        if colonne not in df.columns:
            reserves.append("Colonne « {} » absente : {}.".format(colonne, role))

    if "price" in df.columns:
        prix = pd.to_numeric(df["price"], errors="coerce")
        sans = int(prix.isna().sum())
        if sans == len(df):
            bloquants.append("Aucun prix lisible dans la colonne « price ».")
        elif sans:
            reserves.append("{} ligne(s) sur {} sans prix lisible : elles "
                            "seront écartées.".format(sans, len(df)))

    mois = []
    if "collect_date" in df.columns:
        dates = pd.to_datetime(df["collect_date"], errors="coerce")
        if dates.isna().all():
            bloquants.append("Les dates de relevé ne sont pas lisibles dans la "
                             "colonne « collect_date ».")
        else:
            mois = sorted(dates.dt.to_period("M").dropna().astype(str).unique())
            if len(mois) < 2:
                reserves.append(
                    "Un seul mois de relevés ({}). Un indice compare deux "
                    "périodes : il faudra une seconde collecte, le mois "
                    "prochain, pour obtenir une évolution.".format(
                        mois[0] if mois else "?"))

    return {"utilisable": not bloquants, "bloquants": bloquants,
            "réserves": reserves, "observations": int(len(df)),
            "mois": mois}


def importer(chemin) -> dict:
    """Lit ce que l'utilisateur a déposé, quel qu'en soit le format.

    Accepte l'archive produite par :func:`exporter`, mais aussi un Parquet, un
    CSV ou un Excel nus. Rend ``{"données", "manifeste", "source", "contrôle",
    "journal"}``. Ne lève pas sur un format inattendu : le journal dit ce qui
    s'est passé, en français.
    """
    chemin = Path(chemin)
    journal = []
    donnees, contenu_manifeste, source = None, None, ""

    if not chemin.exists():
        return {"données": None, "manifeste": None, "source": str(chemin),
                "contrôle": {"utilisable": False,
                             "bloquants": ["Fichier introuvable : {}".format(chemin)],
                             "réserves": [], "observations": 0},
                "journal": journal}

    suffixe = chemin.suffix.lower()
    try:
        if suffixe == ".zip":
            with zipfile.ZipFile(chemin) as z:
                noms = z.namelist()
                parquets = [n for n in noms if n.lower().endswith(".parquet")]
                if not parquets:
                    journal.append("L'archive ne contient aucun fichier .parquet.")
                else:
                    octets = z.read(parquets[0])
                    donnees = pd.read_parquet(io.BytesIO(octets))
                    source = "{} (dans {})".format(parquets[0], chemin.name)
                    if NOM_MANIFESTE in noms:
                        contenu_manifeste = json.loads(z.read(NOM_MANIFESTE))
                        attendu = (contenu_manifeste.get("fichiers") or [{}])[0].get("sha256")
                        obtenu = empreinte(octets)
                        if attendu and attendu != obtenu:
                            journal.append(
                                "L'empreinte des relevés ne correspond pas à "
                                "celle du manifeste : le fichier a été modifié "
                                "depuis sa production.")
                        else:
                            journal.append("Empreinte vérifiée : les relevés "
                                           "sont ceux qui ont été produits.")
                    else:
                        journal.append("Archive sans manifeste : l'origine des "
                                       "relevés ne pourra pas être citée.")
        elif suffixe == ".parquet":
            donnees = pd.read_parquet(chemin)
            source = chemin.name
            journal.append("Parquet nu : aucun manifeste, l'origine des "
                           "relevés ne pourra pas être citée.")
        elif suffixe in (".csv", ".txt"):
            donnees = pd.read_csv(chemin)
            source = chemin.name
            journal.append("CSV : les types ont été devinés à la lecture. "
                           "Préférez l'archive produite par le notebook de "
                           "collecte, qui préserve les types.")
        elif suffixe in (".xlsx", ".xls"):
            donnees = pd.read_excel(chemin)
            source = chemin.name
            journal.append(
                "Excel : les types ont été devinés et les codes ont pu être "
                "retypés à l'écriture. C'est le format le moins sûr pour des "
                "relevés — préférez l'archive produite par le notebook de "
                "collecte.")
        else:
            journal.append("Format non reconnu : {}. Attendu .zip, .parquet, "
                           ".csv ou .xlsx.".format(suffixe or "sans extension"))
    except Exception as erreur:
        journal.append("Lecture impossible : {} ({}).".format(
            erreur, type(erreur).__name__))

    controle = verifier(donnees) if donnees is not None else {
        "utilisable": False,
        "bloquants": ["Le fichier n'a pas pu être lu — voir le journal."],
        "réserves": [], "observations": 0}
    return {"données": donnees, "manifeste": contenu_manifeste, "source": source,
            "contrôle": controle, "journal": journal}


def origine_lisible(contenu: dict | None) -> str:
    """Une phrase qui dit d'où viennent les données, pour l'en-tête du rapport."""
    if not contenu:
        return ("Origine inconnue : le fichier déposé ne portait pas de "
                "manifeste. L'indice reste calculable, mais sa provenance ne "
                "peut pas être citée dans une note méthodologique.")
    ou = (contenu.get("collecte_depuis") or {}).get("point_de_sortie") or "un point de sortie non précisé"
    mois = contenu.get("mois_couverts") or []
    return ("{obs} relevés sur {prod} produits, {pays}, {n} mois ({debut} → "
            "{fin}), collectés depuis {ou} par jumia-cpi {v}, générés le {d}."
            .format(obs=contenu.get("observations"), prod=contenu.get("produits"),
                    pays=contenu.get("pays"), n=len(mois),
                    debut=mois[0] if mois else "?", fin=mois[-1] if mois else "?",
                    ou=ou, v=contenu.get("version_code"),
                    d=(contenu.get("généré_le") or "")[:10]))


# --------------------------------------------------- fusionner deux collectes

# Clé d'unicité d'un relevé. Le même produit relevé deux fois le même jour est
# un doublon ; relevé deux jours différents, ce sont deux observations.
CLE_RELEVE = ("sku", "collect_date")

# Les sites d'annonces immobilières publient côte à côte des loyers et des prix
# de vente. Un prix de vente est le prix d'un **actif**, pas d'une
# consommation : le manuel de l'IPC l'exclut de l'indice, où le logement entre
# par les loyers réels et imputés. Le collecteur étiquette donc la nature de
# chaque annonce — « location », « vente », « indéterminée » — et on ne retient
# ici que la première.
#
# « indéterminée » est écartée aussi, et ce n'est pas de la prudence gratuite :
# en Côte d'Ivoire, un quart de ces annonces dépasse dix fois le loyer médian,
# la plus chère à 2,8 milliards de francs CFA. Leur texte ne dit ni « à louer »
# ni « à vendre », et c'est précisément ce que l'étiquetage a déjà tenté de
# trancher. Garder ce qui n'est pas établi ferait entrer des prix d'actifs dans
# la division 04, qui pèse 15,5 % du panier ivoirien.
PREFIXE_LOYERS = "Loyers — "
NATURE_RETENUE = "location"


def ecarter_les_non_loyers(df: pd.DataFrame) -> tuple:
    """Des annonces immobilières, ne garde que les locations.

    Rend ``(données, phrases)``. Les phrases nomment ce qui a été écarté et
    combien : un filtre muet est un filtre qu'on ne relit jamais.
    """
    if "category_name" not in df.columns:
        return df, []
    rubrique = df["category_name"].astype(str)
    immobilier = rubrique.str.startswith(PREFIXE_LOYERS)
    if not immobilier.any():
        return df, []
    nature = rubrique.str.slice(len(PREFIXE_LOYERS))
    a_ecarter = immobilier & (nature != NATURE_RETENUE)
    if not a_ecarter.any():
        return df, []
    detail = nature[a_ecarter].value_counts()
    phrases = [
        "{} annonce(s) immobilière(s) écartée(s) — {}. Un prix de vente est "
        "le prix d'un actif, pas d'une consommation : le manuel de l'IPC "
        "l'exclut de l'indice. Les annonces dont la nature n'a pas pu être "
        "établie sont écartées pour la même raison, faute de pouvoir montrer "
        "que ce sont des loyers. Il reste {} location(s).".format(
            int(a_ecarter.sum()),
            ", ".join("{} {}".format(int(n), k) for k, n in detail.items()),
            int((immobilier & ~a_ecarter).sum()))]
    return df[~a_ecarter].copy(), phrases


def ecarter_les_devises_etrangeres(df: pd.DataFrame) -> tuple:
    """Ne garde que la devise officielle du pays, quand il n'y en a qu'un.

    Une annonce de Kampala libellée en dollars n'est pas une erreur de
    collecte : c'est ainsi que ce marché publie une partie de ses prix. Elle
    n'en reste pas moins inadditionnable aux shillings, et la convertir
    demanderait un taux de change dont l'indice n'a pas à dépendre.

    Ce tri **ne remplace pas** le blocage multi-devises qui suit : celui-ci
    protège le cas où l'on dépose huit pays dans le même dossier, et il doit
    continuer à se déclencher. Ici, le pays est unique et sa devise connue.
    """
    if "country" not in df.columns or "currency" not in df.columns:
        return df, []
    pays = sorted(df["country"].dropna().unique())
    if len(pays) != 1:
        return df, []
    try:
        from .config import site_by_iso2
        officielle = site_by_iso2(str(pays[0])).currency
    except Exception:
        return df, []
    etrangeres = df["currency"].notna() & (df["currency"] != officielle)
    if not etrangeres.any():
        return df, []
    detail = df.loc[etrangeres, "currency"].value_counts()
    phrases = [
        "{} ligne(s) écartée(s) parce qu'elles ne sont pas libellées en {}, "
        "la devise de {} — {}. Des montants en monnaies différentes ne "
        "s'additionnent pas, et les convertir ferait dépendre l'indice d'un "
        "taux de change.".format(
            int(etrangeres.sum()), officielle, pays[0],
            ", ".join("{} en {}".format(int(n), k) for k, n in detail.items()))]
    return df[~etrangeres].copy(), phrases


def fusionner(chemins) -> dict:
    """Lit plusieurs archives et n'en fait qu'un panel.

    C'est ce qui permet au notebook d'analyse de travailler sur **l'ensemble**
    des collectes : les prix de marché en ligne et les prix administrés
    nourrissent le même indice, chacun avec sa division.

    Trois précautions, et chacune vient d'un risque réel :

    * **les doublons sont écartés et comptés.** Déposer deux fois le même
      fichier est une manipulation courante ; garder les lignes en double
      ferait compter deux fois le même prix ;
    * **les identifiants ne se télescopent pas.** Un produit Jumia porte son
      identifiant de boutique ; un relevé institutionnel une clé préfixée du
      nom de sa source — `ocpv:riz local|adjamé|detail`. La collision est donc
      impossible par construction, mais on la vérifie quand même ;
    * **mélanger deux pays est signalé.** Un indice mesure un panier national ;
      agréger la Côte d'Ivoire et le Sénégal donnerait un chiffre qui ne
      décrit aucun des deux.
    """
    chemins = [chemins] if isinstance(chemins, (str, Path)) else list(chemins)
    tables, manifestes, journal, sources = [], [], [], []

    for chemin in chemins:
        lu = importer(chemin)
        nom = Path(chemin).name
        for ligne in lu["journal"]:
            journal.append("[{}] {}".format(nom, ligne))
        if lu["données"] is None or not lu["contrôle"]["utilisable"]:
            for b in lu["contrôle"]["bloquants"]:
                journal.append("[{}] écarté : {}".format(nom, b))
            continue
        table = lu["données"].copy()
        table["_fichier"] = nom
        tables.append(table)
        manifestes.append(lu["manifeste"])
        sources.append({
            "fichier": nom,
            "observations": int(len(table)),
            "produits": int(table["sku"].nunique()) if "sku" in table else None,
            "pays": sorted(table["country"].dropna().unique()) if "country" in table else [],
            "manifeste": lu["manifeste"] is not None,
        })

    if not tables:
        return {"données": None, "manifestes": [], "sources": [],
                "journal": journal,
                "contrôle": {"utilisable": False, "observations": 0,
                             "bloquants": ["Aucun fichier exploitable."],
                             "réserves": []}}

    ensemble = pd.concat(tables, ignore_index=True, sort=False)

    # Concaténer deux tableaux dont une colonne n'a pas le même type rend une
    # colonne `object` — et `np.log` sur des objets lève, ce qui fait tomber
    # tout le calcul d'indice. Le défaut est muet jusque-là : la fusion
    # réussit, les comptes sont bons, et c'est l'indice qui s'effondre.
    #
    # C'est la même famille que le classeur Excel qui retypait des codes : on
    # remet donc les colonnes numériques dans leur type, ici, au seul endroit
    # où deux origines se rencontrent.
    for colonne in ("price", "old_price", "discount_pct", "rating",
                    "n_ratings", "quantity", "unit_price"):
        if colonne in ensemble.columns:
            ensemble[colonne] = pd.to_numeric(ensemble[colonne], errors="coerce")

    cles = [c for c in CLE_RELEVE if c in ensemble.columns]
    if cles:
        avant = len(ensemble)
        # Quand le même relevé figure dans plusieurs archives, c'est la plus
        # récente qui l'emporte. Ce n'est pas un détail : les 209 annonces de
        # loyer kényanes ont été collectées quatre fois le 20 octobre 2026 par
        # un code corrigé entre deux passages, et étiquetées quatre fois
        # différemment — 10 locations au premier passage, 209 au dernier.
        # Garder le premier fichier rencontré, c'est garder la version que le
        # correctif a précisément remplacée.
        #
        # Le nom d'archive porte sa date et son heure — `officiel_KE_2026-10-20
        # _2238` — donc l'ordre alphabétique décroissant est l'ordre du plus
        # récent au plus ancien. Deux préfixes différents (`panel_`,
        # `officiel_`) ne partagent jamais d'identifiant : ils viennent de
        # sources distinctes.
        if "_fichier" in ensemble.columns:
            ensemble = ensemble.sort_values(
                "_fichier", ascending=False, kind="stable")
        ensemble = ensemble.drop_duplicates(subset=cles, keep="first")
        if "_fichier" in ensemble.columns:
            ensemble = ensemble.sort_index(kind="stable")
        doublons = avant - len(ensemble)
        if doublons:
            journal.append(
                "{} ligne(s) en double écartées : le même relevé figurait dans "
                "plusieurs fichiers. C'est la version de l'archive la plus "
                "récente qui est retenue — les garder toutes ferait compter "
                "plusieurs fois le même prix.".format(doublons))

    # Deux tris avant tout contrôle : ce qui suit compte les observations, et
    # il doit compter celles qui entreront vraiment dans l'indice.
    ensemble, dits = ecarter_les_non_loyers(ensemble)
    journal.extend(dits)
    ensemble, dits_devise = ecarter_les_devises_etrangeres(ensemble)
    journal.extend(dits_devise)

    controle = verifier(ensemble)
    for phrase in dits + dits_devise:
        controle.setdefault("réserves", []).append(phrase)

    if "country" in ensemble.columns:
        pays = sorted(ensemble["country"].dropna().unique())
        if len(pays) > 1:
            controle.setdefault("réserves", []).append(
                "Les fichiers déposés couvrent {} pays ({}). Un indice mesure "
                "un panier national : agréger plusieurs pays donnerait un "
                "chiffre qui n'en décrit aucun. Ne gardez que les fichiers "
                "d'un seul pays.".format(len(pays), ", ".join(pays)))

    # Deux devises ne s'additionnent pas. Tant qu'un seul pays pouvait être
    # collecté, l'avertissement ci-dessus suffisait ; depuis qu'une campagne
    # peut déposer huit pays et sept devises dans le même dossier, laisser
    # passer produirait un nombre qui ressemble à un indice sans en être un.
    # Ce n'est donc plus une réserve : c'est une impossibilité arithmétique.
    if "currency" in ensemble.columns:
        devises = sorted(ensemble["currency"].dropna().unique())
        if len(devises) > 1:
            controle["bloquants"] = controle.get("bloquants", []) + [
                "Les fichiers déposés mêlent {} devises ({}). Des montants "
                "exprimés dans des monnaies différentes ne s'additionnent "
                "pas : aucun indice ne peut en sortir. Ne gardez que les "
                "fichiers d'un seul pays.".format(
                    len(devises), ", ".join(map(str, devises)))]
            controle["utilisable"] = False

    if "division_hint" in ensemble.columns:
        divisions = sorted(d for d in ensemble["division_hint"].dropna().unique())
        if divisions:
            journal.append("Divisions apportées par l'ensemble : {}."
                           .format(", ".join(map(str, divisions))))

    return {"données": ensemble.drop(columns=["_fichier"], errors="ignore"),
            "manifestes": manifestes, "sources": sources,
            "journal": journal, "contrôle": controle,
            "repartition": ensemble["_fichier"].value_counts().to_dict()
            if "_fichier" in ensemble else {}}


def origine_fusionnee(manifestes, sources) -> str:
    """Une phrase qui dit d'où vient l'ensemble, fichier par fichier.

    Avec plusieurs collectes, une seule ligne d'origine ne suffit plus : c'est
    le détail par fichier qui permet de citer la provenance dans une note.
    """
    if not sources:
        return "Aucune source chargée."
    morceaux = []
    for s in sources:
        morceaux.append("{} ({} relevés{})".format(
            s["fichier"], s["observations"],
            "" if s["manifeste"] else ", sans manifeste"))
    total = sum(s["observations"] for s in sources)
    sans = [s["fichier"] for s in sources if not s["manifeste"]]
    phrase = "{} relevés au total, issus de {} fichier(s) : {}.".format(
        total, len(sources), " · ".join(morceaux))
    if sans:
        phrase += (" La provenance de {} ne pourra pas être citée : "
                   "aucun manifeste.".format(", ".join(sans)))
    return phrase
