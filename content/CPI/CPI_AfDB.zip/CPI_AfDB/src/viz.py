"""Mise en forme : encadrés pédagogiques, schéma du pipeline, tableaux et figures Plotly.

Les couleurs suivent une règle simple : chaque division COICOP garde toujours la même couleur
(la couleur suit l'entité, jamais son rang) ; l'ensemble est tracé en encre foncée ; les états
(actif, restreint, fermé) utilisent une palette de statut distincte, toujours accompagnée d'un
symbole et d'un libellé.
"""
from __future__ import annotations

import html
import re
from typing import Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.io as pio

from .config import COICOP_SHORT, COICOP_DIVISIONS

# --------------------------------------------------------------------------------------
# Palette (8 teintes catégorielles validées pour la vision des couleurs, ordre fixe)
# --------------------------------------------------------------------------------------
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, MUTED, GRID, SURFACE = "#0b0b0b", "#52514e", "#8a8986", "#e9e8e4", "#fcfcfb"
STATUS = {"active": "#0ca30c", "restricted": "#fab219", "closed": "#d03b3b"}
STATUS_LABEL = {"active": "✅ actif", "restricted": "⚠️ restreint", "closed": "❌ fermé / redirigé"}
SEQ = ["#f0efec", "#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]
DIV_ORDER = ["01", "13", "08", "05", "03", "06", "09", "07"]
DIV_COLORS = {d: SERIES[i] for i, d in enumerate(DIV_ORDER)}
DIV_COLORS.update({"02": "#a3a29c", "04": "#7a7974", "10": "#5e5d59", "11": "#b8b7b0", "12": "#4a4945",
                   "Ensemble": INK})

# « Jumia » était exact quand une seule source nourrissait l'indice. Les relevés
# institutionnels et les loyers l'alimentent désormais aussi : attribuer à une
# place de marché des prix qu'elle n'a pas publiés serait faux sur une figure
# destinée à être montrée.
SOURCE = "Source : relevés de prix en ligne et sources officielles · calculs du dispositif."
SOURCE_JUMIA = "Source : relevés de prix sur Jumia · calculs du dispositif."

pio.templates["jumia"] = go.layout.Template(layout=go.Layout(
    font=dict(family="Inter, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif", size=13, color=INK2),
    # `automargin` fait reserver au titre la place qu'il occupe reellement.
    # Sans lui, un titre sur deux lignes dans une figure courte depassait du
    # haut et se trouvait rogne a l'affichage.
    # `yref="container"` ancre le titre sur la figure entiere et non sur la
    # zone de trace, et `automargin` lui fait reserver la place qu'il occupe :
    # sans les deux, un titre sur deux lignes se trouvait rogne par le haut.
    title=dict(font=dict(size=19, color=INK), x=0, xanchor="left", y=0.94,
               yref="container", yanchor="top", automargin=True),
    paper_bgcolor=SURFACE, plot_bgcolor=SURFACE, colorway=SERIES,
    xaxis=dict(showgrid=False, linecolor=GRID, ticks="outside", tickcolor=GRID, ticklen=5,
               zeroline=False, automargin=True, tickfont=dict(size=12)),
    yaxis=dict(gridcolor=GRID, griddash="dot", zeroline=False, linecolor=GRID, automargin=True,
               tickfont=dict(size=12), title=dict(font=dict(size=12, color=MUTED))),
    # La legende se place sous le bloc titre + sous-titre, pas contre le haut
    # du trace : au-dessus, elle laissait une bande vide entre les deux.
    legend=dict(orientation="h", y=1.14, yanchor="top", x=0, xanchor="left", title_text="",
                font=dict(size=12), itemsizing="constant", itemwidth=30),
    hoverlabel=dict(bgcolor="white", font_size=12, bordercolor=GRID),
    margin=dict(l=64, r=40, t=126, b=84),
))
pio.templates.default = "jumia"


def _titre(texte: str, precision: str = "") -> dict:
    """Un titre, et au-dessous la précision qui évite de le mal lire.

    Le sous-titre n'est pas un ornement : il porte la base, l'unité ou la
    réserve, c'est-à-dire ce sans quoi le chiffre tracé se lit de travers.
    """
    if precision:
        texte = "%s<br><span style='font-size:13px;color:%s'>%s</span>" % (
            texte, MUTED, precision)
    return dict(text=texte)


def panneau(titre: str, message: str, hauteur: int = 320) -> go.Figure:
    """Une figure qui dit qu'il n'y a rien à tracer, au lieu de tracer du vide.

    Un indice sans produit apparié sort plat à 100 sur toute la période. Tracé
    comme les autres — axes, légende, dix couleurs — il ressemble à une mesure
    et se lit « les prix n'ont pas bougé ». C'est faux : il n'y a rien eu à
    mesurer. La distinction ne peut pas être laissée à l'œil du lecteur.
    """
    fig = go.Figure()
    fig.add_annotation(text="<b>%s</b>" % html.escape(titre), xref="paper", yref="paper",
                       x=0.5, y=0.60, showarrow=False, xanchor="center",
                       font=dict(size=16, color=INK))
    fig.add_annotation(text=message, xref="paper", yref="paper", x=0.5, y=0.44,
                       showarrow=False, xanchor="center", align="center",
                       font=dict(size=13, color=MUTED))
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    fig.update_layout(height=hauteur, margin=dict(l=40, r=40, t=40, b=40),
                      shapes=[dict(type="rect", xref="paper", yref="paper",
                                   x0=0, y0=0, x1=1, y1=1, line=dict(color=GRID, width=1),
                                   fillcolor="rgba(0,0,0,0)")])
    return fig


def _immobile(valeurs: pd.Series, tolerance: float = 0.005) -> bool:
    """La série ne bouge-t-elle pas du tout ? Vrai aussi si elle est vide."""
    v = pd.to_numeric(valeurs, errors="coerce").dropna()
    return len(v) == 0 or float(v.max() - v.min()) < tolerance


def _periods(fig: go.Figure, etiquettes: Optional[list] = None,
             maximum: int = 14) -> go.Figure:
    """Les périodes AAAA-MM sont des catégories (pas d'extrapolation de l'axe des dates).

    Au-delà d'une douzaine de mois, afficher chaque étiquette les fait pivoter
    et se chevaucher — vingt-neuf libellés en biais sur la capture. On en garde
    une sur n, la dernière toujours comprise : c'est elle qu'on vient lire.
    """
    fig.update_xaxes(type="category")
    if etiquettes and len(etiquettes) > maximum:
        # On compte depuis la fin : la derniere periode est celle qu'on vient
        # lire, elle doit etre etiquetee. Partir du debut puis « ajouter la
        # derniere » collait deux etiquettes l'une sur l'autre — « 2026-0926-10 »
        # sur le rendu precedent.
        pas = (len(etiquettes) + maximum - 1) // maximum
        gardees = list(reversed(etiquettes[::-1][::pas]))
        fig.update_xaxes(tickmode="array", tickvals=gardees, tickangle=0)
    elif etiquettes:
        fig.update_xaxes(tickangle=0)
    return fig


def _source(fig: go.Figure, text: str = SOURCE, synthetic: bool = False) -> go.Figure:
    if synthetic:
        text += " Données synthétiques (mode test)."
    fig.add_annotation(text=text, xref="paper", yref="paper", x=0, y=0, yshift=-62, showarrow=False,
                       font=dict(size=11, color=MUTED), xanchor="left", yanchor="top")
    return fig


# --------------------------------------------------------------------------------------
# HTML pédagogique
# --------------------------------------------------------------------------------------
KINDS = {
    "why": ("#2a78d6", "💡", "Pourquoi cette étape ?"),
    "insight": ("#0ca30c", "📊", "Ce que disent les données"),
    "warn": ("#eb6834", "⚠️", "Attention"),
    "method": ("#6250d6", "🧮", "Méthode"),
    "ethics": ("#d03b3b", "⚖️", "Éthique et conformité"),
    "tip": ("#1baf7a", "🛠️", "Astuce"),
}


def _md(text: str) -> str:
    t = html.escape(text, quote=False)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"`(.+?)`", r"<code>\1</code>", t)
    return t


def callout(kind: str, body, title: Optional[str] = None) -> str:
    color, icon, default = KINDS.get(kind, KINDS["insight"])
    if isinstance(body, (list, tuple)):
        inner = "<ul style='margin:6px 0 0 0;padding-left:20px'>" + "".join(
            f"<li style='margin:4px 0'>{_md(b)}</li>" for b in body) + "</ul>"
    else:
        inner = f"<div style='margin-top:4px'>{_md(str(body))}</div>"
    return (f"<div style='border-left:5px solid {color};background:{color}14;padding:12px 16px;border-radius:8px;"
            f"margin:10px 0;line-height:1.5'><div style='font-weight:700;color:{color}'>{icon} {title or default}</div>"
            f"{inner}</div>")


def show(html_str: str) -> None:
    try:
        from IPython.display import HTML, display

        display(HTML(html_str))
    except ImportError:
        print(re.sub("<[^>]+>", "", html_str))


def show_callout(kind: str, body, title: Optional[str] = None) -> None:
    show(callout(kind, body, title))


CONF_COLORS = {"élevée": "#0ca30c", "moyenne": "#eda100", "faible": "#d03b3b"}


def message_cards(msgs: list[dict]) -> str:
    cards = []
    for m in msgs:
        c = CONF_COLORS.get(m["confiance"], MUTED)
        icon = {"élevée": "●●●", "moyenne": "●●○", "faible": "●○○"}.get(m["confiance"], "")
        cards.append(
            f"<div style='flex:1 1 280px;border:1px solid {GRID};border-radius:12px;padding:14px 16px;background:white'>"
            f"<div style='font-weight:700;color:{INK};font-size:15px'>{html.escape(m['titre'])}</div>"
            f"<div style='margin:8px 0;color:{INK2};line-height:1.45'>{_md(m['texte'])}</div>"
            f"<div style='font-size:12px'><span style='color:{c};font-weight:700'>{icon} confiance {m['confiance']}</span>"
            f"<span style='color:{MUTED}'> · {html.escape(m['motif'])}</span></div></div>")
    return f"<div style='display:flex;flex-wrap:wrap;gap:12px;margin:10px 0'>{''.join(cards)}</div>"


def kpi_tiles(items: list[tuple[str, str, str]]) -> str:
    """[(valeur, libellé, détail)]"""
    tiles = "".join(
        f"<div style='flex:1 1 150px;border:1px solid {GRID};border-radius:12px;padding:12px 16px;background:white'>"
        f"<div style='font-size:26px;font-weight:700;color:{INK}'>{html.escape(v)}</div>"
        f"<div style='color:{INK2};font-weight:600'>{html.escape(l)}</div>"
        f"<div style='color:{MUTED};font-size:12px'>{html.escape(d)}</div></div>" for v, l, d in items)
    return f"<div style='display:flex;flex-wrap:wrap;gap:10px;margin:10px 0'>{tiles}</div>"


def synthetic_banner() -> str:
    return ("<div style='background:#fab21933;border:1px solid #fab219;border-radius:8px;padding:10px 14px;margin:8px 0;"
            "font-weight:600;color:#5a4300'>🧪 MODE TEST : site Jumia synthétique (pays fictif XT), sans réseau. Les chiffres "
            "illustrent la méthode et ne décrivent aucun pays réel. Passez MODE = \"live\" pour une vraie collecte.</div>")


STEPS = [
    ("1", "Découverte", "registre + pages Jumia", "#2a78d6"),
    ("2", "Validation", "HTTP · TLS · robots.txt", "#1baf7a"),
    ("3", "Collecte", "pages de liste · Parquet", "#eda100"),
    ("4", "Enrichissement", "LLM · COICOP · quantités", "#6250d6"),
    ("5", "Indices", "Jevons · GEKS · pondérations", "#eb6834"),
    ("6", "Validation", "IPC officiel · biais", "#e87ba4"),
    ("7", "Restitution", "messages · rapport HTML", "#008300"),
]


def pipeline_diagram(active: Optional[str] = None) -> str:
    boxes = []
    for i, (n, t, s, c) in enumerate(STEPS):
        on = active is None or active == n
        boxes.append(
            f"<div style='flex:1 1 120px;min-width:118px;border:2px solid {c};border-radius:12px;padding:10px;"
            f"background:{c}{'22' if on else '08'};opacity:{1 if on else 0.55};text-align:center'>"
            f"<div style='font-size:12px;font-weight:700;color:{c}'>ÉTAPE {n}</div>"
            f"<div style='font-weight:700;color:{INK};margin:2px 0'>{t}</div>"
            f"<div style='font-size:11.5px;color:{INK2}'>{s}</div></div>")
        if i < len(STEPS) - 1:
            boxes.append(f"<div style='align-self:center;color:{MUTED};font-size:20px'>➜</div>")
    llm = ("<div style='margin-top:8px;font-size:12px;color:" + INK2 + "'>LLM : <b>Ollama</b> (local) · <b>Groq</b> · "
           "<b>Gemini</b> → repli automatique → <b>règles</b> déterministes · Stockage : Parquet partitionné + DuckDB · "
           "Cache HTTP et LLM · Reprise après interruption</div>")
    return (f"<div style='display:flex;flex-wrap:wrap;gap:6px;align-items:stretch;padding:12px;border-radius:14px;"
            f"background:white;border:1px solid {GRID}'>{''.join(boxes)}</div>{llm}")


def cover(title: str, subtitle: str) -> str:
    return (f"<div style='padding:28px 30px;border-radius:16px;background:linear-gradient(120deg,#0d366b,#2a78d6 60%,#1baf7a);"
            f"color:white'><div style='font-size:13px;letter-spacing:2px;opacity:.85'>STATISTIQUES DE PRIX · DONNÉES WEB</div>"
            f"<div style='font-size:30px;font-weight:800;margin:6px 0'>{html.escape(title)}</div>"
            f"<div style='font-size:16px;opacity:.95'>{html.escape(subtitle)}</div></div>")


def table(df: pd.DataFrame, fmt: Optional[dict] = None, max_rows: int = 30, caption: str = ""):
    """Tableau stylé (Styler pandas) lisible en clair comme en sombre."""
    d = df.head(max_rows)
    sty = d.style.hide(axis="index")
    if fmt:
        sty = sty.format(fmt, na_rep="—")
    else:
        sty = sty.format(precision=2, na_rep="—", thousands=" ")
    sty = sty.set_table_styles([
        {"selector": "th", "props": f"background:#eef3fb;color:{INK};font-weight:600;padding:6px 10px;text-align:left"},
        {"selector": "td", "props": "padding:5px 10px"},
        {"selector": "caption", "props": f"caption-side:top;font-weight:700;color:{INK};padding:4px 0"},
    ])
    if caption:
        sty = sty.set_caption(caption)
    return sty


# --------------------------------------------------------------------------------------
# Figures
# --------------------------------------------------------------------------------------


# Pays d'Afrique (ISO3) dessinés en fond de carte, pour maîtriser les frontières tracées.
AFRICA_ISO3 = ["DZA", "AGO", "BEN", "BWA", "BFA", "BDI", "CPV", "CMR", "CAF", "TCD", "COM", "COD", "COG", "CIV", "DJI",
               "EGY", "GNQ", "ERI", "SWZ", "ETH", "GAB", "GMB", "GHA", "GIN", "GNB", "KEN", "LSO", "LBR", "LBY", "MDG",
               "MWI", "MLI", "MRT", "MUS", "MAR", "ESH", "MOZ", "NAM", "NER", "NGA", "RWA", "STP", "SEN", "SYC", "SLE",
               "SOM", "ZAF", "SSD", "SDN", "TZA", "TGO", "TUN", "UGA", "ZMB", "ZWE"]
# Territoires dessinés avec le pays indiqué (même couleur, sans frontière intérieure).
# Le Maroc est représenté avec son Sahara.
MAP_MERGE = {"MAR": ["ESH"]}


def fig_availability_map(val: pd.DataFrame, synthetic: bool = False) -> go.Figure:
    d = val[val["iso3"].str.len() == 3].copy()
    d = d[d["iso3"] != "XTS"]
    merged = {t for k, ts in MAP_MERGE.items() for t in ts}
    seamless = set(MAP_MERGE) | merged
    fig = go.Figure()

    # Fond : tous les pays africains, bordures blanches, sauf entre un pays et ses territoires fusionnés
    base = [c for c in AFRICA_ISO3 if c not in set(d["iso3"]) and c not in merged]
    for k, ts in MAP_MERGE.items():
        if k not in set(d["iso3"]) and k in base:
            base += ts
    fig.add_trace(go.Choropleth(
        locations=base, z=[1] * len(base), colorscale=[[0, "#e9e8e4"], [1, "#e9e8e4"]], showscale=False,
        marker_line_color="white", marker_line_width=[0 if c in seamless else 1 for c in base],
        hoverinfo="skip", showlegend=False))

    for v in ["active", "restricted", "closed"]:
        s = d[d["verdict"] == v]
        if s.empty:
            continue
        locs, cdata = [], []
        for r in s.itertuples():
            for loc in [r.iso3] + MAP_MERGE.get(r.iso3, []):
                locs.append(loc)
                cdata.append([r.country_fr, r.domain, r.raison if isinstance(r.raison, str) else ""])
        fig.add_trace(go.Choropleth(
            locations=locs, z=[1] * len(locs), colorscale=[[0, STATUS[v]], [1, STATUS[v]]], showscale=False,
            name=STATUS_LABEL[v], marker_line_color="white",
            marker_line_width=[0 if c in seamless else 1 for c in locs], customdata=cdata,
            hovertemplate="<b>%{customdata[0]}</b><br>%{customdata[1]}<br>" + STATUS_LABEL[v]
                          + " — %{customdata[2]}<extra></extra>", showlegend=True))
    # Les frontières viennent des polygones ci-dessus (showcountries=False) : aucune ligne
    # n'est tracée entre le Maroc et son Sahara.
    fig.update_geos(scope="africa", showcountries=False, showland=True, landcolor="#e9e8e4", showcoastlines=False,
                    showframe=False, bgcolor=SURFACE, projection_type="natural earth", fitbounds="locations")
    fig.update_layout(title="Où Jumia est-il accessible aujourd'hui ?", height=600, margin=dict(l=10, r=10, t=60, b=70),
                      legend=dict(orientation="h", y=-0.02))
    return _source(fig, "Source : tests HTTP, TLS et robots.txt réalisés par le notebook.", synthetic)


def fig_response_times(val: pd.DataFrame, synthetic: bool = False) -> go.Figure:
    d = val[val["temps_ms"].notna()].sort_values("temps_ms")
    fig = go.Figure(go.Bar(
        y=d["country_fr"] + " · " + d["domain"], x=d["temps_ms"], orientation="h",
        marker_color=[STATUS.get(v, MUTED) for v in d["verdict"]], marker_line_width=0,
        text=[STATUS_LABEL.get(v, "") for v in d["verdict"]], textposition="outside",
        hovertemplate="%{y}<br>%{x:.0f} ms<extra></extra>"))
    fig.update_layout(title=_titre("Temps de réponse de la page d'accueil",
                                   "une mesure par site, en millisecondes"),
                      height=max(340, 32 * len(d) + 150),
                      xaxis_title="millisecondes", bargap=0.35)
    return _source(fig, "Source : requêtes HTTP du notebook.", synthetic)


def fig_categories(products: pd.DataFrame, synthetic: bool = False) -> go.Figure:
    d = products.groupby(["category_name", "division_hint"]).size().reset_index(name="n").sort_values("n")
    fig = go.Figure(go.Bar(y=d["category_name"], x=d["n"], orientation="h",
                           marker_color=[DIV_COLORS.get(x, MUTED) for x in d["division_hint"]],
                           text=d["n"], textposition="outside", hovertemplate="%{y} : %{x} produits<extra></extra>"))
    fig.update_layout(title=_titre("Produits relevés par catégorie",
                                   "la couleur est celle de la division COICOP du rayon"),
                      height=max(340, 28 * len(d) + 150),
                      xaxis_title="produits distincts", bargap=0.3)
    return _source(fig, SOURCE_JUMIA, synthetic=synthetic)


def fig_price_distribution(enr: pd.DataFrame, currency: str, synthetic: bool = False) -> go.Figure:
    fig = go.Figure()
    for div in [d for d in DIV_ORDER + sorted(COICOP_DIVISIONS) if d in set(enr["division"])][::-1]:
        s = enr[enr["division"] == div]
        if s.empty or div in [t.name[:2] for t in fig.data]:
            continue
        fig.add_trace(go.Box(x=s["price"], name=f"{div} {COICOP_SHORT.get(div, '')}", marker_color=DIV_COLORS.get(div, MUTED),
                             boxpoints="outliers", orientation="h", line_width=1.5, showlegend=False,
                             hovertemplate="%{x:,.0f} " + currency + "<extra></extra>"))
    fig.update_layout(title=_titre("Distribution des prix par division COICOP",
                                   "échelle logarithmique · la boîte couvre la moitié centrale "
                                   "des prix, le trait la médiane"),
                      xaxis_type="log", height=500, xaxis_title=f"prix affiché ({currency})")
    # Puissances de dix seules : les graduations mineures de Plotly donnent
    # « 2, 5, 1000, 2, 5, 10k », une suite qui se lit de travers.
    fig.update_xaxes(dtick=1)
    return _source(fig, SOURCE_JUMIA, synthetic=synthetic)


def fig_unit_prices(enr: pd.DataFrame, currency: str, top: int = 8, synthetic: bool = False) -> go.Figure:
    d = enr[enr["unit"].isin(["kg", "l"]) & enr["unit_price"].notna()]
    codes = d["coicop"].value_counts().head(top).index
    d = d[d["coicop"].isin(codes)]
    from .config import coicop_label

    fig = go.Figure()
    for code in codes:
        s = d[d["coicop"] == code]
        u = s["unit"].mode().iat[0]
        label = coicop_label(code)
        label = (label[:34] + "…") if len(label) > 35 else label
        fig.add_trace(go.Box(x=s["unit_price"], name=f"{label} (/{u})", orientation="h", boxpoints="all",
                             jitter=0.4, pointpos=0, marker=dict(size=6, color=DIV_COLORS.get(code[:2], MUTED), opacity=0.6),
                             line_color=INK2, fillcolor="rgba(0,0,0,0)", showlegend=False,
                             customdata=s["name"], hovertemplate="%{customdata}<br>%{x:,.0f} " + currency + "<extra></extra>"))
    fig.update_layout(title=_titre("Prix au kilo ou au litre",
                                   "la dispersion entre marques et formats, en %s · "
                                   "échelle logarithmique · un point par produit" % currency),
                      xaxis_type="log", height=max(380, 52 * len(codes) + 180))
    fig.update_xaxes(dtick=1)
    return _source(fig, SOURCE_JUMIA, synthetic=synthetic)


def fig_confusion(mat: pd.DataFrame, title: str) -> go.Figure:
    labels = sorted(set(mat.index) | set(mat.columns))
    m = mat.reindex(index=labels, columns=labels, fill_value=0)
    fig = go.Figure(go.Heatmap(z=m.values, x=[f"{c}" for c in labels], y=[f"{c}" for c in labels],
                               colorscale=[[i / (len(SEQ) - 1), c] for i, c in enumerate(SEQ)], showscale=False,
                               text=m.values, texttemplate="%{text}", hovertemplate="référence %{y} → prédit %{x} : %{z}<extra></extra>"))
    fig.update_layout(title=title, xaxis_title="division prédite", yaxis_title="division de référence",
                      yaxis_autorange="reversed", height=440, width=520)
    return fig


def fig_indices(ind: pd.DataFrame, reference: str, synthetic: bool = False,
                diagnostics: Optional[pd.DataFrame] = None) -> go.Figure:
    """L'indice par division, et l'ensemble en encre foncée.

    `diagnostics` est facultatif mais change ce qui est montré : sans aucun
    produit apparié, un indice reste à 100 d'un bout à l'autre et la courbe
    plate se lit « les prix sont stables ». On refuse alors de la tracer.
    """
    apparies = None
    if diagnostics is not None and "appariés" in getattr(diagnostics, "columns", []):
        apparies = int(pd.to_numeric(diagnostics["appariés"], errors="coerce").fillna(0).sum())

    e = ind[ind["série"] == "Ensemble"].sort_values("period")
    if apparies == 0 or (apparies is None and _immobile(ind["index"])):
        periodes = list(dict.fromkeys(ind["period"].astype(str))) if len(ind) else []
        return panneau(
            "Aucun produit apparié : il n'y a pas d'indice à tracer",
            "Un indice compare le prix d'un <b>même</b> produit d'un mois sur "
            "l'autre.<br>Sur les %d période(s) chargées — %s —<br>aucun produit "
            "n'est présent deux mois de suite.<br><br>Il faut des collectes "
            "rapprochées, ou davantage d'archives." % (
                len(periodes),
                (periodes[0] + " … " + periodes[-1]) if periodes else "aucune"),
            hauteur=420)

    # Les mois reellement mesures : ceux ou des produits ont ete apparies.
    # Ailleurs l'indice est reconduit, et le tracer plein affirmerait une
    # mesure qui n'a pas eu lieu.
    mesures = set()
    if diagnostics is not None and {"period", "appariés"} <= set(getattr(diagnostics, "columns", [])):
        par_periode = diagnostics.groupby("period")["appariés"].sum()
        mesures = {str(p) for p, n in par_periode.items() if n > 0}

    fig = go.Figure()
    series = [s for s in DIV_ORDER + sorted(COICOP_DIVISIONS) if s in set(ind["série"])]
    reconduites = 0
    for s in dict.fromkeys(series):
        d = ind[ind["série"] == s].sort_values("period")
        # Une division qui ne bouge jamais est reconduite d'un bout a l'autre.
        # La laisser dans la legende y ajoute une entree pour une courbe
        # invisible : onze entrees sur quatre lignes, dont neuf inutiles.
        if _immobile(d["index"]):
            reconduites += 1
            fig.add_trace(go.Scatter(
                x=d["period"], y=d["index"], name=d["libellé"].iat[0],
                mode="lines", opacity=0.35, showlegend=False,
                line=dict(width=1.2, color=DIV_COLORS.get(s, MUTED), dash="dot"),
                hovertemplate="%{x} : %{y:.1f} (reconduit)<extra>"
                              + d["libellé"].iat[0] + "</extra>"))
            continue
        fig.add_trace(go.Scatter(
            x=d["period"], y=d["index"], name=d["libellé"].iat[0], mode="lines",
            opacity=0.9, line=dict(width=2.4, color=DIV_COLORS.get(s, MUTED)),
            hovertemplate="%{x} : %{y:.1f}<extra>" + d["libellé"].iat[0] + "</extra>"))

    # L'ensemble en deux passes : le trait fin pointille court sur toute la
    # periode, le trait epais ne couvre que les mois mesures.
    if mesures:
        fig.add_trace(go.Scatter(x=e["period"], y=e["index"], name="Ensemble (reconduit)",
                                 mode="lines", line=dict(width=1.6, color=INK, dash="dot"),
                                 opacity=0.55, hoverinfo="skip"))
        visible = e["index"].where(e["period"].astype(str).isin(mesures))
        fig.add_trace(go.Scatter(x=e["period"], y=visible, name="Ensemble (mesuré)",
                                 mode="lines+markers", connectgaps=False,
                                 line=dict(width=4, color=INK),
                                 marker=dict(size=7, line=dict(width=2, color=SURFACE)),
                                 hovertemplate="%{x} : <b>%{y:.1f}</b><extra>Ensemble</extra>"))
    else:
        fig.add_trace(go.Scatter(x=e["period"], y=e["index"], name="Ensemble", mode="lines+markers",
                                 line=dict(width=4, color=INK),
                                 marker=dict(size=7, line=dict(width=2, color=SURFACE)),
                                 hovertemplate="%{x} : <b>%{y:.1f}</b><extra>Ensemble</extra>"))

    last = e.iloc[-1]
    fig.add_annotation(x=last["period"], y=last["index"], text=f"<b>{last['index']:.1f}</b>", showarrow=False,
                       xanchor="left", xshift=12, font=dict(color=INK, size=14),
                       bgcolor=SURFACE, borderpad=3)
    fig.add_hline(y=100, line=dict(color=MUTED, width=1, dash="dot"))
    precision = "base 100 = %s" % reference
    if reconduites:
        precision += (" · %d division(s) sans appariement, reconduites en "
                      "pointillé et hors légende" % reconduites)
    fig.update_layout(title=_titre("Indice des prix par division COICOP", precision),
                      height=540, hovermode="x unified", yaxis_title="indice",
                      margin=dict(r=96))
    _periods(fig, list(dict.fromkeys(e["period"].astype(str))))
    return _source(fig, synthetic=synthetic)


METHOD_COLORS = {"jevons": SERIES[0], "dutot": SERIES[2], "carli": SERIES[7], "geks-jevons": SERIES[6],
                 "geks-tornqvist": SERIES[1], "jevons (prix hors promo)": INK2}


def fig_methods(mc: pd.DataFrame, reference: str, synthetic: bool = False) -> go.Figure:
    """Les formules côte à côte — non pour hésiter, mais pour montrer l'écart."""
    if _immobile(mc["index"]):
        return panneau(
            "Les formules ne peuvent pas être comparées",
            "Faute de produits appariés, les cinq formules donnent la même "
            "ligne plate.<br>Leur écart — ce que cette figure sert à montrer — "
            "n'apparaît qu'avec<br>des prix relevés deux mois de suite sur les "
            "mêmes produits.", hauteur=380)

    fig = go.Figure()
    etiquettes = []
    for meth, d in mc.groupby("méthode", sort=False):
        d = d.sort_values("period")
        fig.add_trace(go.Scatter(x=d["period"], y=d["index"], name=meth, mode="lines",
                                 line=dict(width=3.4 if meth == "jevons" else 2,
                                           color=METHOD_COLORS.get(meth, MUTED),
                                           dash="dash" if "promo" in meth else None),
                                 hovertemplate="%{y:.2f}<extra>" + meth + "</extra>"))
        if meth in ("jevons", "carli", "geks-tornqvist"):
            etiquettes.append((float(d["index"].iat[-1]), meth, d["period"].iat[-1]))

    # Deux formules qui finissent au même niveau superposaient leurs étiquettes
    # — « geks-tj100.0 » sur la capture. On les empile du plus haut au plus
    # bas en gardant un écart minimal, en pixels et non en unités d'indice.
    etiquettes.sort(key=lambda t: -t[0])
    dernier_y = None
    for valeur, meth, periode in etiquettes:
        decalage = 0
        if dernier_y is not None and abs(valeur - dernier_y) < 1e-9:
            decalage = -16
        dernier_y = valeur
        fig.add_annotation(x=periode, y=valeur, text="%s %.1f" % (meth, valeur),
                           showarrow=False, xanchor="left", xshift=10, yshift=decalage,
                           font=dict(size=11, color=INK2), bgcolor=SURFACE, borderpad=2)

    fig.update_layout(title=_titre("L'indice d'ensemble selon la formule retenue",
                                   "base 100 = %s · le Jevons est la formule recommandée" % reference),
                      height=500, hovermode="x unified", margin=dict(r=168))
    _periods(fig, sorted(set(mc["period"].astype(str))))
    return _source(fig, synthetic=synthetic)


def fig_contributions(contrib: pd.DataFrame, ens: pd.DataFrame, synthetic: bool = False) -> go.Figure:
    if not len(contrib) or _immobile(contrib["contribution_pp"]):
        return panneau(
            "Aucune contribution à décomposer",
            "Cette figure répartit la variation mensuelle entre les "
            "divisions.<br>Sans variation — faute de produits appariés — il n'y "
            "a rien à répartir.", hauteur=360)
    fig = go.Figure()
    divs = [d for d in DIV_ORDER + sorted(COICOP_DIVISIONS) if d in set(contrib["division"])]
    for d in dict.fromkeys(divs):
        s = contrib[contrib["division"] == d].sort_values("period")
        fig.add_trace(go.Bar(x=s["period"], y=s["contribution_pp"], name=s["libellé"].iat[0],
                             marker_color=DIV_COLORS.get(d, MUTED), marker_line=dict(color=SURFACE, width=1),
                             hovertemplate="%{y:+.2f} pp<extra>" + s["libellé"].iat[0] + "</extra>"))
    e = ens.dropna(subset=["mensuelle_%"]).sort_values("period")
    fig.add_trace(go.Scatter(x=e["period"], y=e["mensuelle_%"], name="Ensemble (variation mensuelle)",
                             mode="lines+markers", line=dict(color=INK, width=2), marker=dict(size=8),
                             hovertemplate="<b>%{y:+.2f} %</b><extra>Ensemble</extra>"))
    fig.add_hline(y=0, line=dict(color=INK2, width=1))
    fig.update_layout(barmode="relative", bargap=0.25,
                      title=_titre("Qui fait monter l'indice, et de combien",
                                   "contribution de chaque division à la variation mensuelle, "
                                   "en points de pourcentage"),
                      height=500, hovermode="x unified", yaxis_title="points de pourcentage")
    _periods(fig, sorted(set(contrib["period"].astype(str))))
    return _source(fig, synthetic=synthetic)


def fig_promo(promo: pd.DataFrame, synthetic: bool = False) -> go.Figure:
    p = promo.pivot(index="libellé", columns="period", values="part_promo")
    # Un mois sans relevé pour aucune division produit une colonne entièrement
    # vide. Neuf colonnes de « NaN » alignées, comme sur la capture, n'apprennent
    # rien et donnent l'impression d'un défaut. On ne garde que ce qui existe.
    # Un mois ou une seule division a un releve remplit la colonne de cases
    # vides. Vingt-huit colonnes ainsi, comme sur le rendu precedent, forment
    # un mur de « NaN » qui ne dit rien et fait croire a une panne. On ne garde
    # que les mois ou la comparaison entre divisions a un sens.
    remplissage = p.notna().sum()
    gardees = [c for c in p.columns if remplissage[c] >= 2]
    omis = len(p.columns) - len(gardees)
    p = p[gardees].dropna(how="all") if gardees else p.iloc[0:0]
    if p.empty:
        return panneau("Pas encore de quoi comparer les promotions",
                       "Cette figure compare, mois par mois, la part des "
                       "produits affichés<br>avec un prix barré. Il y faut au "
                       "moins deux divisions relevées le même mois.",
                       hauteur=340)
    precision = "part des produits affichés avec un prix barré"
    if omis:
        precision += " · %d mois trop peu couverts sont omis" % omis
    # Le texte est construit a la main : « %{text:.0f} » ecrit « NaN » dans
    # les cases vides au lieu de les laisser muettes.
    etiquettes = [["" if pd.isna(v) else "%.0f" % v for v in ligne]
                  for ligne in p.values]
    # Sans `zmax`, une matrice entierement a zero fait centrer l'echelle sur
    # zero : elle s'etale de -0,5 % a +0,5 %, peint toutes les cases en bleu
    # moyen, et « aucune promotion » se lit « beaucoup de promotions ».
    maximum = float(np.nanmax(p.values)) if p.notna().any().any() else 0.0
    fig = go.Figure(go.Heatmap(z=p.values, x=p.columns, y=p.index,
                               zmin=0, zmax=max(maximum, 1.0),
                               colorscale=[[i / (len(SEQ) - 1), c] for i, c in enumerate(SEQ)],
                               colorbar=dict(title=dict(text="%", side="top"), ticksuffix=" %",
                                             thickness=14, outlinewidth=0),
                               xgap=2, ygap=2, hoverongaps=False,
                               text=etiquettes, texttemplate="%{text}",
                               textfont=dict(size=12),
                               hovertemplate="%{y} · %{x} : %{z:.1f} % des produits avec prix barré<extra></extra>"))
    fig.update_layout(title=_titre("Fréquence des prix barrés, par division et par mois", precision),
                      height=max(320, 42 * len(p) + 150), margin=dict(t=120))
    _periods(fig, [str(c) for c in p.columns])
    return _source(fig, synthetic=synthetic)


def fig_diagnostics(diag: pd.DataFrame, synthetic: bool = False) -> go.Figure:
    d = diag.groupby("period")[["appariés", "entrées", "sorties", "imputés"]].sum().reset_index()
    if not len(d) or d[["entrées", "sorties", "imputés"]].to_numpy().sum() == 0:
        return panneau("Rien à montrer sur le renouvellement",
                       "Aucune entrée, sortie ni imputation n'a été relevée.",
                       hauteur=300)
    fig = go.Figure()
    # Les produits appariés d'abord, en fond : c'est eux qui portent l'indice,
    # et les trois autres séries ne se lisent que par rapport à leur nombre.
    fig.add_trace(go.Bar(x=d["period"], y=d["appariés"], name="appariés",
                         marker_color=SERIES[0], opacity=0.28,
                         marker_line=dict(width=0), width=0.72,
                         hovertemplate="%{y} produits appariés<extra></extra>"))
    for i, c in enumerate(["entrées", "sorties", "imputés"]):
        fig.add_trace(go.Bar(x=d["period"], y=d[c], name=c, marker_color=SERIES[[1, 7, 6][i]],
                             marker_line=dict(color=SURFACE, width=1), width=0.2,
                             offset=(-0.3 + 0.21 * i),
                             hovertemplate="%{y}<extra>" + c + "</extra>"))
    precision = ("en fond, les produits appariés d'un mois sur l'autre ; "
                 "devant, les mouvements")
    # Le mois ou un panel entier arrive compte des milliers d'entrees quand les
    # autres en comptent quelques dizaines : a l'echelle lineaire, une seule
    # barre occupe la figure et le reste devient un trait. L'echelle
    # logarithmique rend les deux lisibles — a condition de le dire.
    valeurs = d[["appariés", "entrées", "sorties", "imputés"]].to_numpy().ravel()
    valeurs = valeurs[valeurs > 0]
    log = len(valeurs) > 2 and float(valeurs.max()) > 20 * float(np.median(valeurs))
    if log:
        # `dtick=1` ne garde que les puissances de dix. Par defaut, Plotly
        # intercale des graduations mineures — « 2, 1000, 5, 100, 5 » — qui se
        # lisent comme une suite de nombres sans rapport.
        fig.update_yaxes(type="log", dtick=1, showgrid=True)
        precision += " · échelle logarithmique"
    fig.update_layout(barmode="overlay",
                      title=_titre("Le catalogue se renouvelle — ce que l'indice en garde",
                                   precision),
                      height=440, hovermode="x unified", yaxis_title="produits")
    _periods(fig, sorted(set(d["period"].astype(str))))
    return _source(fig, synthetic=synthetic)


def fig_comparison(m: pd.DataFrame, source: str, synthetic: bool = False) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=m["period"], y=m["officiel_rebasé"], name=f"IPC officiel ({source})", mode="lines+markers",
                             line=dict(color=SERIES[1], width=2), marker=dict(size=8)))
    fig.add_trace(go.Scatter(x=m["period"], y=m["jumia_rebasé"], name="Indice en ligne (ensemble)", mode="lines+markers",
                             line=dict(color=INK, width=3), marker=dict(size=8)))
    fig.update_layout(title=_titre("L'indice en ligne face à l'IPC officiel",
                                   "ramenés à la même base : premier mois commun = 100"),
                      height=470, hovermode="x unified", yaxis_title="indice")
    _periods(fig, sorted(set(m["period"].astype(str))))
    return _source(fig, f"Sources : relevés en ligne et sources officielles (calculs du dispositif) ; IPC officiel : {source}.", synthetic)


def fig_comparison_monthly(m: pd.DataFrame, synthetic: bool = False) -> go.Figure:
    d = m.dropna(subset=["jumia_mensuelle_%"])
    fig = go.Figure()
    fig.add_trace(go.Bar(x=d["period"], y=d["officiel_mensuelle_%"], name="IPC officiel", marker_color=SERIES[1]))
    fig.add_trace(go.Bar(x=d["period"], y=d["jumia_mensuelle_%"], name="Indice en ligne", marker_color=SERIES[0]))
    fig.add_hline(y=0, line=dict(color=INK2, width=1))
    fig.update_layout(barmode="group", title=_titre("Variations mensuelles comparées",
                                   "en pourcentage, mois après mois"),
                      height=420, hovermode="x unified", yaxis_title="%")
    _periods(fig, sorted(set(m["period"].astype(str))))
    return _source(fig, synthetic=synthetic)


def fig_llm_usage(usage: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Bar(x=usage["fournisseur"] + " · " + usage["modèle"], y=usage["appels"], name="appels",
                         marker_color=SERIES[0], text=usage["appels"], textposition="outside"))
    fig.update_layout(title=_titre("Appels par fournisseur de modèle"),
                      height=360, yaxis_title="appels", showlegend=False)
    return fig
