# -*- coding: utf-8 -*-
"""Collecte des loyers d'habitation — COICOP 04.1, « locations réelles ».

Pourquoi ce module existe
-------------------------
Le loyer est le poste non alimentaire le plus lourd d'un panier africain : dans
l'IHPC ivoirien, le groupe **04.1 pèse 10,65 %**, deuxième poste de tout
l'indice derrière la restauration. Or il est **entièrement absent** du commerce
en ligne : sur 51 320 produits collectés sur Jumia, la division 04 n'en comptait
que 35, tous des raccords de bouteille de gaz et du charbon. Un indice bâti sans
les loyers laisse de côté un dixième de la dépense des ménages.

Les loyers se relèvent donc ailleurs : sur les sites de petites annonces
immobilières, qui publient des offres de location avec leur prix.

Ce que ce module ne fait pas, et pourquoi
-----------------------------------------
**Il ne trie pas les locations des ventes.** Les rayons de ces sites mélangent
les deux — CoinAfrique affiche « Location appartement 2 pièces, 200 000 CFA »
à côté de « Vente studio, 17 500 000 CFA ». On pourrait filtrer sur un montant
plancher, mais les bornes dépendent de la devise et de la périodicité : un loyer
nigérian est souvent annoncé **à l'année**, un loyer égyptien au mois. Mettre
ces bornes dans le collecteur, c'est figer un jugement dans la couche qui doit
rester fidèle. On enregistre donc le **texte du prix tel qu'il est affiché** —
« 85,000 EGP/month », « FOR RENT ₦ 2,500,000 » — et le tri se fait à l'analyse,
où il est visible et discutable.

**Il ne force aucun accès.** Les sources ont été sondées le 20/10/2026 ; celles
qui refusent sont nommées plus bas avec le motif de leur refus, afin que
personne ne les retente en croyant à une panne.

Un relevé d'annonces n'est pas un relevé d'enquête
--------------------------------------------------
Une annonce porte un prix **demandé** ; une enquête mesure un loyer **pratiqué**.
Sur la Côte d'Ivoire, le projet voisin a mesuré l'écart entre les deux : l'indice
issu des annonces surestimait de 3,8 % en mai 2024, 4,4 % en juin, 5,3 % en
juillet. L'écart ne se contente pas d'exister, **il se creuse** — un biais
constant se corrige par un calage, un biais qui dérive ne se corrige pas. Ces
relevés sont donc un complément à instruire, non un substitut à l'enquête.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import date
from typing import Optional

import pandas as pd
from bs4 import BeautifulSoup

from .utils import now_utc

log = logging.getLogger("jumia_cpi.loyers")

DIVISION = "04"
GROUPE = "04.1"


@dataclass(frozen=True)
class SourceLoyers:
    """Une source d'annonces de location, décrite et non codée.

    Les sélecteurs ne sont pas écrits de mémoire : ils ont été trouvés en
    comptant, dans la page réelle, les structures qui se répètent et portent un
    montant. Le nombre d'annonces observé à la sondage figure en commentaire.
    """

    nom: str
    pays: str
    intitule: str
    devise: str
    urls: tuple
    carte: str                      # sélecteur CSS d'une vignette d'annonce
    gabarit_pagination: str = ""    # « {url}?page={page} », vide si sans pages
    pages_max: int = 10
    # Vrai quand l'adresse interrogée est une recherche de locations et rien
    # d'autre — « /property-to-rent », « /appartements-a-louer ». L'éditeur a
    # alors déjà déclaré la nature, et une vignette muette (« AVAILABLE NOW
    # KSh 250 000 5 Bedroom House ») est une location, non une inconnue. Faux
    # pour les rubriques qui mêlent ventes et locations.
    rubrique_de_location: bool = False
    # « requests » lit le HTML servi ; « navigateur » le fait rendre par
    # Chromium quand les vignettes n'arrivent qu'après exécution du script de
    # la page. Le second coûte des secondes par page : on ne le choisit que
    # lorsque le premier a été mesuré insuffisant.
    moteur: str = "requests"
    note: str = ""


SOURCES: tuple = (
    SourceLoyers(
        nom="coinafrique_ci", pays="CI", devise="XOF",
        intitule="Annonces de location — CoinAfrique Côte d'Ivoire",
        urls=("https://ci.coinafrique.com/categorie/appartements",
              "https://ci.coinafrique.com/categorie/villas"),
        carte="div.card.ad__card.round",
        gabarit_pagination="{url}?page={page}",
        pages_max=10,
        note="81 annonces par page au sondage du 20/10/2026. La rubrique "
             "« appartements meublés » est volontairement écartée : elle est "
             "facturée à la nuitée, ce n'est pas un loyer mensuel. Au-delà "
             "d'une vingtaine de pages le site répond 503.",
    ),
    SourceLoyers(
        nom="coinafrique_sn", pays="SN", devise="XOF",
        intitule="Annonces de location — CoinAfrique Sénégal",
        urls=("https://sn.coinafrique.com/categorie/appartements",
              "https://sn.coinafrique.com/categorie/villas"),
        carte="div.card.ad__card.round",
        gabarit_pagination="{url}?page={page}",
        pages_max=10,
        note="84 annonces par page au sondage du 20/10/2026.",
    ),
    SourceLoyers(
        nom="propertypro_ng", pays="NG", devise="NGN",
        intitule="Annonces de location — PropertyPro Nigeria",
        urls=("https://www.propertypro.ng/property-for-rent",),
        carte="div.property-listing",
        gabarit_pagination="{url}?page={page}",
        pages_max=10,
        rubrique_de_location=True,
        note="22 annonces par page au sondage du 20/10/2026. ATTENTION : les "
             "loyers nigérians sont couramment annoncés à l'année. Le texte du "
             "prix est conservé pour que la périodicité reste lisible. "
             "Son robots.txt autorise « ?page= » et n'interdit que /admin, "
             "/backend et les paramètres de filtre (sort, max_price, type, "
             "area…). Un refus de robots.txt sur ce site pendant une collecte "
             "signifie donc que le fichier est devenu illisible sous charge — "
             "la RFC 9309 impose alors de tout refuser — et non que l'éditeur "
             "s'y oppose : il faut réessayer après une pause, pas insister.",
    ),
    SourceLoyers(
        nom="property24_ke", pays="KE", devise="KES",
        intitule="Annonces de location — Property24 Kenya",
        urls=("https://www.property24.co.ke/property-to-rent",),
        carte="div.p24_regularTile",
        gabarit_pagination="{url}?page={page}",
        pages_max=10,
        rubrique_de_location=True,
        note="21 annonces par page au sondage du 20/10/2026. La pagination est "
             "« ?page= » : les formes « /p2 » et « /page-2 » répondent 404, et "
             "la première collecte s'est arrêtée à la page 1 pour cette raison. "
             "Jiji Kenya et BuyRentKenya répondent 403 : décision de "
             "l'éditeur, non contournée.",
    ),
    SourceLoyers(
        nom="propertyfinder_eg", pays="EG", devise="EGP",
        intitule="Annonces de location — Property Finder Égypte",
        urls=("https://www.propertyfinder.eg/en/rent/properties-for-rent.html",),
        carte="article[class*='property-card__wrapper']",
        gabarit_pagination="{url}?page={page}",
        pages_max=10,
        rubrique_de_location=True,
        note="25 annonces par page au sondage du 20/10/2026. Le prix porte sa "
             "périodicité dans le texte : « 85,000 EGP/month ».",
    ),
    SourceLoyers(
        nom="meqasa_gh", pays="GH", devise="GHS",
        intitule="Annonces de location — Meqasa Ghana",
        urls=("https://meqasa.com/1-bedroom-apartments-for-rent-in-ghana",
              "https://meqasa.com/2-bedroom-apartments-for-rent-in-ghana",
              "https://meqasa.com/3-bedroom-apartments-for-rent-in-ghana",
              "https://meqasa.com/2-bedroom-houses-for-rent-in-ghana",
              "https://meqasa.com/3-bedroom-houses-for-rent-in-ghana"),
        carte="div.mqs-prop-dt-wrapper",
        gabarit_pagination="",
        pages_max=1,
        rubrique_de_location=True,
        moteur="navigateur",
        note="32 vignettes par page au sondage du 20/10/2026, sur 1 476 "
             "annonces annoncees pour le seul segment une chambre. "
             "DEUX PIEGES, tous deux payes : l'adresse « /houses-for-rent-in-"
             "ghana » ne porte aucune annonce, seuls les chemins par nombre de "
             "chambres en portent — ils ont ete trouves dans le plan de site "
             "« /sitemap.xml », qui liste 478 adresses. Et le rendu doit "
             "attendre « domcontentloaded » puis defiler : avec "
             "« networkidle », la page expire et revient non rendue, ce qui "
             "faisait conclure a tort que le site n'avait pas d'annonces "
             "(160 593 caracteres contre 367 641). meqasa.com n'a pas de "
             "robots.txt — un 404 vaut autorisation selon la RFC 9309. "
             "ghanapropertycentre.com et Jiji Ghana repondent 403 ; "
             "tonaton.com.gh et ghanapropertylistings.com refusent par "
             "robots.txt.",
    ),
    SourceLoyers(
        nom="mubawab_ma", pays="MA", devise="MAD",
        intitule="Annonces de location — Mubawab Maroc",
        urls=("https://www.mubawab.ma/fr/sc/appartements-a-louer",),
        carte="div.listingBox",
        gabarit_pagination="",
        pages_max=1,
        rubrique_de_location=True,
        note="34 vignettes sur la premiere page au sondage du 20/10/2026, sur "
             "15 392 resultats annonces. PAGINATION IMPOSSIBLE EN L'ETAT : la "
             "page ne porte aucun lien de page suivante, « ?page=2 » rend "
             "exactement les memes annonces que « ?page=1 », et « :p:2 » comme "
             "« /page:2 » redirigent. Le site charge la suite par defilement, "
             "ce qui demanderait de piloter un navigateur. On s'en tient donc "
             "a une page : trente-quatre annonces honnetes valent mieux que "
             "trois cent quarante dont trois cents sont des doublons. "
             "Avito.ma a ete ecarte : noms de classes haches, changeant a "
             "chaque deploiement, et reponses irregulieres.",
    ),
    SourceLoyers(
        nom="red_ug", pays="UG", devise="UGX",
        intitule="Annonces de location — Real Estate Database Ouganda",
        urls=("https://realestatedatabase.net/",),
        carte="div.list-item",
        gabarit_pagination="",
        pages_max=1,
        note="48 vignettes sur la page d'accueil au sondage du 20/10/2026, "
             "dont la moitié sont des espaceurs vides : 24 annonces lisibles. "
             "LA RECHERCHE EST MORTE : « HouseList.aspx » répond 404 pour "
             "toutes ses formes — avec ou sans paramètres, dans les deux "
             "casses, avec ou sans « www » — alors que la page d'accueil y "
             "renvoie encore 127 fois. Ce sont des liens périmés après refonte, "
             "et la page d'accueil est donc la seule surface qui réponde. "
             "DEVISE : le parc formel de Kampala est annoncé en dollars "
             "(« USD 3,000 p/m »), pas en shillings ; la devise déclarée ici "
             "n'est qu'un défaut, c'est celle lue dans l'annonce qui compte. "
             "RÉFÉRENCE : le texte porte « Code - 257211 » avant le prix — "
             "lire le premier nombre venu donnait le numéro d'annonce comme "
             "loyer. Jiji Ouganda répond 403 ; realtoruganda.com, lamudi.ug, "
             "housingug.com et property24.co.ug sont refusés par robots.txt.",
    ),
)

# Pays de l'étude sans source utilisable, avec le motif exact. Déclarés ici
# pour que l'absence soit une information et non un oubli.
# Vide : les huit pays de l'étude ont une source. Le dictionnaire reste en
# place parce qu'un pays ajouté demain sans source doit pouvoir dire pourquoi —
# une absence expliquée est une information, une absence muette est un oubli.
#
# Il a porté le Ghana pendant quelques heures, sur un motif qui s'est révélé
# faux trois fois de suite : « Mubawab rend en JavaScript » (non testé),
# « Meqasa n'a pas d'annonces » (mauvaise adresse), « le rendu JavaScript n'y
# change rien » (mauvais mode d'attente). La leçon est consignée dans la note
# de `meqasa_gh` : une conclusion négative sur une source demande autant de
# mesures qu'une conclusion positive.
SANS_SOURCE: dict = {}

# Les marques de devise rencontrées, et le code ISO correspondant. C'est la
# devise **trouvée dans l'annonce** qui est retenue, non celle supposée du pays :
# en Ouganda, les loyers du parc formel sont annoncés en dollars.
DEVISES = {
    "FCFA": "XOF", "CFA": "XOF", "XOF": "XOF",
    "KSH": "KES", "KES": "KES",
    "UGX": "UGX", "SHS": "UGX",
    "NGN": "NGN", "₦": "NGN",
    "GHS": "GHS", "GH₵": "GHS",
    "MAD": "MAD", "DH": "MAD", "DHS": "MAD",
    "EGP": "EGP", "LE": "EGP",
    "USD": "USD", "$": "USD", "EUR": "EUR", "€": "EUR",
}
_MARQUES = sorted(DEVISES, key=len, reverse=True)
_ALT = "|".join(re.escape(m) for m in _MARQUES)
# Un montant : soit des groupes de trois chiffres séparés, soit une suite de
# chiffres. Les groupes doivent faire exactement trois chiffres, sinon
# « KSh 250 000 5 Bedroom » est lu 2 500 005 — l'espace puis le « 5 » de
# « 5 Bedroom » sont avalés par la classe de séparateurs.
_SEP = r"[\s\u00a0,\.]"
_VAL = r"(?:\d{1,3}(?:%s\d{3})+|\d{3,})" % _SEP
# Un montant ancré à une devise, dans un sens ou dans l'autre.
AVANT = re.compile(r"(?P<dev>%s)\s*(?P<val>%s)" % (_ALT, _VAL), re.I)
APRES = re.compile(r"(?P<val>%s)\s*(?P<dev>%s)\b" % (_VAL, _ALT), re.I)
# Ce qui précède une référence d'annonce. « Code - 257211 USD 3,000 » : sans ce
# garde-fou, le numéro d'annonce était lu comme un loyer — une valeur plausible
# et fausse. Le projet voisin avait documenté le même piège sur yapgi ; la leçon
# est ici appliquée au lieu d'être relue.
REFERENCE = re.compile(r"(code|ref|r[ée]f|r[ée]f[ée]rence|n[°o]|#|id)\s*[-:.]?\s*$",
                       re.I)

# Ce qui distingue, dans le texte affiché, une location d'une vente.
# « location » nu est volontairement absent : sur un site anglophone,
# « Location - Kololo District » désigne un lieu, et il faisait passer une villa
# « for sale » pour indéterminée.
LOCATION = re.compile(
    r"\bfor rent\b|\bto rent\b|\bstatus\s*[-:]\s*for rent\b|"
    r"\ba louer\b|\bà louer\b|\ben location\b|"
    r"\blocations?\s+(d[eu'’]\s*)?(appartement|appartements|villa|villas|maison|"
    r"maisons|studio|chambre|terrain|bureau|boutique|duplex)|"
    r"\bp/m\b|/month|per month|per annum|\bmensuel\b|\bmonthly\b", re.I)
VENTE = re.compile(r"\bventes?\s+(d[eu'’]\s*)?(appartement|appartements|villa|"
                   r"villas|maison|maisons|studio|terrain|duplex)|"
                   r"\bfor sale\b|\ba vendre\b|\bà vendre\b|\bsale price\b|"
                   r"\bstatus\s*[-:]\s*for sale\b", re.I)


def _montant_et_devise(texte: str,
                       defaut: str = "") -> tuple[Optional[float], str]:
    """Le premier montant **ancré à une devise**, et cette devise.

    Exiger la devise est ce qui sépare un loyer d'un numéro d'annonce, d'une
    surface ou d'un numéro de téléphone. Sans ancrage, aucune valeur n'est
    rendue : une case vide est une information, un identifiant pris pour un
    loyer est une erreur silencieuse qui se propage jusqu'à l'indice.
    """
    texte = texte or ""
    candidats = []
    for motif in (AVANT, APRES):
        for m in motif.finditer(texte):
            # Un nombre précédé de « Code - » ou « Réf. » est une référence.
            avant = texte[max(0, m.start("val") - 14):m.start("val")]
            if REFERENCE.search(avant):
                continue
            chiffres = re.sub(r"\D", "", m.group("val"))
            if len(chiffres) < 3:
                continue
            candidats.append((m.start(), float(chiffres),
                              DEVISES[m.group("dev").upper()]))
    if not candidats:
        return None, defaut
    candidats.sort()
    return candidats[0][1], candidats[0][2]


def _nature(texte: str, rubrique_de_location: bool = False) -> str:
    """« location », « vente » ou « indéterminée » — un indice, pas un verdict.

    `rubrique_de_location` dit que l'adresse interrogée ne contient que des
    locations. Une vignette qui ne le répète pas — « AVAILABLE NOW KSh 250 000
    5 Bedroom House Karen » — est alors une location, parce que l'éditeur l'a
    déclarée en plaçant l'annonce dans cette rubrique. Une vignette qui dit
    « for sale » reste une vente malgré la rubrique : ce que dit l'annonce
    l'emporte sur ce que dit la page.
    """
    loc, vte = bool(LOCATION.search(texte or "")), bool(VENTE.search(texte or ""))
    if loc and not vte:
        return "location"
    if vte and not loc:
        return "vente"
    if not loc and not vte and rubrique_de_location:
        return "location"
    return "indéterminée"


def _adresse(source: SourceLoyers, url: str, page: int) -> str:
    if page <= 1 or not source.gabarit_pagination:
        return url
    return source.gabarit_pagination.format(url=url, page=page)


def lire_page(html: str, source: SourceLoyers, url: str) -> list[dict]:
    """Les annonces d'une page de liste, une par vignette."""
    soup = BeautifulSoup(html or "", "lxml")
    lignes = []
    for carte in soup.select(source.carte):
        texte = carte.get_text(" ", strip=True)
        if not texte:
            continue
        loyer, devise = _montant_et_devise(texte, source.devise)
        if loyer is None:
            # Pas de montant ancre a une devise : on ne devine pas. Mieux vaut
            # perdre une annonce que lui prêter un prix qui n'en est pas un.
            continue
        lien = carte.find("a", href=True)
        titre = ""
        for selecteur in ("p.ad__card-description", "h2", "h3",
                          "div.annonce-description", "a"):
            el = carte.select_one(selecteur)
            if el and el.get_text(strip=True):
                titre = el.get_text(" ", strip=True)
                break
        lignes.append({
            "source": source.nom,
            "pays": source.pays,
            "titre": titre[:220] or texte[:220],
            "loyer": loyer,
            # La devise lue dans l'annonce, non celle supposee du pays : les
            # loyers du parc formel ougandais sont annonces en dollars.
            "devise": devise,
            # Le texte affiché garde la périodicité et la mention location/vente.
            "prix_texte": texte[:260],
            "nature": _nature(texte, source.rubrique_de_location),
            "url": (lien["href"] if lien else url)[:400],
            "page_source": url,
        })
    return lignes


def collecter_loyers(pays: str, pages_max: Optional[int] = None,
                     incidents: Optional[list] = None,
                     fetcher=None) -> pd.DataFrame:
    """Les annonces de location d'un pays, toutes sources confondues.

    Comme les autres lecteurs du projet, celui-ci passe par le Fetcher partagé
    qu'`officiel.preparer()` a fixé — robots.txt, délai, cache et réparation de
    chaîne TLS compris. `fetcher` n'est là que pour l'essai direct.

    Un pays sans source ne lève pas d'erreur : il journalise son motif. Une
    absence expliquée vaut mieux qu'une exception.
    """
    from .officiel import _FETCHER

    incidents = incidents if incidents is not None else []
    fetcher = fetcher or _FETCHER[0]
    if fetcher is None:
        raise RuntimeError(
            "aucun Fetcher : appelez `officiel.preparer(fetcher)` d'abord.")
    sources = [s for s in SOURCES if s.pays == pays.upper()]
    if not sources:
        motif = SANS_SOURCE.get(pays.upper(),
                                "aucune source de loyers instruite")
        incidents.append("{} — loyers : {}".format(pays.upper(), motif))
        return pd.DataFrame()

    jour = str(date.today())
    tout = []
    for source in sources:
        limite = pages_max or source.pages_max
        for url in source.urls:
            for page in range(1, limite + 1):
                adresse = _adresse(source, url, page)
                if not fetcher.allowed(adresse):
                    incidents.append(
                        "{} — {} : robots.txt refuse {}".format(
                            pays.upper(), source.nom, adresse))
                    break
                # Le contrôle robots.txt vient d'avoir lieu, y compris pour le
                # rendu par navigateur : faire exécuter la page ne dispense
                # d'aucune autorisation.
                if source.moteur == "navigateur":
                    from .fetch import render_with_playwright
                    try:
                        html = render_with_playwright(
                            adresse, getattr(fetcher, "user_agent", "") or
                            "jumia-cpi")
                    except Exception as erreur:
                        incidents.append(
                            "{} — {} : rendu impossible ({}) sur {}".format(
                                pays.upper(), source.nom,
                                type(erreur).__name__, adresse))
                        break
                    if not html:
                        incidents.append(
                            "{} — {} : Playwright absent — "
                            "pip install playwright && playwright install "
                            "chromium".format(pays.upper(), source.nom))
                        break
                else:
                    try:
                        reponse = fetcher.get(adresse)
                    except Exception as erreur:
                        incidents.append("{} — {} : {} sur {}".format(
                            pays.upper(), source.nom, type(erreur).__name__,
                            adresse))
                        break
                    if not reponse.ok:
                        incidents.append("{} — {} : HTTP {} sur {}".format(
                            pays.upper(), source.nom, reponse.status, adresse))
                        break
                    html = reponse.text
                lignes = lire_page(html, source, adresse)
                if not lignes:
                    # Page vide : soit la fin de la pagination, soit un
                    # changement de balisage. On le dit et on s'arrête là.
                    incidents.append(
                        "{} — {} : aucune annonce lue sur {} "
                        "(fin de pagination ou balisage modifié)".format(
                            pays.upper(), source.nom, adresse))
                    break
                tout.extend(lignes)
                if not source.gabarit_pagination:
                    break

    if not tout:
        return pd.DataFrame()
    d = pd.DataFrame(tout)
    d["date_collecte"] = jour
    d["collecte_utc"] = now_utc()
    # Une même annonce peut figurer dans deux rayons (appartements et villas).
    d = d.drop_duplicates(subset=["source", "url", "loyer"]).reset_index(drop=True)
    log.info("Loyers %s : %d annonces (%s)", pays.upper(), len(d),
             d["nature"].value_counts().to_dict())
    return d


def sources_du_pays(pays: str) -> list:
    return [s for s in SOURCES if s.pays == pays.upper()]


def pays_couverts() -> list:
    return sorted({s.pays for s in SOURCES})
