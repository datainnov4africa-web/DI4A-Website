"""Paramètres, registre des sites Jumia et nomenclature COICOP 2018.

Tout ce qui peut changer (domaines, devises, seuils, sélecteurs) est centralisé ici pour
que le reste du code reste générique.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional


def _ascii(texte: str) -> str:
    """Rend un texte transportable dans un en-tete HTTP.

    Les accents sont remplaces par leur lettre de base (`e` pour `e`), le reste
    du non-ASCII est retire. On ne leve pas : un contact mal saisi ne doit pas
    empecher la collecte, il doit seulement arriver lisible.
    """
    import unicodedata

    if not texte:
        return ""
    decompose = unicodedata.normalize("NFKD", str(texte))
    return "".join(c for c in decompose if ord(c) < 128)


VERSION = "1.0.0"
PROJECT_NAME = "jumia-cpi"
# Gabarit volontaire : tant que « <utilisateur> » y figure, les carnets de
# collecte l'affichent et demandent de le remplacer. Cette adresse part dans
# le User-Agent envoyé à chaque site : elle doit désigner VOTRE projet.
PROJECT_URL = "https://github.com/<utilisateur>/jumia-cpi"

# --------------------------------------------------------------------------------------
# Registre des sites Jumia
# --------------------------------------------------------------------------------------


@dataclass(frozen=True)
class Site:
    iso2: str
    iso3: str
    country_fr: str
    country_en: str
    domain: str
    currency: str
    currency_symbol: str
    languages: tuple
    status_hint: str  # "active" | "exited" | "historical" | "synthetic" | "discovered"
    note: str = ""

    @property
    def url(self) -> str:
        return f"https://www.{self.domain}/"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["languages"] = ", ".join(self.languages)
        d["url"] = self.url
        return d


# Statuts d'après le site corporate (group.jumia.com/about/locations) et les communiqués de
# Jumia (consultés en octobre 2026). Le notebook revérifie chaque domaine à l'exécution :
# ces indications ne sont qu'un point de départ.
CANDIDATE_SITES: tuple[Site, ...] = (
    Site("NG", "NGA", "Nigéria", "Nigeria", "jumia.com.ng", "NGN", "₦", ("en",), "active"),
    Site("EG", "EGY", "Égypte", "Egypt", "jumia.com.eg", "EGP", "EGP", ("en", "ar"), "active"),
    Site("MA", "MAR", "Maroc", "Morocco", "jumia.ma", "MAD", "Dhs", ("fr", "ar"), "active"),
    Site("KE", "KEN", "Kenya", "Kenya", "jumia.co.ke", "KES", "KSh", ("en",), "active"),
    Site("GH", "GHA", "Ghana", "Ghana", "jumia.com.gh", "GHS", "GH₵", ("en",), "active"),
    Site("CI", "CIV", "Côte d'Ivoire", "Côte d'Ivoire", "jumia.ci", "XOF", "FCFA", ("fr",), "active"),
    Site("SN", "SEN", "Sénégal", "Senegal", "jumia.sn", "XOF", "FCFA", ("fr",), "active"),
    Site("UG", "UGA", "Ouganda", "Uganda", "jumia.ug", "UGX", "UGX", ("en",), "active"),
    Site("DZ", "DZA", "Algérie", "Algeria", "jumia.dz", "DZD", "DA", ("fr", "ar"), "exited",
         "Activité arrêtée en février 2026"),
    Site("TN", "TUN", "Tunisie", "Tunisia", "jumia.com.tn", "TND", "TND", ("fr",), "exited",
         "Activité arrêtée fin 2024"),
    Site("ZA", "ZAF", "Afrique du Sud", "South Africa", "jumia.co.za", "ZAR", "R", ("en",), "exited",
         "Retrait annoncé en 2024"),
    Site("CM", "CMR", "Cameroun", "Cameroon", "jumia.cm", "XAF", "FCFA", ("fr", "en"), "historical",
         "Activité suspendue en 2019"),
    Site("TZ", "TZA", "Tanzanie", "Tanzania", "jumia.co.tz", "TZS", "TSh", ("en",), "historical",
         "Activité suspendue en 2019"),
    Site("RW", "RWA", "Rwanda", "Rwanda", "jumia.rw", "RWF", "RWF", ("en", "fr"), "historical",
         "Activité suspendue en 2019"),
)

# Pays fictif du jeu de test (code ISO réservé à l'usage privé). Toute sortie qui en est
# issue porte l'indicateur synthetic=True.
TEST_SITE = Site("XT", "XTS", "Pays test (synthétique)", "Test country (synthetic)", "jumia.xt",
                 "XTF", "XTF", ("fr",), "synthetic", "Site simulé hors ligne")

CORPORATE_URLS = (
    "https://group.jumia.com/about/locations",
    "https://www.jumia.com/",
)

DOMAIN_PATTERN = re.compile(r"(?:https?://)?(?:www\.)?(jumia\.(?:com\.[a-z]{2}|co\.[a-z]{2}|[a-z]{2}))\b", re.I)


def site_by_iso2(iso2: str, extra: tuple[Site, ...] = ()) -> Site:
    iso2 = iso2.upper().strip()
    for s in CANDIDATE_SITES + (TEST_SITE,) + tuple(extra):
        if s.iso2 == iso2 or s.iso3 == iso2:
            return s
    raise KeyError(f"Pays inconnu : {iso2!r}. Codes possibles : "
                   + ", ".join(s.iso2 for s in CANDIDATE_SITES))


# --------------------------------------------------------------------------------------
# Paramètres d'exécution
# --------------------------------------------------------------------------------------


@dataclass
class Settings:
    mode: str = "live"                 # "test" (hors ligne, site simulé) | "live"
    country: str = "CI"
    categories: object = "auto"         # "auto" | liste de slugs ("/epicerie/", ...)
    max_pages: int = 5
    max_categories: int = 25
    request_delay: float = 2.0          # secondes entre deux requêtes vers le même hôte
    jitter: float = 0.5
    timeout: float = 25.0
    max_retries: int = 4
    details_sample: int = 0             # nb de fiches produit à ouvrir (vendeur, stock)
    use_playwright: bool = False
    llm_provider: str = "groq"          # "ollama" | "groq" | "gemini" | "none"
    model_name: str = ""                # vide = choix automatique (fournisseur préféré)
    llm_models: Optional[dict] = None   # modèle par fournisseur : {"groq": "...", "gemini": "...", "ollama": "..."}
    prompt_lang: str = "fr"             # langue du prompt envoyé au modèle : "fr" | "en"
    llm_batch_size: int = 25
    llm_max_items: int = 600            # plafond de produits envoyés au LLM par exécution
    reference_period: str = ""          # "AAAA-MM" ; vide = première période observée
    contact_email: str = ""            # obligatoire en mode live, vérifié par pipeline.check_live_requirements
    ollama_host: str = "http://localhost:11434"
    weights_csv: str = ""
    official_cpi_csv: str = ""
    root: str = "."
    test_months: int = 13

    # --- seuils méthodologiques ---
    min_matched: int = 3                # produits appariés minimum par agrégat élémentaire
    relative_bounds: tuple = (1 / 3, 3.0)  # relatifs de prix hors bornes = aberrants
    max_gap: int = 2                    # mois d'absence imputables

    def __post_init__(self):
        self.mode = self.mode.lower().strip()
        if self.mode not in {"test", "live"}:
            raise ValueError("MODE doit valoir 'test' ou 'live'.")
        self.country = (TEST_SITE.iso2 if self.mode == "test" else self.country).upper()
        if self.llm_provider:
            self.llm_provider = self.llm_provider.lower().strip()

    # Chemins ---------------------------------------------------------------------------
    @property
    def site(self) -> Site:
        return site_by_iso2(self.country)

    @property
    def out_dir(self) -> Path:
        p = Path(self.root) / "outputs" / self.site.iso3
        p.mkdir(parents=True, exist_ok=True)
        return p

    def path(self, *parts: str) -> Path:
        p = self.out_dir.joinpath(*parts)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def user_agent(self) -> str:
        """L'identite annoncee au site, en ASCII strict.

        Un en-tete HTTP ne transporte pas d'UTF-8 : il est encode en latin-1 au
        mieux. Le « a » accentue de « a des fins statistiques » partait donc en
        octet brut 0xE0, et le pare-feu applicatif de Cloudflare refusait la
        requete. Mesure le 13/10/2026 sur jumia.ci, meme machine, meme minute :

            ...a des fins statistiques   -> HTTP 403,     5 482 octets
            ...a des fins statistiques   -> HTTP 200, 1 609 506 octets
              (avec accent)                 (sans accent)

        Un seul caractere accentue bloquait toute la collecte, sur les dix
        sites a la fois - et le symptome, « acces refuse ou protection
        anti-robot », envoyait chercher du cote de l'editeur.

        `_ascii` protege aussi le contact et l'URL, que l'exploitant renseigne
        et ou un accent est tout aussi probable.
        """
        contact = _ascii(self.contact_email or "non-renseigne")
        return (f"JumiaCPI-Research/{VERSION} (+{_ascii(PROJECT_URL)}; "
                f"contact: {contact}; collecte de prix a des fins statistiques)")

    @property
    def synthetic(self) -> bool:
        return self.mode == "test"

    def summary(self) -> dict:
        d = {k: v for k, v in asdict(self).items()}
        d["site"] = self.site.url
        d["user_agent"] = self.user_agent
        return d


# --------------------------------------------------------------------------------------
# COICOP 2018 (Nations Unies) : divisions et groupes utilisés
# --------------------------------------------------------------------------------------

COICOP_DIVISIONS = {
    "01": "Produits alimentaires et boissons non alcoolisées",
    "02": "Boissons alcoolisées, tabac et stupéfiants",
    "03": "Articles d'habillement et chaussures",
    "04": "Logement, eau, électricité, gaz et autres combustibles",
    "05": "Ameublement, équipement ménager et entretien courant",
    "06": "Santé",
    "07": "Transports",
    "08": "Information et communication",
    "09": "Loisirs, sports et culture",
    "10": "Enseignement",
    "11": "Restaurants et hébergement",
    "12": "Assurances et services financiers",
    "13": "Soins personnels, protection sociale et divers",
}

COICOP_SHORT = {
    "01": "Alimentation", "02": "Alcool & tabac", "03": "Habillement", "04": "Logement & énergie",
    "05": "Équipement ménager", "06": "Santé", "07": "Transports", "08": "Information & comm.",
    "09": "Loisirs & culture", "10": "Enseignement", "11": "Restaurants", "12": "Assurances & fin.",
    "13": "Soins personnels & divers",
}

COICOP_CODES = {
    "01.1.1": "Céréales et produits céréaliers",
    "01.1.2": "Viandes",
    "01.1.3": "Poissons et fruits de mer",
    "01.1.4": "Lait, produits laitiers et œufs",
    "01.1.5": "Huiles et graisses",
    "01.1.6": "Fruits et noix",
    "01.1.7": "Légumes, tubercules et légumineuses",
    "01.1.8": "Sucre, confiserie et desserts",
    "01.1.9": "Plats préparés et autres produits alimentaires",
    "01.2.1": "Jus de fruits et de légumes",
    "01.2.2": "Café",
    "01.2.3": "Thé et infusions",
    "01.2.4": "Boissons cacaotées",
    "01.2.5": "Eaux",
    "01.2.6": "Boissons rafraîchissantes",
    "02.1": "Boissons alcoolisées",
    "02.2": "Tabac",
    "03.1": "Vêtements",
    "03.2": "Chaussures",
    "04.5": "Électricité, gaz et autres combustibles",
    "05.1": "Meubles et articles d'ameublement",
    "05.2": "Articles de ménage en textiles",
    "05.3": "Appareils ménagers",
    "05.4": "Verrerie, vaisselle et ustensiles de ménage",
    "05.5": "Outillage pour la maison et le jardin",
    "05.6": "Biens et services d'entretien courant",
    "06.1": "Médicaments et produits de santé",
    "07.2": "Utilisation des véhicules personnels (pièces, lubrifiants)",
    "08.1": "Équipement d'information et de communication",
    "09.1": "Biens durables de loisirs",
    "09.2": "Autres articles de loisirs et de sport",
    "09.3": "Jardinage, plantes et animaux de compagnie",
    "09.7": "Journaux, livres et papeterie",
    "13.1": "Soins personnels",
    "13.2": "Effets personnels (bijoux, montres, bagagerie)",
}


# Les mêmes libellés en anglais : le carnet anglais envoie au modèle un prompt
# anglais, et les prototypes des plongements parlent les deux langues.
COICOP_DIVISIONS_EN = {
    "01": "Food and non-alcoholic beverages",
    "02": "Alcoholic beverages, tobacco and narcotics",
    "03": "Clothing and footwear",
    "04": "Housing, water, electricity, gas and other fuels",
    "05": "Furnishings, household equipment and routine household maintenance",
    "06": "Health",
    "07": "Transport",
    "08": "Information and communication",
    "09": "Recreation, sport and culture",
    "10": "Education services",
    "11": "Restaurants and accommodation services",
    "12": "Insurance and financial services",
    "13": "Personal care, social protection and miscellaneous goods and services",
}

COICOP_CODES_EN = {
    "01.1.1": "Cereals and cereal products",
    "01.1.2": "Meat",
    "01.1.3": "Fish and seafood",
    "01.1.4": "Milk, other dairy products and eggs",
    "01.1.5": "Oils and fats",
    "01.1.6": "Fruits and nuts",
    "01.1.7": "Vegetables, tubers and pulses",
    "01.1.8": "Sugar, confectionery and desserts",
    "01.1.9": "Ready-made food and other food products",
    "01.2.1": "Fruit and vegetable juices",
    "01.2.2": "Coffee",
    "01.2.3": "Tea and infusions",
    "01.2.4": "Cocoa drinks",
    "01.2.5": "Water",
    "01.2.6": "Soft drinks",
    "02.1": "Alcoholic beverages",
    "02.2": "Tobacco",
    "03.1": "Clothing",
    "03.2": "Footwear",
    "04.5": "Electricity, gas and other fuels",
    "05.1": "Furniture and furnishings",
    "05.2": "Household textiles",
    "05.3": "Household appliances",
    "05.4": "Glassware, tableware and household utensils",
    "05.5": "Tools and equipment for house and garden",
    "05.6": "Goods and services for routine household maintenance",
    "06.1": "Medicines and health products",
    "07.2": "Operation of personal transport equipment (parts, lubricants)",
    "08.1": "Information and communication equipment",
    "09.1": "Recreational durables",
    "09.2": "Other recreational goods and sports equipment",
    "09.3": "Gardens, plants and pets",
    "09.7": "Newspapers, books and stationery",
    "13.1": "Personal care",
    "13.2": "Personal effects (jewellery, watches, luggage)",
}


def division_of(code: Optional[str]) -> Optional[str]:
    if not code or not isinstance(code, str):
        return None
    m = re.match(r"^(\d{2})", code)
    return m.group(1) if m else None


def coicop_label(code: str) -> str:
    if code in COICOP_CODES:
        return f"{code} {COICOP_CODES[code]}"
    d = division_of(code)
    return f"{code} {COICOP_DIVISIONS.get(d, '?')}"


# --------------------------------------------------------------------------------------
# Pondérations par défaut
# --------------------------------------------------------------------------------------
# Sans fichier de pondérations national, chaque division couverte reçoit le même poids.
# C'est un choix neutre mais irréaliste (l'alimentation pèse souvent 25 à 45 % des IPC
# africains) : le notebook l'indique et abaisse le niveau de confiance. Remplissez
# data/templates/weights_template.csv avec les pondérations publiées par l'institut national.
DEFAULT_WEIGHTS_NOTE = ("Pondérations égales entre divisions couvertes (aucun fichier national "
                        "fourni) : résultat illustratif, à remplacer par les pondérations officielles.")

# Pondérations du jeu de test (synthétiques, inventées pour la démonstration)
TEST_WEIGHTS = {"01": 0.36, "02": 0.02, "03": 0.08, "04": 0.14, "05": 0.06, "06": 0.05, "07": 0.09, "08": 0.05,
                "09": 0.03, "10": 0.03, "11": 0.04, "12": 0.01, "13": 0.04}

# --------------------------------------------------------------------------------------
# Fournisseurs LLM
# --------------------------------------------------------------------------------------
# Modèles par défaut : s'ils ne figurent plus dans la liste du fournisseur, le client choisit
# automatiquement le premier modèle disponible dans l'ordre de préférence.
LLM_DEFAULT_MODELS = {
    # Le 26/10/2026, le catalogue Groq ne proposait plus les llama-3.x ; les
    # gpt-oss sont en tête, les llama restent au cas où ils reviendraient.
    "groq": ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "llama-3.3-70b-versatile",
             "llama-3.1-8b-instant"],
    # Le 27/10/2026, Gemini refusait les 2.5 aux nouveaux comptes (« no longer
    # available to new users ») et renvoyait vers les 3.5.
    "gemini": ["gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash", "gemini-2.5-flash-lite",
               "gemini-2.0-flash", "gemini-flash-latest"],
    "ollama": ["qwen2.5:7b", "llama3.1:8b", "mistral:7b", "gemma2:9b"],
}

# Prix en USD par million de jetons (entrée, sortie). Laissés à None : renseignez-les depuis
# les pages tarifaires des fournisseurs si vous voulez un suivi des coûts en dollars.
# Ollama tourne en local : coût nul.
LLM_PRICING: dict[str, Optional[tuple[float, float]]] = {
    "groq": None,
    "gemini": None,
    "ollama": (0.0, 0.0),
    "rules": (0.0, 0.0),
}

SECRET_NAMES = {"groq": "GROQ_API_KEY", "gemini": "GEMINI_API_KEY"}
