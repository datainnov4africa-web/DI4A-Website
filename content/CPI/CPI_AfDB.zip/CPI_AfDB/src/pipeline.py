"""Assemblage des étapes, partagé par le notebook et le script de collecte planifiée."""
from __future__ import annotations

import logging
from datetime import date
from pathlib import Path
from typing import Optional

import pandas as pd

from . import classification, config, fixture, llm, scraper, storage
from .fetch import Fetcher
from .utils import get_secret

log = logging.getLogger("jumia_cpi.pipeline")


def make_fetcher(s: config.Settings, transport=None) -> Fetcher:
    test = s.mode == "test"
    return Fetcher(
        s.user_agent, delay=0 if test else s.request_delay, jitter=0 if test else s.jitter, timeout=s.timeout,
        max_retries=s.max_retries, transport=transport, cache_dir=s.out_dir / "cache" / "http",
        sleep=(lambda _x: None) if test else __import__("time").sleep)


def check_live_requirements(s: config.Settings) -> list[str]:
    """Conditions à remplir avant toute collecte réelle."""
    problems = []
    if s.mode == "live":
        if "@" not in (s.contact_email or ""):
            problems.append("CONTACT_EMAIL est vide : la politique robots.txt de Jumia exige que le robot "
                            "identifie son propriétaire et un moyen de le contacter.")
        if s.request_delay < 1.0:
            problems.append("REQUEST_DELAY doit être d'au moins 1 seconde (charge serveur minimale).")
    return problems


def test_world(s: config.Settings) -> tuple[fixture.SyntheticJumia, fixture.FixtureTransport]:
    site = fixture.SyntheticJumia(months=s.test_months)
    return site, fixture.FixtureTransport(site)


def collect_snapshot(s: config.Settings, fetcher: Fetcher, categories: pd.DataFrame, collect_date: str,
                     progress: bool = True, collected_at: Optional[str] = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    site = s.site
    df, pages = scraper.collect(fetcher, site, categories, collect_date, s.max_pages, s.out_dir / "checkpoints",
                                details_sample=s.details_sample, use_playwright=s.use_playwright,
                                progress=progress, collected_at=collected_at)
    if len(df):
        storage.save_snapshot(df, s.out_dir, site.iso2, collect_date)
    return df, pages


def backfill_test_panel(s: config.Settings, fetcher: Fetcher, world: fixture.SyntheticJumia,
                        categories: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Mode test : simule un relevé mensuel sur `test_months` mois (le panel qu'un an de
    collectes réelles aurait constitué). Retourne le dernier relevé et son journal."""
    last, pages = pd.DataFrame(), pd.DataFrame()
    dates = world.collection_dates()
    from tqdm.auto import tqdm

    for d in tqdm(dates, desc="Relevés mensuels simulés"):
        world.set_date(d)
        last, pages = collect_snapshot(s, fetcher, categories, str(d), progress=False, collected_at=f"{d}T09:00:00Z")
    return last, pages


def load_weights(s: config.Settings) -> tuple[dict, str]:
    """Pondérations par division : fichier national > jeu de test > poids égaux."""
    if s.weights_csv and Path(s.weights_csv).exists():
        w = pd.read_csv(s.weights_csv, dtype={"division": str})
        w["division"] = w["division"].str.zfill(2)
        return dict(zip(w["division"], w["weight"].astype(float))), "national"
    if s.mode == "test":
        return dict(config.TEST_WEIGHTS), "synthétiques (test)"
    return {k: 1.0 for k in config.COICOP_DIVISIONS}, "égales (par défaut)"


def make_llm_client(s: config.Settings) -> llm.LLMClient:
    keys = {"groq": get_secret("GROQ_API_KEY"), "gemini": get_secret("GEMINI_API_KEY")}
    preferred = s.llm_provider if s.llm_provider in ("ollama", "groq", "gemini") else "none"
    return llm.LLMClient(preferred, s.model_name, keys=keys, ollama_host=s.ollama_host,
                         cache_path=s.path("llm_cache.sqlite"), rules_handler=classification.rules_handler,
                         fallback=True, models=s.llm_models)


def enrich_panel(panel: pd.DataFrame, client, s: config.Settings, progress: bool = True) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Classe chaque produit une seule fois (dernière description connue) et propage aux relevés."""
    products = panel.sort_values("collect_date").drop_duplicates("sku", keep="last").reset_index(drop=True)
    enr = classification.enrich(products, client, batch_size=s.llm_batch_size, max_items=s.llm_max_items,
                                progress=progress, langue=getattr(s, "prompt_lang", "fr"))
    enr = classification.find_duplicates(enr)
    keep = ["sku", "coicop", "division", "coicop_source", "quantity", "unit", "brand_norm", "cluster_id"]
    obs = panel.merge(enr[keep], on="sku", how="left")
    obs["unit_price"] = obs["price"] / obs["quantity"].where(obs["quantity"] > 0)
    return enr, obs
