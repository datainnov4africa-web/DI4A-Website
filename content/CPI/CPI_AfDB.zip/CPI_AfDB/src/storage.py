"""Stockage incrémental des relevés en Parquet, partitionné par pays et par date, interrogé
avec DuckDB. Chaque collecte écrit (ou remplace) `raw/country=XX/collect_date=AAAA-MM-JJ/`,
ce qui rend l'opération idempotente : relancer la collecte du jour ne crée pas de doublon.
"""
from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

log = logging.getLogger("jumia_cpi.storage")

KEEP = ["sku", "name", "brand", "jumia_category", "price", "old_price", "discount_pct", "is_buyable", "rating",
        "n_ratings", "url", "parse_method", "collect_date", "collected_at", "category_slug", "category_name",
        "category_depth", "division_hint", "page", "currency", "country", "seller", "availability"]


def snapshot_path(root: Path, country: str, collect_date: str) -> Path:
    return Path(root) / "raw" / f"country={country}" / f"collect_date={collect_date}" / "part-0.parquet"


def save_snapshot(df: pd.DataFrame, root: Path, country: str, collect_date: str) -> Path:
    p = snapshot_path(root, country, collect_date)
    p.parent.mkdir(parents=True, exist_ok=True)
    out = df[[c for c in KEEP if c in df.columns]].drop(columns=["country", "collect_date"], errors="ignore").copy()
    for c in ("seller", "availability", "brand", "jumia_category", "division_hint", "image"):
        if c in out:
            out[c] = out[c].astype("string")
    for c in ("is_buyable",):
        if c in out:
            out[c] = out[c].astype("boolean")
    for c in ("rating", "n_ratings", "discount_pct", "old_price", "price"):
        if c in out:
            out[c] = pd.to_numeric(out[c], errors="coerce")
    out.to_parquet(p, index=False)
    return p


def load_panel(root: Path, country: str) -> pd.DataFrame:
    """Tous les relevés d'un pays, via DuckDB (lecture des partitions Hive)."""
    import duckdb

    base = Path(root) / "raw" / f"country={country}"
    if not base.exists() or not any(base.rglob("*.parquet")):
        return pd.DataFrame()
    pattern = str(Path(root) / "raw" / "*" / "*" / "*.parquet")
    con = duckdb.connect()
    df = con.execute(f"""
        SELECT * FROM read_parquet('{pattern}', hive_partitioning = true, union_by_name = true)
        WHERE country = ?
        QUALIFY row_number() OVER (PARTITION BY sku, collect_date ORDER BY collected_at DESC) = 1
    """, [country]).df()
    con.close()
    df["collect_date"] = pd.to_datetime(df["collect_date"]).dt.date.astype(str)
    return df


def panel_overview(root: Path) -> pd.DataFrame:
    """Résumé SQL : nombre de relevés, produits et prix médian par pays et par date."""
    import duckdb

    pattern = str(Path(root) / "raw" / "*" / "*" / "*.parquet")
    if not list((Path(root) / "raw").rglob("*.parquet")):
        return pd.DataFrame()
    con = duckdb.connect()
    df = con.execute(f"""
        SELECT country AS pays, CAST(collect_date AS VARCHAR) AS date_relevé, count(*) AS observations,
               count(DISTINCT sku) AS produits, count(DISTINCT category_slug) AS catégories,
               round(avg(CASE WHEN old_price > price THEN 1 ELSE 0 END) * 100, 1) AS pct_promo,
               round(median(price)) AS prix_médian
        FROM read_parquet('{pattern}', hive_partitioning = true, union_by_name = true)
        GROUP BY 1, 2 ORDER BY 1, 2
    """).df()
    con.close()
    return df
