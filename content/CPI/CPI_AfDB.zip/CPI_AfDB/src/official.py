"""Étape 6 : comparaison avec l'IPC officiel et analyse des biais.

Sources de l'IPC officiel, par ordre de préférence :
  1. un fichier CSV mensuel de l'institut national de statistique (`period`, `cpi`) ;
  2. l'API de la Banque mondiale (WDI) : inflation annuelle `FP.CPI.TOTL.ZG`, qui sert au moins
     de repère d'ordre de grandeur ;
  3. en mode test, un IPC synthétique produit par `fixture`.
"""
from __future__ import annotations

import logging
from typing import Optional

import numpy as np
import pandas as pd

from .config import COICOP_DIVISIONS

log = logging.getLogger("jumia_cpi.official")

WB_URL = "https://api.worldbank.org/v2/country/{iso3}/indicator/{ind}?format=json&per_page=100"
WB_INDICATORS = {
    "FP.CPI.TOTL.ZG": "Inflation, prix à la consommation (% annuel)",
    "IT.NET.USER.ZS": "Utilisateurs d'Internet (% de la population)",
    "SP.URB.TOTL.IN.ZS": "Population urbaine (% du total)",
}


def worldbank(iso3: str, indicator: str, http=None, timeout: float = 20) -> pd.DataFrame:
    """Série annuelle WDI. Renvoie un tableau vide en cas d'échec (réseau, pays inconnu)."""
    if http is None:
        import requests as http
    try:
        r = http.get(WB_URL.format(iso3=iso3, ind=indicator), timeout=timeout)
        r.raise_for_status()
        js = r.json()
        rows = js[1] if isinstance(js, list) and len(js) > 1 and js[1] else []
    except Exception as e:
        log.warning("Banque mondiale %s/%s indisponible : %s", iso3, indicator, e)
        return pd.DataFrame(columns=["année", "valeur"])
    df = pd.DataFrame([{"année": int(x["date"]), "valeur": x["value"]} for x in rows if x.get("value") is not None])
    return df.sort_values("année").reset_index(drop=True) if not df.empty else df


def context_indicators(iso3: str, http=None) -> pd.DataFrame:
    """Dernière valeur disponible de chaque indicateur de contexte."""
    rows = []
    for ind, label in WB_INDICATORS.items():
        df = worldbank(iso3, ind, http)
        if not df.empty:
            last = df.iloc[-1]
            rows.append({"indicateur": label, "code": ind, "année": int(last["année"]),
                         "valeur": round(float(last["valeur"]), 1)})
    return pd.DataFrame(rows)


def load_official_csv(path: str) -> pd.DataFrame:
    """CSV mensuel : colonnes `period` (AAAA-MM) et `cpi` (indice, base quelconque)."""
    df = pd.read_csv(path)
    cols = {c.lower().strip(): c for c in df.columns}
    p = cols.get("period") or cols.get("date") or cols.get("mois")
    v = cols.get("cpi") or cols.get("ipc") or cols.get("index") or cols.get("indice")
    if not p or not v:
        raise ValueError("Le fichier doit contenir les colonnes 'period' et 'cpi'.")
    out = pd.DataFrame({"period": pd.to_datetime(df[p]).dt.to_period("M").astype(str), "cpi": df[v].astype(float)})
    return out.sort_values("period").reset_index(drop=True)


def compare(jumia: pd.DataFrame, official: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Aligne l'indice Jumia (« Ensemble ») et l'IPC officiel, puis calcule les écarts.

    `jumia` : colonnes period, index ; `official` : colonnes period, cpi."""
    j = jumia[["period", "index"]].rename(columns={"index": "jumia"})
    o = official[["period", "cpi"]].rename(columns={"cpi": "officiel"}).copy()
    o["officiel_annuel_%"] = o["officiel"].pct_change(12, fill_method=None) * 100
    m = j.merge(o, on="period", how="inner").sort_values("period").reset_index(drop=True)
    if len(m) < 3:
        return m, {"n": len(m), "message": "Moins de trois mois communs : comparaison impossible pour l'instant."}
    m["officiel_rebasé"] = m["officiel"] / m["officiel"].iloc[0] * 100
    m["jumia_rebasé"] = m["jumia"] / m["jumia"].iloc[0] * 100
    m["jumia_mensuelle_%"] = m["jumia"].pct_change() * 100
    m["officiel_mensuelle_%"] = m["officiel"].pct_change() * 100
    m["écart_cumulé_pp"] = m["jumia_rebasé"] - m["officiel_rebasé"]
    a, b = m["jumia_mensuelle_%"].dropna(), m["officiel_mensuelle_%"].dropna()
    lags = {}
    for k in range(-3, 4):
        s = m["jumia_mensuelle_%"].shift(k)
        ok = s.notna() & m["officiel_mensuelle_%"].notna()
        if ok.sum() >= 4:
            lags[k] = round(float(np.corrcoef(s[ok], m.loc[ok, "officiel_mensuelle_%"])[0, 1]), 3)
    best = max(lags, key=lambda k: lags[k]) if lags else None
    stats = {
        "n": len(m),
        "corr_niveaux": round(float(np.corrcoef(m["jumia"], m["officiel"])[0, 1]), 3),
        "corr_mensuelle": round(float(np.corrcoef(a, b)[0, 1]), 3) if len(a) >= 3 else None,
        "même_signe_%": round(float((np.sign(a) == np.sign(b)).mean() * 100), 1) if len(a) else None,
        "écart_absolu_moyen_pp": round(float((a - b).abs().mean()), 2) if len(a) else None,
        "variation_jumia_%": round(float(m["jumia_rebasé"].iloc[-1] - 100), 2),
        "variation_officielle_%": round(float(m["officiel_rebasé"].iloc[-1] - 100), 2),
        "corrélations_décalées": lags,
        "meilleur_décalage": best,
    }
    return m, stats


def coverage_bias(obs: pd.DataFrame, national_weights: dict, promo_gap_pp: Optional[float]) -> pd.DataFrame:
    """Tableau des biais : couverture du panier, poids de l'alimentaire, effet des promotions."""
    covered = sorted(obs["division"].dropna().unique())
    w = {k: v for k, v in national_weights.items() if v}
    total = sum(w.values()) or 1
    cov = sum(v for k, v in w.items() if k in covered) / total * 100 if w else np.nan
    sample_food = (obs["division"] == "01").mean() * 100
    nat_food = w.get("01", np.nan) / total * 100 if w else np.nan
    missing = [f"{k} {COICOP_DIVISIONS[k]}" for k in w if k not in covered]
    rows = [
        {"biais": "Couverture du panier national", "mesure": f"{cov:.0f} % des pondérations" if w else "n.d.",
         "lecture": "Part des dépenses de l'IPC représentée par les divisions observées en ligne."},
        {"biais": "Divisions absentes", "mesure": f"{len(missing)}",
         "lecture": "; ".join(missing[:6]) or "aucune"},
        {"biais": "Poids de l'alimentaire", "mesure": f"échantillon {sample_food:.0f} % / IPC {nat_food:.0f} %",
         "lecture": "Un échantillon riche en non-alimentaire suit plus les prix importés et le change."},
        {"biais": "Effet des promotions", "mesure": "n.d." if promo_gap_pp is None else f"{promo_gap_pp:+.2f} pp",
         "lecture": "Écart final entre l'indice aux prix affichés et l'indice aux prix hors promotion."},
        {"biais": "Population couverte", "mesure": "urbaine et connectée",
         "lecture": "Les acheteurs en ligne sont surtout urbains, connectés et plus aisés que la moyenne."},
    ]
    return pd.DataFrame(rows)
