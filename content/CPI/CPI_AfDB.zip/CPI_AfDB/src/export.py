"""Étape 7 : exports CSV/Parquet, manifeste et rapport HTML autonome (un seul fichier)."""
from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Iterable, Optional

import pandas as pd

from .config import VERSION
from .utils import now_utc


def export_tables(tables: dict[str, pd.DataFrame], out_dir: Path, formats=("csv", "parquet")) -> pd.DataFrame:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for name, df in tables.items():
        if df is None or not isinstance(df, pd.DataFrame) or df.empty:
            continue
        for fmt in formats:
            p = out_dir / f"{name}.{fmt}"
            if fmt == "csv":
                df.to_csv(p, index=False, encoding="utf-8-sig")
            else:
                d = df.copy()
                for c in d.columns:
                    if d[c].dtype == object:
                        d[c] = d[c].astype("string")
                d.to_parquet(p, index=False)
            rows.append({"table": name, "format": fmt, "lignes": len(df), "fichier": str(p),
                         "taille_ko": round(p.stat().st_size / 1024, 1)})
    return pd.DataFrame(rows)


def write_manifest(path: Path, settings: dict, extra: Optional[dict] = None) -> Path:
    m = {"projet": "jumia-cpi", "version": VERSION, "généré_le": now_utc(), "paramètres": settings}
    if extra:
        m.update(extra)
    Path(path).write_text(json.dumps(m, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return Path(path)


CSS = """
:root{--ink:#0b0b0b;--ink2:#52514e;--muted:#8a8986;--grid:#e9e8e4;--bg:#f6f6f3;--card:#fff;--accent:#2a78d6}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--ink:#f0efec;--ink2:#c3c2b7;--muted:#9a998f;
--grid:#383835;--bg:#121211;--card:#1a1a19}}
:root[data-theme="dark"]{--ink:#f0efec;--ink2:#c3c2b7;--muted:#9a998f;--grid:#383835;--bg:#121211;--card:#1a1a19}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink2);font:15px/1.55 Inter,'Segoe UI',Roboto,Arial,sans-serif}
main{max-width:1100px;margin:0 auto;padding:16px}h1,h2,h3{color:var(--ink)}h2{margin-top:36px;border-bottom:2px solid var(--grid);padding-bottom:6px}
nav.toc{background:var(--card);border:1px solid var(--grid);border-radius:12px;padding:10px 16px}
nav.toc a{color:var(--accent);text-decoration:none;margin-right:14px;white-space:nowrap}
.card{background:var(--card);border:1px solid var(--grid);border-radius:12px;padding:12px;margin:12px 0;overflow-x:auto}
table.t{border-collapse:collapse;width:100%;font-size:13px}table.t th{background:#2a78d61a;color:var(--ink);text-align:left;padding:6px 8px}
table.t td{border-top:1px solid var(--grid);padding:5px 8px}footer{color:var(--muted);font-size:12px;margin:30px 0}
"""


def _table_html(df: pd.DataFrame, max_rows: int = 40) -> str:
    return df.head(max_rows).to_html(index=False, classes="t", border=0, na_rep="—", float_format=lambda x: f"{x:,.2f}")


def build_report(path: Path, title: str, subtitle: str, sections: Iterable[tuple[str, list]],
                 header_html: str = "", footer_note: str = "") -> Path:
    """sections : [(titre, [éléments])] où un élément est une figure Plotly, un DataFrame ou du HTML."""
    import plotly.io as pio
    from plotly.offline import get_plotlyjs

    # Fond de carte de l'Afrique embarqué (Natural Earth via plotly.js) : la carte s'affiche hors ligne.
    geo_js = ""
    topo = Path(__file__).parent / "assets" / "africa_110m.json"
    if topo.exists():
        geo_js = ("<script>window.PlotlyGeoAssets=window.PlotlyGeoAssets||{topojson:{}};"
                  "window.PlotlyGeoAssets.topojson.africa_110m=" + topo.read_text(encoding="utf-8") + ";</script>")
    body, toc = [], []
    for i, (sec_title, items) in enumerate(sections):
        anchor = f"s{i}"
        toc.append(f"<a href='#{anchor}'>{html.escape(sec_title)}</a>")
        parts = [f"<h2 id='{anchor}'>{html.escape(sec_title)}</h2>"]
        for it in items:
            if it is None:
                continue
            if hasattr(it, "to_plotly_json"):
                parts.append("<div class='card'>" + pio.to_html(it, full_html=False, include_plotlyjs=False,
                                                                 config={"displaylogo": False, "responsive": True}) + "</div>")
            elif isinstance(it, pd.DataFrame):
                parts.append("<div class='card'>" + _table_html(it) + "</div>")
            else:
                parts.append(str(it))
        body.append("\n".join(parts))
    doc = f"""<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{html.escape(title)}</title>
<style>{CSS}</style>{geo_js}<script>{get_plotlyjs()}</script></head><body><main>
<h1>{html.escape(title)}</h1><p>{html.escape(subtitle)}</p>{header_html}
<nav class="toc">{''.join(toc)}</nav>
{''.join(body)}
<footer>Généré le {now_utc()} par jumia-cpi {VERSION}. {html.escape(footer_note)}</footer>
</main></body></html>"""
    Path(path).write_text(doc, encoding="utf-8")
    return Path(path)
