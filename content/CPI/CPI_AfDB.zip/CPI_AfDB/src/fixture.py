"""Jeu de test hors ligne : un site « Jumia » synthétique, complet et déterministe.

Le pays fictif XT (ISO3 XTS, monnaie XTF) imite la structure des vrais sites : robots.txt
avec la même politique, menu de catégories, pages de liste paginées (40 produits), cartes
produit avec attributs `data-gtm-*`, état JSON `window.__STORE__` sur une partie des pages,
fiches produit avec JSON-LD, promotions, ruptures de stock, entrées et sorties de catalogue,
une catégorie interdite par robots.txt et une erreur 503 passagère.

Les prix suivent une inflation connue par division COICOP (avec des chocs ciblés). Les tests
vérifient que la chaîne de traitement retrouve cette inflation. Le module simule aussi le
« monde » vu à l'étape de validation (sites actifs, fermés, redirigés, injoignables) et un IPC
officiel synthétique.

Rien de ce qui sort de ce module ne décrit un pays réel.
"""
from __future__ import annotations

import html
import json
import math
import re
from dataclasses import dataclass, field
from datetime import date
from typing import Optional
from urllib.parse import parse_qs, urlsplit

import numpy as np
import pandas as pd

from .config import CANDIDATE_SITES, TEST_SITE
from .fetch import Response

PAGE_SIZE = 40
# Gabarits dont la variante {q} est un numéro de modèle et non une quantité
NO_SCALE = ("Smartphone", "Tablette", "Téléphone", "Chargeur", "Écouteurs", "Console")

# Inflation annuelle simulée par division et chocs ponctuels par classe (mois → hausse)
DIVISION_INFLATION = {"01": 0.09, "03": 0.03, "05": 0.04, "06": 0.05, "07": 0.06, "08": -0.02,
                      "09": 0.01, "13": 0.06}
CLASS_SHOCKS = {"01.1.5": {5: 0.06}, "01.1.1": {8: 0.04}, "01.2.6": {3: 0.05}}

BRANDS = ["Soleil d'Or", "Baobab", "Kora", "Savane", "Atlantis", "Lagune", "Sahel", "Nyota",
          "Akwaba", "Teranga", "Zénith", "Oasis"]
TECH_BRANDS = ["Novatel", "Kivu", "Orbis", "Tekno-X", "Lumio", "Vertex"]
SELLERS = ["Boutique Plateau", "Marché Express", "Global Store XT", "Maison Akwaba",
           "TechCity", "Bonprix Distribution", "Jumia Mall XT"]

# slug, nom affiché, parent, gabarits [(gabarit, coicop vrai, prix de base, variantes)]
CATALOG = [
    ("epicerie", "Supermarché", None, []),
    ("riz-pates-cereales", "Riz, pâtes & céréales", "epicerie", [
        ("Riz parfumé {b} {q} kg", "01.1.1", 900, [1, 5, 25]),
        ("Riz brisé {b} - Sac de {q} kg", "01.1.1", 650, [5, 25]),
        ("Spaghetti {b} {q}g", "01.1.1", 1.1, [500]),
        ("Farine de blé {b} {q} kg", "01.1.1", 750, [1, 2]),
        ("Couscous moyen {b} {q} kg", "01.1.1", 1300, [1]),
        ("Flocons d'avoine {b} {q}g", "01.1.1", 4.2, [500]),
        ("Nouilles instantanées {b} - Pack de {q} x 70g", "01.1.1", 160, [40]),
    ]),
    ("huiles-condiments", "Huiles & condiments", "epicerie", [
        ("Huile végétale raffinée {b} {q} L", "01.1.5", 1500, [1, 5]),
        ("Huile d'arachide {b} {q} L", "01.1.5", 2200, [1]),
        ("Huile d'olive extra vierge {b} {q} ml", "01.1.5", 9.0, [500]),
        ("Concentré de tomate {b} {q}g", "01.1.7", 2.5, [400]),
        ("Bouillon cube {b} - Boîte de {q} cubes", "01.1.9", 25, [60]),
        ("Sel iodé {b} {q} kg", "01.1.9", 300, [1]),
        ("Mayonnaise {b} {q}g", "01.1.9", 4.0, [430]),
    ]),
    ("produits-laitiers", "Produits laitiers", "epicerie", [
        ("Lait en poudre entier {b} {q}g", "01.1.4", 8.5, [400, 900]),
        ("Lait concentré sucré {b} {q}g", "01.1.4", 2.0, [397]),
        ("Lait UHT {b} 1L - Pack de {q}", "01.1.4", 950, [6]),
    ]),
    ("conserves-sucre", "Conserves & sucre", "epicerie", [
        ("Sardines à l'huile {b} {q}g", "01.1.3", 4.0, [125]),
        ("Thon au naturel {b} {q}g", "01.1.3", 7.5, [160]),
        ("Corned beef {b} {q}g", "01.1.2", 6.0, [340]),
        ("Sucre en morceaux {b} {q} kg", "01.1.8", 1000, [1]),
        ("Chocolat noir {b} {q}g", "01.1.8", 12, [100]),
        ("Céréales infantiles {b} {q}g", "01.1.9", 7.0, [400]),
    ]),
    ("boissons", "Boissons", "epicerie", [
        ("Eau minérale {b} 1,5L - Pack de {q}", "01.2.5", 280, [6]),
        ("Boisson gazeuse {b} 33cl - Pack de {q}", "01.2.6", 330, [24]),
        ("Jus d'orange {b} {q} L", "01.2.1", 1300, [1]),
        ("Café soluble {b} {q}g", "01.2.2", 25, [200]),
        ("Thé vert à la menthe {b} - {q} sachets", "01.2.3", 40, [25]),
        ("Poudre cacaotée {b} {q}g", "01.2.4", 7.0, [400]),
    ]),
    ("entretien-maison", "Entretien de la maison", "epicerie", [
        ("Lessive en poudre {b} {q} kg", "05.6", 1400, [1, 3]),
        ("Liquide vaisselle {b} {q} ml", "05.6", 1.6, [750]),
        ("Eau de javel {b} {q} L", "05.6", 600, [1]),
        ("Insecticide aérosol {b} {q} ml", "05.6", 5.0, [400]),
    ]),
    ("beaute-hygiene-sante", "Beauté & Hygiène", None, [
        ("Savon de toilette {b} 200g - Lot de {q}", "13.1", 450, [4]),
        ("Dentifrice protection caries {b} {q} ml", "13.1", 12, [100]),
        ("Shampooing nourrissant {b} {q} ml", "13.1", 7.5, [400]),
        ("Lait de corps hydratant {b} {q} ml", "13.1", 6.0, [500]),
        ("Huile capillaire fortifiante {b} {q} ml", "13.1", 30, [100]),
        ("Déodorant spray {b} {q} ml", "13.1", 14, [150]),
        ("Papier toilette {b} - {q} rouleaux", "13.1", 220, [12]),
        ("Couches bébé {b} Taille 4 - {q} couches", "13.1", 160, [44]),
        ("Masques chirurgicaux {b} - Boîte de {q}", "06.1", 70, [50]),
        ("Vitamine C 1000mg {b} - {q} comprimés", "06.1", 110, [30]),
        ("Thermomètre digital {b}", "06.1", 3500, [1]),
        ("Tensiomètre électronique {b}", "06.1", 18000, [1]),
    ]),
    ("telephone-tablette", "Téléphones & Tablettes", None, [
        ("Smartphone {b} A{q} 6,6\" 128Go 4Go RAM 5000mAh", "08.1", 85000, [5, 7]),
        ("Smartphone {b} Note {q} 6,7\" 256Go 8Go RAM", "08.1", 160000, [12]),
        ("Tablette {b} Tab {q} 10,1\" 64Go", "08.1", 70000, [3]),
        ("Téléphone portable {b} {q} double SIM", "08.1", 9000, [110]),
        ("Chargeur rapide {b} {q}W USB-C", "08.1", 6000, [25]),
        ("Écouteurs Bluetooth {b} TWS-{q}", "08.1", 9500, [2]),
    ]),
    ("electronique", "TV & Électronique", None, [
        ("TV LED {b} {q}\" HD", "08.1", 2600, [32]),
        ("Smart TV {b} {q}\" Full HD", "08.1", 4300, [43]),
        ("Barre de son {b} {q}W", "08.1", 450, [120]),
        ("Console de jeux portable {b} G{q}", "09.1", 30000, [2]),
    ]),
    ("maison-cuisine-jardin", "Maison & Cuisine", None, [
        ("Mixeur blender {b} 1,5L {q}W", "05.3", 40, [350]),
        ("Fer à repasser {b} {q}W", "05.3", 7, [1200]),
        ("Ventilateur sur pied {b} {q}\"", "05.3", 1300, [16]),
        ("Bouilloire électrique {b} 1,7L {q}W", "05.3", 6, [2000]),
        ("Marmite inox {b} {q}L", "05.4", 1500, [10]),
        ("Service de table {b} {q} pièces", "05.4", 900, [24]),
        ("Drap housse {b} 2 places - lot de {q}", "05.2", 4500, [2]),
        ("Matelas mousse {b} 140x190 - épaisseur {q} cm", "05.1", 2800, [20]),
    ]),
    ("fashion-mode", "Mode", None, [
        ("T-shirt homme coton {b} - Lot de {q}", "03.1", 3500, [3]),
        ("Robe pagne femme {b} taille {q}", "03.1", 450, [40]),
        ("Jean slim homme {b} taille {q}", "03.1", 380, [42]),
        ("Baskets homme {b} pointure {q}", "03.2", 400, [42]),
        ("Sandales femme {b} pointure {q}", "03.2", 220, [39]),
        ("Montre homme acier {b} M{q}", "13.2", 4000, [3]),
    ]),
    ("sports-loisirs", "Sports & Loisirs", None, [
        ("Ballon de football {b} taille {q}", "09.2", 1500, [5]),
        ("Tapis de yoga {b} {q} mm", "09.2", 1100, [6]),
        ("Haltères réglables {b} 2 x {q} kg", "09.2", 1800, [5]),
    ]),
    ("auto-moto", "Auto & Moto", None, [
        ("Huile moteur 5W30 {b} {q} L", "07.2", 4000, [4]),
        ("Liquide de refroidissement {b} {q} L", "07.2", 2500, [1]),
    ]),
    ("livres-papeterie", "Livres & Papeterie", None, [
        ("Cahier {b} 200 pages - Lot de {q}", "09.7", 400, [10]),
        ("Stylos à bille {b} - Boîte de {q}", "09.7", 90, [50]),
    ]),
    # Catégorie volontairement interdite par robots.txt (/mlp-*) : le collecteur doit l'ignorer.
    ("mlp-electromenager", "Électroménager", None, [
        ("Réfrigérateur {b} {q}L", "05.3", 1100, [200]),
    ]),
]


def _slugify(s: str) -> str:
    s = s.lower()
    for a, b in (("é", "e"), ("è", "e"), ("ê", "e"), ("à", "a"), ("â", "a"), ("ô", "o"), ("î", "i"),
                 ("ç", "c"), ("û", "u"), ("ù", "u"), ("'", "-"), ('"', "")):
        s = s.replace(a, b)
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-")


def _round_price(p: float) -> float:
    step = 5 if p < 1000 else 25 if p < 20000 else 100
    return float(max(step, round(p / step) * step))


@dataclass
class Product:
    sku: str
    name: str
    brand: str
    category: str
    coicop: str
    seller: str
    rating: float
    n_ratings: int
    regular: np.ndarray            # prix « normal » par période
    shown: np.ndarray              # prix affiché (après promotion)
    old: np.ndarray                # prix barré affiché (NaN si absent)
    present: np.ndarray            # booléen : en ligne à cette période
    buyable: np.ndarray
    url: str = ""


class SyntheticJumia:
    """Site synthétique. `periods` : mois simulés ; le transport choisit la période affichée."""

    def __init__(self, months: int = 13, end: Optional[str] = None, seed: int = 20261013):
        self.rng = np.random.default_rng(seed)
        end_p = pd.Period(end, "M") if end else pd.Timestamp.today().to_period("M")
        self.periods = pd.period_range(end=end_p, periods=months, freq="M")
        self.T = months
        self.products: list[Product] = []
        self.categories = {c[0]: c for c in CATALOG}
        self.level = self._levels()
        self._build()
        self.by_sku = {p.sku: p for p in self.products}
        self.period_idx = self.T - 1
        self._fail_once = {"/telephone-tablette/?page=2"}  # une 503 passagère

    # ---- dynamique des prix --------------------------------------------------------------
    def _levels(self) -> dict:
        """Niveau de prix « vrai » par classe COICOP et par période (base 1 en t=0)."""
        levels = {}
        codes = {g[1] for c in CATALOG for g in c[3]}
        for code in codes:
            div = code[:2]
            m = (1 + DIVISION_INFLATION.get(div, 0.03)) ** (1 / 12) - 1
            lv = [1.0]
            for t in range(1, self.T):
                lv.append(lv[-1] * (1 + m + CLASS_SHOCKS.get(code, {}).get(t, 0.0)))
            levels[code] = np.array(lv)
        return levels

    def _build(self):
        rng = self.rng
        sku = 30000000
        for slug, cname, parent, templates in CATALOG:
            for tpl, code, base, variants in templates:
                brands = TECH_BRANDS if code.startswith(("08", "09.1")) else BRANDS
                for q in variants:
                    for b in rng.choice(brands, size=min(len(brands), int(rng.integers(3, 6))), replace=False):
                        sku += int(rng.integers(7, 977))
                        name = tpl.format(b=b, q=str(q).replace(".", ","))
                        scale = 1 if any(w in tpl for w in NO_SCALE) else q
                        p0 = base * scale * float(np.exp(rng.normal(0, 0.25)))
                        self.products.append(self._path(str(sku), name, str(b), slug, code, p0))
                        if rng.random() < 0.08:  # même article proposé par un autre vendeur
                            sku += int(rng.integers(7, 977))
                            self.products.append(self._path(str(sku), name, str(b), slug, code,
                                                            p0 * float(rng.uniform(0.92, 1.1))))

    def _path(self, sku, name, brand, slug, code, p0) -> Product:
        rng, T = self.rng, self.T
        lv = self.level[code]
        regular = np.empty(T)
        regular[0] = _round_price(p0)
        drift = 1.0
        for t in range(1, T):
            drift *= float(np.exp(rng.normal(0, 0.01)))
            target = p0 * lv[t] * drift
            gap = target / regular[t - 1] - 1
            if rng.random() < 0.35 or abs(gap) > 0.06:
                regular[t] = _round_price(target)
            else:
                regular[t] = regular[t - 1]
        promo = rng.random(T) < 0.2
        depth = rng.uniform(0.10, 0.40, T)
        shown = np.where(promo, [_round_price(x) for x in regular * (1 - depth)], regular)
        permanent_ref = rng.random() < 0.25  # prix barré « de référence » toujours affiché
        old = np.where(promo, regular, np.where(permanent_ref, [_round_price(x) for x in regular * 1.3], np.nan))
        entry = 0 if rng.random() < 0.82 else int(rng.integers(1, T))
        exit_ = T if rng.random() < 0.85 else int(rng.integers(entry + 1, T + 1))
        present = np.array([(entry <= t < exit_) for t in range(T)])
        present &= ~(rng.random(T) < 0.03)  # absences passagères
        if entry < exit_:
            present[entry] = True
        buyable = rng.random(T) > 0.04
        rating = round(float(rng.uniform(3.0, 5.0)), 1)
        n_rat = int(rng.lognormal(2.5, 1.2))
        p = Product(sku, name, brand, slug, code, str(rng.choice(SELLERS)), rating, n_rat,
                    regular, shown, old, present, buyable)
        p.url = f"/{_slugify(name)}-{sku}.html"
        return p

    # ---- état courant --------------------------------------------------------------------
    def set_date(self, d) -> None:
        per = pd.Timestamp(d).to_period("M")
        idx = list(self.periods).index(per) if per in self.periods else self.T - 1
        self.period_idx = idx

    def collection_dates(self) -> list[date]:
        return [p.to_timestamp(how="start").date().replace(day=15) for p in self.periods]

    def visible(self, slug: str) -> list[Product]:
        t = self.period_idx
        kids = [c[0] for c in CATALOG if c[2] == slug]
        cats = {slug, *kids}
        return [p for p in self.products if p.category in cats and p.present[t]]

    # ---- pages ---------------------------------------------------------------------------
    @staticmethod
    def fmt(v: float) -> str:
        return f"{int(round(v)):,} XTF"

    def robots_txt(self) -> str:
        return (
            "# Scraping is allowed only if the bot identifies itself and its owner in the user-agent\n"
            "# and stays under 200 requests per minute. Contact techops for higher volumes.\n"
            "# (Politique reproduite de façon simplifiée pour le site synthétique.)\n"
            "Sitemap: https://www.jumia.xt/sitemap.xml\n\n"
            "User-agent: CCBot\nDisallow: /\n\n"
            "User-agent: *\n"
            "Disallow: /customer/\nDisallow: /cart/\nDisallow: /catalog/\nAllow: /catalog/productspecifications/\n"
            "Disallow: /mlp-*\nDisallow: /sp-*\nDisallow: /*?*q=\nDisallow: /*?*sort=\n"
            "Disallow: /*/*/*/\nDisallow: /*?*utm_\n"
        )

    def _card(self, p: Product, t: int, cat_name: str) -> str:
        shown, old = p.shown[t], p.old[t]
        disc = (f'<div class="bdg _dsct _sm">-{int(round((1 - shown / old) * 100))}%</div>'
                if not math.isnan(old) and old > shown else "")
        old_html = f'<div class="old">{self.fmt(old)}</div>' if not math.isnan(old) and old > shown else ""
        e = html.escape
        return (
            f'<article class="prd _fb col c-prd"><a class="core" href="{p.url}" data-gtm-id="{p.sku}" '
            f'data-gtm-name="{e(p.name)}" data-gtm-price="{shown:.0f}" data-gtm-brand="{e(p.brand)}" '
            f'data-gtm-category="{e(cat_name)}" data-ga4-item_id="{p.sku}">'
            f'<div class="img-c"><img class="img" data-src="https://static.jumia.xt/{p.sku}.jpg" alt="{e(p.name)}"></div>'
            f'<div class="info"><h3 class="name">{e(p.name)}</h3><div class="prc">{self.fmt(shown)}</div>'
            f'<div class="s-prc-w">{old_html}{disc}</div>'
            f'<div class="rev"><div class="stars _s">{p.rating} out of 5</div>({p.n_ratings})</div></div></a>'
            f'<footer class="ft"><button class="add btn _md">Ajouter au panier</button></footer></article>'
        )

    def _store(self, items: list[Product], t: int, cat_name: str) -> str:
        prods = []
        for p in items:
            old = p.old[t]
            prods.append({
                "sku": p.sku, "name": p.name, "displayName": f"{p.brand} - {p.name}", "brand": p.brand,
                "url": p.url, "categories": f"{cat_name}", "isBuyable": bool(p.buyable[t]),
                "prices": {"price": self.fmt(p.shown[t]), "rawPrice": f"{p.shown[t]:.0f}",
                           "oldPrice": None if math.isnan(old) else self.fmt(old),
                           "rawOldPrice": None if math.isnan(old) else f"{old:.0f}"},
                "rating": {"average": p.rating, "totalRatings": p.n_ratings},
            })
        return "<script>window.__STORE__=" + json.dumps({"products": prods}) + ";</script>"

    def home(self) -> str:
        links = "".join(f'<a class="itm" href="/{s}/"><span class="text">{html.escape(n)}</span></a>'
                        for s, n, parent, _ in CATALOG if parent is None)
        return (f"<html><head><title>Jumia XT | Achat en ligne</title></head><body>"
                f'<div class="flyout">{links}<a class="itm" href="/customer/account/">Mon compte</a></div>'
                f'<section class="card">{"".join(self._card(p, self.period_idx, "Accueil") for p in self.products[:8])}'
                f"</section></body></html>")

    def category_page(self, slug: str, page: int) -> Optional[str]:
        if slug not in self.categories:
            return None
        _, name, parent, _ = self.categories[slug]
        items = self.visible(slug)
        n_pages = max(1, math.ceil(len(items) / PAGE_SIZE))
        chunk = items[(page - 1) * PAGE_SIZE: page * PAGE_SIZE]
        t = self.period_idx
        kids = "".join(f'<a class="-db -pvs -phxl" href="/{c[0]}/">{html.escape(c[1])}</a>'
                       for c in CATALOG if c[2] == slug)
        pager = "".join(f'<a class="pg" href="/{slug}/?page={i}#catalog-listing" aria-label="Page {i}">{i}</a>'
                        for i in range(1, n_pages + 1))
        use_store = list(self.categories).index(slug) % 2 == 0
        store = self._store(chunk, t, name) if use_store else ""
        cards = "".join(self._card(p, t, name) for p in chunk)
        return (f"<html><head><title>{html.escape(name)} | Jumia XT</title></head><body>"
                f'<nav class="brcbs"><a href="/">Accueil</a> / {html.escape(name)}</nav>'
                f'<div class="-pvs">{kids}</div><section class="card -fh"><div class="-paxs row _no-g _4cl-3cm-shs">'
                f'{cards}</div></section><div class="pg-w -ptm -pbxl">{pager}</div>{store}</body></html>')

    def product_page(self, sku: str) -> Optional[str]:
        p = self.by_sku.get(sku)
        if not p:
            return None
        t = self.period_idx
        ld = {"@context": "https://schema.org", "@type": "Product", "name": p.name, "sku": p.sku,
              "brand": {"@type": "Brand", "name": p.brand},
              "aggregateRating": {"@type": "AggregateRating", "ratingValue": p.rating, "reviewCount": p.n_ratings},
              "offers": {"@type": "Offer", "price": f"{p.shown[t]:.0f}", "priceCurrency": "XTF",
                         "availability": "https://schema.org/" + ("InStock" if p.buyable[t] else "OutOfStock"),
                         "seller": {"@type": "Organization", "name": p.seller}}}
        return (f"<html><head><script type=\"application/ld+json\">{json.dumps(ld)}</script></head>"
                f"<body><h1>{html.escape(p.name)}</h1><div class=\"-hr -pvs\">Vendu par {html.escape(p.seller)}</div>"
                f"</body></html>")

    def corporate_page(self) -> str:
        items = "".join(
            f'<li><a href="https://www.{s.domain}/">{s.country_en}</a></li>'
            for s in CANDIDATE_SITES if s.status_hint == "active")
        return f"<html><body><h1>Locations</h1><ul>{items}</ul><p>Copyright © Jumia</p></body></html>"

    # ---- IPC officiel synthétique --------------------------------------------------------
    def official_cpi(self, weights: dict) -> pd.DataFrame:
        """IPC « officiel » simulé : mêmes tendances que le site, plus des postes non vendus en
        ligne (logement, transport public) et du bruit. Sert uniquement à la démonstration."""
        rng = np.random.default_rng(7)
        total = pd.Series(0.0, index=range(self.T))
        wsum = 0.0
        for div, w in weights.items():
            codes = [c for c in self.level if c.startswith(div)]
            if not codes:
                continue
            lv = np.exp(np.mean([np.log(self.level[c]) for c in codes], axis=0))
            total += w * lv
            wsum += w
        services = np.cumprod([1.0] + [1 + 0.03 / 12] * (self.T - 1))
        idx = 0.8 * (total / wsum).values + 0.2 * services
        idx = idx * np.exp(rng.normal(0, 0.002, self.T))
        # 12 mois d'historique supplémentaires pour pouvoir calculer un glissement annuel
        back = idx[0] / np.cumprod([1 + 0.055 / 12] * 12)[::-1]
        periods = pd.period_range(end=self.periods[-1], periods=self.T + 12, freq="M")
        values = np.concatenate([back, idx]) * 100 / idx[0]
        return pd.DataFrame({"period": periods.astype(str), "cpi": np.round(values, 2)})

    def truth(self) -> pd.DataFrame:
        rows = []
        for code, lv in self.level.items():
            for t, per in enumerate(self.periods):
                rows.append({"coicop": code, "period": str(per), "level": lv[t] * 100})
        return pd.DataFrame(rows)


# --------------------------------------------------------------------------------------
# Transport simulé
# --------------------------------------------------------------------------------------

SIMULATED_WORLD = {
    # domaine : (comportement, détail)
    "jumia.dz": ("redirect", "https://group.jumia.com/news/jumia-algeria-closure"),
    "jumia.com.tn": ("redirect", "https://group.jumia.com/news/jumia-tunisia-closure"),
    "jumia.co.za": ("dns", None),
    "jumia.cm": ("dns", None),
    "jumia.co.tz": ("timeout", None),
    "jumia.rw": ("dns", None),
    "jumia.com.eg": ("blocked", 403),  # ex. protection anti-robot : statut « restreint »
}


class FixtureTransport:
    """Répond aux requêtes sans réseau. `site.set_date()` choisit le relevé simulé."""

    def __init__(self, site: Optional[SyntheticJumia] = None):
        self.site = site or SyntheticJumia()
        self.calls = 0
        self._failed: set = set()

    def get(self, url: str, headers: dict, timeout: float) -> Response:
        self.calls += 1
        parts = urlsplit(url)
        host = parts.netloc.lower().removeprefix("www.")
        path = parts.path or "/"
        q = parse_qs(parts.query)
        el = 0.05 + (hash(url) % 50) / 1000

        if host in ("group.jumia.com", "jumia.com"):
            return Response(url, 200, self.site.corporate_page(), {"Content-Type": "text/html"}, el)

        if host == TEST_SITE.domain:
            return self._site(url, path, q, el)

        beh = SIMULATED_WORLD.get(host)
        if beh is None:  # vrai domaine actif : page d'accueil minimale avec quelques produits
            if path == "/robots.txt":
                return Response(url, 200, self.site.robots_txt().replace("jumia.xt", host), {}, el)
            return Response(url, 200, self.site.home(), {"Content-Type": "text/html"}, el)
        kind, detail = beh
        if kind == "redirect":
            return Response(detail, 200, "<html><body>Jumia has ceased operations in this country.</body></html>",
                            {}, el, history=[url])
        if kind == "blocked":
            return Response(url, detail, "Access denied", {}, el)
        return Response(url, 0, elapsed=el, error=kind)

    def _site(self, url, path, q, el) -> Response:
        s = self.site
        if path == "/robots.txt":
            return Response(url, 200, s.robots_txt(), {"Content-Type": "text/plain"}, el)
        if path == "/":
            return Response(url, 200, s.home(), {"Content-Type": "text/html"}, el)
        m = re.match(r"^/.*-(\d{5,})\.html$", path)
        if m:
            body = s.product_page(m.group(1))
            return Response(url, 200 if body else 404, body or "Not found", {}, el)
        slug = path.strip("/")
        page = int(q.get("page", ["1"])[0])
        key = f"/{slug}/?page={page}"
        if key in s._fail_once and (key, s.period_idx) not in self._failed:
            self._failed.add((key, s.period_idx))
            return Response(url, 503, "Service Unavailable", {"Retry-After": "1"}, el)
        body = s.category_page(slug, page)
        return Response(url, 200 if body else 404, body or "Not found", {"Content-Type": "text/html"}, el)
