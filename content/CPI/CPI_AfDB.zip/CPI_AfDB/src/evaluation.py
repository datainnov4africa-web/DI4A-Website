"""Comparer les méthodes de classification sur un jeu de référence.

Pourquoi ce module
------------------
« Les règles suffisent-elles, ou faut-il un modèle de langue ? » est une
question de coût autant que de qualité, et elle n'a pas la même réponse selon
le catalogue. Y répondre demande de **mesurer**, pas d'arbitrer d'avance.

Deux pièges guident la conception de ce module.

**La couverture n'est pas la justesse.** Une méthode qui classe 10 % des
produits sans jamais se tromper n'est pas « parfaite » : elle est inutilisable.
Une méthode qui classe tout avec 70 % de justesse peut l'être. Les deux chiffres
sont donc toujours rendus ensemble, et la justesse l'est deux fois : sur
**l'ensemble** des produits, et sur les seuls **classés**. Ne publier que la
seconde ferait passer une méthode muette pour une méthode excellente.

**La moyenne cache les classes rares.** Une nomenclature a des postes qui pèsent
mille produits et d'autres qui en pèsent trois. La moyenne pondérée flatte la
méthode qui réussit les gros postes ; la moyenne macro donne le même poids à
chaque classe et révèle l'abandon des petites. Les deux sont rendues.

Le coût et le temps viennent du client lui-même (`usage_summary`), pas d'une
estimation : un modèle facturé au jeton doit se comparer au temps d'un jeu de
règles qui ne coûte rien.
"""
from __future__ import annotations

import time
from typing import Optional

import numpy as np
import pandas as pd

from .config import division_of

# Les méthodes comparables. « mixte » est l'arbitrage du pipeline : le modèle
# quand sa confiance dépasse le seuil, les règles sinon.
METHODES = ("regles", "embeddings", "embeddings_voisins", "llm", "mixte")

LIBELLES = {
    "regles": "Règles (mots-clés et expressions régulières)",
    "embeddings": "Plongements multilingues, zéro-tir : prototype de classe le plus proche",
    "embeddings_voisins": "Plongements + références annotées (validation croisée, 5 plis)",
    "llm": "Modèle de langue",
    "mixte": "Mixte : modèle si confiant, règles sinon",
}

# Colonne produite par `classification.enrich` pour chaque méthode ; les
# plongements ont leur propre chemin (`embeddings.EmbeddingClassifier`).
COLONNE = {"regles": "coicop_rules", "llm": "coicop_llm", "mixte": "coicop"}


# --------------------------------------------------------------------- mesures

def _normaliser(serie: pd.Series) -> pd.Series:
    """Codes en chaînes propres ; le vide devient ``None``.

    Une chaîne vide et un ``NaN`` disent la même chose — « pas de classe » — et
    les compter séparément fausserait la couverture.
    """
    s = serie.astype("object").where(serie.notna(), None)
    s = s.map(lambda v: str(v).strip() if v is not None and str(v).strip() else None)
    return s


def metriques(verite: pd.Series, prediction: pd.Series, niveau: str = "classe") -> dict:
    """Précision, rappel, F1, couverture — au niveau classe ou division.

    ``niveau="division"`` tronque les codes à deux caractères : retrouver la
    division est déjà utile à un indice, et une méthode peut être bonne à ce
    niveau tout en hésitant entre classes voisines. Mesurer les deux évite de
    rejeter une méthode pour la mauvaise raison.
    """
    v, p = _normaliser(verite), _normaliser(prediction)
    if niveau == "division":
        v = v.map(lambda c: division_of(c) if c else None)
        p = p.map(lambda c: division_of(c) if c else None)

    total = len(v)
    evaluables = v.notna()
    n_evaluables = int(evaluables.sum())
    couverts = evaluables & p.notna()
    n_couverts = int(couverts.sum())
    justes = int((couverts & (v == p)).sum())

    classes = sorted({c for c in v[evaluables].unique() if c})
    lignes = []
    for classe in classes:
        vrai_positif = int(((p == classe) & (v == classe)).sum())
        faux_positif = int(((p == classe) & (v != classe)).sum())
        faux_negatif = int(((v == classe) & (p != classe)).sum())
        precision = vrai_positif / (vrai_positif + faux_positif) if (vrai_positif + faux_positif) else 0.0
        rappel = vrai_positif / (vrai_positif + faux_negatif) if (vrai_positif + faux_negatif) else 0.0
        f1 = 2 * precision * rappel / (precision + rappel) if (precision + rappel) else 0.0
        lignes.append({"classe": classe, "effectif": int((v == classe).sum()),
                       "précision": precision, "rappel": rappel, "F1": f1})
    par_classe = pd.DataFrame(lignes)

    if len(par_classe):
        macro = {c: float(par_classe[c].mean()) for c in ("précision", "rappel", "F1")}
        poids = par_classe["effectif"] / par_classe["effectif"].sum()
        ponderee = {c: float((par_classe[c] * poids).sum()) for c in ("précision", "rappel", "F1")}
    else:
        macro = ponderee = {"précision": 0.0, "rappel": 0.0, "F1": 0.0}

    return {
        "niveau": niveau,
        "produits": total,
        "évaluables": n_evaluables,
        "classés": n_couverts,
        "couverture": n_couverts / n_evaluables if n_evaluables else 0.0,
        # Deux justesses, et la distinction compte : la première punit le
        # silence, la seconde ne juge que ce qui a été ose.
        "justesse_globale": justes / n_evaluables if n_evaluables else 0.0,
        "justesse_sur_classés": justes / n_couverts if n_couverts else 0.0,
        "précision_macro": macro["précision"], "rappel_macro": macro["rappel"],
        "F1_macro": macro["F1"],
        "précision_pondérée": ponderee["précision"], "rappel_pondéré": ponderee["rappel"],
        "F1_pondéré": ponderee["F1"],
        "classes_attendues": len(classes),
        "par_classe": par_classe.sort_values("effectif", ascending=False) if len(par_classe) else par_classe,
    }


def confusions(verite: pd.Series, prediction: pd.Series, maximum: int = 12) -> pd.DataFrame:
    """Les confusions les plus fréquentes, pour savoir **où** une méthode échoue.

    Un F1 dit qu'une méthode se trompe ; il ne dit pas qu'elle range
    systématiquement les couches pour bébé en produits d'entretien. C'est
    pourtant cette information-là qui permet de corriger une règle.
    """
    v, p = _normaliser(verite), _normaliser(prediction)
    garde = v.notna() & p.notna() & (v != p)
    if not garde.any():
        return pd.DataFrame(columns=["attendu", "prédit", "occurrences"])
    paires = pd.DataFrame({"attendu": v[garde], "prédit": p[garde]})
    out = (paires.groupby(["attendu", "prédit"]).size()
           .rename("occurrences").reset_index()
           .sort_values("occurrences", ascending=False).head(maximum))
    return out.reset_index(drop=True)


# ------------------------------------------------------------------ exécution

def _cout_et_jetons(client) -> dict:
    """Ce que le client a réellement consommé. Zéro si aucun modèle."""
    vide = {"appels": 0, "jetons_entrée": 0, "jetons_sortie": 0, "coût_usd": 0.0,
            "depuis_cache": 0}
    if client is None or not hasattr(client, "usage_summary"):
        return vide
    try:
        resume = client.usage_summary()
    except Exception:                                   # pragma: no cover
        return vide
    if resume is None or len(resume) == 0:
        return vide
    total = dict(vide)
    for colonne in ("appels", "jetons_entrée", "jetons_sortie", "depuis_cache"):
        if colonne in resume.columns:
            total[colonne] = int(pd.to_numeric(resume[colonne], errors="coerce").fillna(0).sum())
    if "coût_usd" in resume.columns:
        total["coût_usd"] = float(pd.to_numeric(resume["coût_usd"], errors="coerce").fillna(0).sum())
    return total


def executer(produits: pd.DataFrame, methode: str, client=None, reglages=None,
             max_items: int = 600, progress: bool = False, embedder=None,
             verite: Optional[pd.Series] = None) -> dict:
    """Classe les produits par une méthode, et mesure ce que cela a coûté.

    ``classification.enrich`` produit en un passage les deux colonnes
    ``coicop_rules`` et ``coicop_llm`` : on l'appelle donc une fois par méthode
    pour que le **temps mesuré** soit celui de cette méthode-là, et non un temps
    partagé qu'on ne saurait pas répartir.

    Pour « regles », le client n'est pas passé : aucune requête n'est émise, ce
    qui est précisément ce qu'on veut mesurer.
    """
    from . import classification

    if methode not in METHODES:
        raise ValueError("méthode inconnue : {!r}. Attendu l'une de {}."
                         .format(methode, ", ".join(METHODES)))

    if methode in ("embeddings", "embeddings_voisins"):
        return _executer_embeddings(produits, embedder, max_items,
                                    verite=verite if methode == "embeddings_voisins" else None,
                                    methode=methode)

    client_effectif = None if methode == "regles" else client
    if methode != "regles" and client is None:
        return {"méthode": methode, "disponible": False,
                "raison": "aucun client de modèle n'a été fourni",
                "résultat": None, "secondes": 0.0, **_cout_et_jetons(None)}

    avant = _cout_et_jetons(client_effectif)
    debut = time.perf_counter()
    enrichi = classification.enrich(
        produits, client_effectif,
        batch_size=getattr(reglages, "llm_batch_size", 25),
        max_items=max_items, progress=progress,
        langue=getattr(reglages, "prompt_lang", "fr"))
    secondes = time.perf_counter() - debut
    apres = _cout_et_jetons(client_effectif)

    consomme = {c: apres[c] - avant.get(c, 0) for c in apres}
    enrichi = enrichi.copy()
    enrichi["coicop_predit"] = _normaliser(enrichi[COLONNE[methode]])
    return {"méthode": methode, "disponible": True, "raison": "",
            "résultat": enrichi, "secondes": secondes, **consomme}


def _executer_embeddings(produits: pd.DataFrame, embedder, max_items: int,
                         verite: Optional[pd.Series] = None, methode: str = "embeddings") -> dict:
    """Les méthodes par plongements : locales, sans appel facturé, temps mesuré.

    « embeddings » classe par le prototype de classe le plus proche, sans rien
    savoir du jeu annoté. « embeddings_voisins » ajoute les produits annotés
    comme références, en validation croisée à cinq plis : un produit n'est
    jamais classé à l'aide de sa propre étiquette. Le modèle est chargé au
    premier appel ; ce chargement est compté à part (`chargement_s`) pour ne
    pas être confondu avec le temps de classement."""
    vide = {"appels": 0, "jetons_entrée": 0, "jetons_sortie": 0, "coût_usd": 0.0, "depuis_cache": 0}
    if embedder is None:
        return {"méthode": methode, "disponible": False,
                "raison": "aucun classifieur par plongements n'a été fourni",
                "résultat": None, "secondes": 0.0, **vide}
    ok, raison = embedder.disponible()
    if not ok:
        return {"méthode": methode, "disponible": False, "raison": raison,
                "résultat": None, "secondes": 0.0, **vide}
    cible = produits.head(max_items) if max_items else produits
    if methode == "embeddings_voisins":
        etiquettes = verite.reindex(cible.index) if verite is not None else None
        if etiquettes is None or etiquettes.notna().sum() < 10:
            return {"méthode": methode, "disponible": False,
                    "raison": "il faut au moins dix produits annotés pour servir de références",
                    "résultat": None, "secondes": 0.0, **vide}
    embedder.prototypes()                                   # charge modèle et prototypes hors chrono
    debut = time.perf_counter()
    if methode == "embeddings_voisins":
        pred = embedder.valider_croise(cible["name"], etiquettes.fillna("").astype(str),
                                       rayons=cible.get("category_name"), index=cible.index)
    else:
        pred = embedder.classify(cible["name"], cible.get("category_name"), index=cible.index)
    secondes = time.perf_counter() - debut
    resultat = cible.copy()
    resultat["coicop_emb"] = pred["coicop"]
    resultat["confiance_emb"] = pred["confiance"]
    resultat["marge_emb"] = pred["marge"]
    resultat["coicop_predit"] = _normaliser(resultat["coicop_emb"])
    return {"méthode": methode, "disponible": True, "raison": "",
            "résultat": resultat, "secondes": secondes,
            "chargement_s": embedder.temps_chargement, **vide}


def comparer(produits: pd.DataFrame, verite: pd.Series, methodes=METHODES,
             client=None, reglages=None, max_items: int = 600,
             niveau: str = "classe", progress: bool = False, embedder=None) -> dict:
    """Exécute chaque méthode et rend un tableau comparable.

    ``verite`` est alignée sur l'index de ``produits``. Les produits sans
    vérité connue sont ignorés par les métriques mais comptés dans le temps :
    une méthode les traite quand même.
    """
    lignes, details = [], {}
    for methode in methodes:
        passage = executer(produits, methode, client, reglages, max_items, progress,
                           embedder=embedder, verite=verite)
        if not passage["disponible"]:
            lignes.append({"méthode": methode, "libellé": LIBELLES.get(methode, methode),
                           "disponible": "non", "raison": passage["raison"]})
            continue
        resultat = passage["résultat"]
        mesure = metriques(verite.reindex(resultat.index), resultat["coicop_predit"], niveau)
        details[methode] = {"résultat": resultat, "mesure": mesure,
                            "confusions": confusions(verite.reindex(resultat.index),
                                                     resultat["coicop_predit"])}
        lignes.append({
            "méthode": methode, "libellé": LIBELLES.get(methode, methode),
            "disponible": "oui", "raison": "",
            "couverture": mesure["couverture"],
            "justesse_globale": mesure["justesse_globale"],
            "justesse_sur_classés": mesure["justesse_sur_classés"],
            "F1_macro": mesure["F1_macro"], "F1_pondéré": mesure["F1_pondéré"],
            "précision_macro": mesure["précision_macro"], "rappel_macro": mesure["rappel_macro"],
            "secondes": round(passage["secondes"], 2),
            "produits_par_seconde": round(len(resultat) / passage["secondes"], 1) if passage["secondes"] else None,
            "appels_modèle": passage["appels"], "jetons": passage["jetons_entrée"] + passage["jetons_sortie"],
            "coût_usd": round(passage["coût_usd"], 4),
            "coût_pour_1000": round(passage["coût_usd"] / len(resultat) * 1000, 4) if len(resultat) else 0.0,
        })
    return {"tableau": pd.DataFrame(lignes), "détails": details, "niveau": niveau}


# ------------------------------------------------------------------- lecture

def recommander(tableau: pd.DataFrame, marge_f1: float = 0.03) -> list:
    """Ce que le tableau permet de conclure — et ce qu'il ne permet pas.

    La règle appliquée est explicite : on ne recommande un modèle payant que
    s'il gagne **plus que la marge** sur le F1 macro. En deçà, l'écart n'est
    pas une raison suffisante d'introduire un coût, une dépendance réseau et
    une variabilité entre exécutions.

    Rend des phrases, pas un verdict : le choix revient à l'institut.
    """
    phrases = []
    utilisables = tableau[tableau.get("disponible", "oui") == "oui"] if "disponible" in tableau else tableau
    if len(utilisables) == 0:
        return ["Aucune méthode n'a pu être évaluée."]
    if "F1_macro" not in utilisables.columns:
        return ["Le tableau ne porte pas de F1 : rien à conclure."]

    classe = utilisables.sort_values("F1_macro", ascending=False)
    meilleure = classe.iloc[0]
    phrases.append(
        "Meilleur F1 macro : **{}** à {:.3f}, avec {:.1%} de couverture et "
        "{:.1%} de justesse sur les produits classés."
        .format(meilleure["méthode"], meilleure["F1_macro"],
                meilleure.get("couverture", float("nan")),
                meilleure.get("justesse_sur_classés", float("nan"))))

    regles = utilisables[utilisables["méthode"] == "regles"]
    if len(regles) and meilleure["méthode"] != "regles":
        ecart = meilleure["F1_macro"] - float(regles.iloc[0]["F1_macro"])
        cout = float(meilleure.get("coût_pour_1000", 0) or 0)
        if ecart < marge_f1:
            phrases.append(
                "Mais l'écart avec les règles n'est que de {:+.3f} de F1, sous "
                "la marge de {:.2f} retenue. Les règles ne coûtent rien, ne "
                "dépendent d'aucun réseau et donnent le même résultat à chaque "
                "exécution : à cet écart-là, elles restent préférables."
                .format(ecart, marge_f1))
        else:
            phrases.append(
                "L'écart avec les règles est de {:+.3f} de F1, pour {:.4f} USD "
                "par millier de produits. Le gain est réel ; reste à décider "
                "s'il justifie une dépendance à un service tiers."
                .format(ecart, cout))

    lentes = utilisables[utilisables["produits_par_seconde"].notna()] if "produits_par_seconde" in utilisables else utilisables.iloc[0:0]
    if len(lentes) > 1:
        rapide = lentes.sort_values("produits_par_seconde", ascending=False).iloc[0]
        lente = lentes.sort_values("produits_par_seconde").iloc[0]
        if float(lente["produits_par_seconde"]) > 0:
            facteur = float(rapide["produits_par_seconde"]) / float(lente["produits_par_seconde"])
            if facteur >= 2:
                phrases.append(
                    "**{}** traite {:.0f} fois plus de produits par seconde que "
                    "**{}**. Sur un catalogue de dix mille références, cela se "
                    "compte en heures."
                    .format(rapide["méthode"], facteur, lente["méthode"]))

    faibles = utilisables[utilisables.get("couverture", 1) < 0.5] if "couverture" in utilisables else utilisables.iloc[0:0]
    for _, ligne in faibles.iterrows():
        phrases.append(
            "**{}** ne classe que {:.1%} des produits. Sa justesse sur les "
            "classés ({:.1%}) ne dit rien de ceux qu'elle laisse de côté — et "
            "un indice a besoin de couverture."
            .format(ligne["méthode"], ligne["couverture"],
                    ligne.get("justesse_sur_classés", float("nan"))))

    phrases.append(
        "Ces chiffres valent **pour ce jeu de référence**. Un catalogue dont "
        "les libellés sont rédigés autrement donnera d'autres résultats : "
        "refaire la mesure sur un échantillon annoté de vos propres données "
        "est le seul moyen de trancher pour votre cas.")
    return phrases


def charger_reference(chemin, colonne_verite: str = "coicop_vrai") -> dict:
    """Lit un jeu de référence annoté : produits + classe attendue.

    Accepte CSV, Parquet ou Excel. Les colonnes attendues sont celles d'un
    relevé — ``sku``, ``name``, et au moins ``category_name`` — plus la colonne
    de vérité. Rend des phrases en cas de manque, pas une exception.
    """
    from pathlib import Path

    chemin = Path(chemin)
    if not chemin.exists():
        return {"ok": False, "produits": None, "vérité": None,
                "problèmes": ["Fichier introuvable : {}".format(chemin)]}
    try:
        if chemin.suffix.lower() == ".parquet":
            df = pd.read_parquet(chemin)
        elif chemin.suffix.lower() in (".xlsx", ".xls"):
            df = pd.read_excel(chemin)
        else:
            df = pd.read_csv(chemin)
    except Exception as erreur:
        return {"ok": False, "produits": None, "vérité": None,
                "problèmes": ["Lecture impossible : {}".format(erreur)]}

    problemes = []
    if colonne_verite not in df.columns:
        problemes.append(
            "Colonne « {} » absente : c'est la classe COICOP attendue, sans "
            "elle aucune méthode ne peut être notée.".format(colonne_verite))
    for colonne in ("sku", "name"):
        if colonne not in df.columns:
            problemes.append("Colonne « {} » absente.".format(colonne))
    if problemes:
        return {"ok": False, "produits": None, "vérité": None, "problèmes": problemes}

    for colonne in ("category_name", "brand", "price", "division_hint"):
        if colonne not in df.columns:
            df[colonne] = None
    verite = _normaliser(df[colonne_verite])
    produits = df.drop(columns=[colonne_verite])
    avertissements = []
    sans = int(verite.isna().sum())
    if sans:
        avertissements.append(
            "{} ligne(s) sans classe attendue : elles sont classées mais ne "
            "comptent pas dans les notes.".format(sans))
    return {"ok": True, "produits": produits, "vérité": verite,
            "problèmes": [], "avertissements": avertissements,
            "produits_annotés": int(verite.notna().sum()),
            "classes": int(verite.nunique())}


# ------------------------------------------------- un jeu de référence honnête

# Bruits observés sur de vrais catalogues en ligne. Chacun est une façon réelle
# dont un vendeur rédige son libellé, et chacun met en défaut une règle écrite
# pour un libellé propre.
ABREVIATIONS = {
    "kilogramme": "kg", "kilogrammes": "kg", "kilo": "kg", "litre": "L",
    "litres": "L", "millilitre": "ml", "gramme": "g", "grammes": "g",
    "paquet": "pqt", "bouteille": "bt", "sachet": "sch", "boîte": "bte",
    "boite": "bte", "pièces": "pcs", "pieces": "pcs",
}
ORNEMENTS = ("PROMO", "NEW", "Original", "100% authentique", "Livraison rapide",
             "Meilleur prix", "Qualité supérieure", "Offre spéciale",
             "Import", "Lot", "Vendu par Jumia")


def bruiter(reference: pd.DataFrame, intensite: float = 0.7, graine: int = 7,
            colonne: str = "name") -> pd.DataFrame:
    """Rend un jeu de référence réaliste, sans toucher à sa vérité.

    **Pourquoi c'est nécessaire.** Le jeu tiré du simulateur donne 100 % à la
    méthode par règles — non parce qu'elle est parfaite, mais parce que le
    simulateur fabrique ses libellés à partir des mêmes gabarits que ceux
    contre lesquels les règles ont été écrites. Mesurer là-dessus reviendrait
    à faire passer un examen dont on a écrit le corrigé : le résultat serait
    flatteur et sans valeur.

    Cette fonction rapproche les libellés de ce qu'un vrai catalogue publie —
    abréviations, ornements commerciaux, ordre des mots, majuscules, et
    parfois la disparition du mot qui portait toute l'information. La classe
    attendue, elle, ne bouge pas : c'est ce qui rend la mesure interprétable.

    ``intensite`` est la probabilité qu'un libellé donné soit altéré.

    **Ce que cette fonction ne suffit pas à faire.** Mesuré le 14/10/2026 sur
    380 produits : les règles obtiennent 100 % sur le jeu brut et **98,7 %** sur
    le jeu bruité à 0,7. Le bruit déplace les mots, les abrège et les crie, mais
    il laisse le mot porteur — « riz parfumé » reste reconnaissable. Et le
    retirer rendrait la vérité irrécupérable y compris pour un humain : personne
    ne classe « NESTLE 400g ».

    Autrement dit : **un jeu synthétique ne départage pas des méthodes de
    classification**, parce que sa vérité et les règles partagent un
    vocabulaire. Il sert à vérifier que la chaîne de mesure fonctionne, et à
    rien d'autre. Le seul banc d'essai qui tranche est un échantillon de vos
    propres relevés, annoté à la main — voir :func:`echantillon_a_annoter`.
    """
    rng = np.random.default_rng(graine)
    out = reference.copy()
    originaux = out[colonne].fillna("").astype(str)
    nouveaux, touches = [], 0

    for libelle in originaux:
        if not libelle or rng.random() > intensite:
            nouveaux.append(libelle)
            continue
        touches += 1
        mots = libelle.split()

        # 1. abréviations — « 1 litre » devient « 1 L »
        mots = [ABREVIATIONS.get(m.lower().strip(",."), m) for m in mots]

        # 2. ornement commercial, au début ou à la fin
        if rng.random() < 0.45:
            orne = str(rng.choice(ORNEMENTS))
            mots = ([orne] + mots) if rng.random() < 0.5 else (mots + [orne])

        # 3. la marque passe devant, comme sur beaucoup de places de marché
        if len(mots) > 3 and rng.random() < 0.3:
            mots = [mots[-1]] + mots[:-1]

        # 4. majuscules intégrales — fréquent, et met en défaut une règle
        #    écrite sans insensibilité à la casse
        if rng.random() < 0.25:
            mots = [m.upper() for m in mots]

        # 5. le cas difficile : le mot porteur disparaît. C'est ce qui arrive
        #    quand un vendeur titre « NESTLE 400g » sans dire ce que c'est.
        if len(mots) > 2 and rng.random() < 0.12:
            mots.pop(rng.integers(0, len(mots) - 1))

        nouveaux.append(" ".join(mots).strip())

    out[colonne] = nouveaux
    out.attrs["libellés_altérés"] = touches
    out.attrs["intensité"] = intensite
    return out


def echantillon_a_annoter(produits: pd.DataFrame, nombre: int = 120,
                          graine: int = 0, par_division: bool = True) -> pd.DataFrame:
    """Tire un échantillon de VOS produits, à annoter à la main.

    C'est le seul banc d'essai qui tranche. Un jeu synthétique partage son
    vocabulaire avec les règles et leur donne 100 % ; vos libellés réels, non.

    L'échantillon est **stratifié par division** quand c'est possible : tirer au
    hasard sur un catalogue dominé par l'électronique donnerait un banc d'essai
    qui ne dit rien de l'alimentaire, c'est-à-dire de ce qui pèse dans un indice
    des prix.

    La colonne ``coicop_vrai`` est laissée vide : c'est vous qui la remplissez.
    Comptez une à deux heures pour cent vingt produits, et refaites-la à chaque
    refonte importante du catalogue.
    """
    from . import classification

    df = produits.copy()
    if "coicop_rules" not in df.columns:
        regles = [classification.classify_rules(n, c) for n, c in
                  zip(df.get("name", pd.Series(dtype=str)).fillna(""),
                      df.get("category_name", pd.Series(dtype=str)).fillna(""))]
        df["coicop_rules"] = [r[0] for r in regles]
    df["division_rules"] = df["coicop_rules"].map(
        lambda c: division_of(c) if isinstance(c, str) else None)

    if par_division and df["division_rules"].notna().any():
        groupes = df.groupby("division_rules", dropna=False)
        par_groupe = max(1, nombre // max(1, groupes.ngroups))
        tire = groupes.apply(
            lambda g: g.sample(min(len(g), par_groupe), random_state=graine),
            include_groups=False).reset_index(drop=False)
        tire = tire.drop(columns=[c for c in tire.columns if c.startswith("level_")],
                         errors="ignore")
    else:
        tire = df.sample(min(len(df), nombre), random_state=graine)

    colonnes = [c for c in ("sku", "name", "brand", "category_name",
                            "category_slug", "price", "coicop_rules") if c in tire.columns]
    out = tire[colonnes].head(nombre).copy()
    # Vide a dessein : la proposition des regles est a cote pour aider, pas
    # pour etre recopiee. La remplir d'avance biaiserait l'annotation.
    out["coicop_vrai"] = ""
    return out.reset_index(drop=True)
