"""Étape 4 : classification COICOP 2018, quantités, marques et doublons.

Deux classificateurs travaillent en parallèle :
  * des **règles** transparentes (mots-clés FR/EN), toujours disponibles, qui servent de
    référence et de dernier recours ;
  * un **LLM** (Ollama, Groq ou Gemini) qui lit le nom complet et la catégorie Jumia.
Le code retenu est celui du LLM s'il est valide et suffisamment sûr de lui, sinon celui des
règles. Les deux sont conservés pour mesurer leur accord.
"""
from __future__ import annotations

import json
import logging
import math
import re
from typing import Literal, Optional

import numpy as np
import pandas as pd
from pydantic import BaseModel, Field, field_validator
from tqdm.auto import tqdm

from .config import COICOP_CODES, COICOP_CODES_EN, COICOP_DIVISIONS, COICOP_DIVISIONS_EN, division_of
from .utils import norm_text

log = logging.getLogger("jumia_cpi.classification")

# --------------------------------------------------------------------------------------
# Règles COICOP (texte normalisé : minuscules, sans accents). L'ordre compte : les règles
# non alimentaires précises passent avant les règles alimentaires génériques, pour que
# « huile capillaire » aille en soins personnels et « huile moteur » en transports.
# --------------------------------------------------------------------------------------
RULES: list[tuple[str, str]] = [
    ("07.2", r"huile moteur|engine oil|motor oil|lubrifiant|liquide de refroidissement|coolant|pneus?\b|tyres?|batterie auto|car battery|bougies? d.allumage|spark plug|"
             # Accessoires de véhicule. On nomme la pièce, jamais « car » seul :
             # « gourde en forme de car » est une gourde d'enfant, pas une automobile.
             r"windscreen|windshield|essuie.glaces?|wiper blade|pare.brise|housse (de )?(siege )?(auto|voiture)|car cover|car (door|window) (guard|edge|protection|visor)|"
             r"enjoliveurs?|\bjantes?\b|retroviseurs?|plaques? d.immatriculation|license plate|tapis de (voiture|sol auto)|car floor mats?|porte.velos?|roof rack|galerie de toit|"
             r"plaquettes? de frein|brake pads?|amortisseurs?|shock absorber|filtre a (huile|air|carburant)|oil filter|courroie de distribution|alternateur|demarreur auto|klaxon|lave.glace|"
             r"car (back )?seats? (organi[sz]er|covers?|cushions?|protectors?)|seat ?belts?|ceintures? de securite|tableaux? de bord"),
    ("01.1.9", r"cereales infantiles|baby food|aliments? (pour )?bebe|lait infantile|infant formula|petits pots"),
    ("13.1", r"cheveux|capillaire|\bhair\b|shampo|conditioner|savon|\bsoap|gel douche|shower gel|dentifrice|toothpaste|brosse a dents|toothbrush|deodorant|\bdeo\b|\bparfums?\b|eau de parfum|perfume|eau de toilette|lotion|lait de corps|body lotion|\bcreme\b|\bcream\b|karite|shea butter|maquillage|makeup|rouge a levres|lipstick|vernis|rasoir|razor|serviettes? hygieniques?|sanitary|couches?\b|diapers?|lingettes|wipes|papier toilette|toilet (paper|tissue)|mouchoirs|coton.tige|seche.cheveux|hair dryer|tondeuse (a cheveux|barbe)|clipper|lisseur|straightener"),
    ("06.1", r"masques? (chirurgica|medica)|surgical mask|face mask|vitamine|vitamin|complement alimentaire|supplement|comprimes|gelules|capsules|thermometre|thermometer|tensiometre|blood pressure|glucometre|glucometer|pansement|bandage|test de grossesse|preservatifs?|condoms?|medicament|paracetamol|ibuprofen|oxymetre|oximeter"),
    # Un nettoyant pour biberons est un produit d'entretien, pas un article de
    # puériculture : la règle passe avant celle qui suit, sinon « biberon » l'emporte.
    ("05.6", r"(nettoyant|liquide vaisselle) .{0,14}biberons?|(baby )?bottle cleaner"),
    # Puériculture. En COICOP 2018, les articles pour bébés — poussettes, couffins,
    # sièges-auto enfant, biberons, tire-lait — relèvent des effets personnels (13.2.2),
    # et non du mobilier ni de la santé. La règle est placée ici à dessein : après les
    # aliments infantiles (01.1.9) et les soins (13.1), pour que le lait infantile et le
    # savon pour bébé gardent leur classe ; avant 05.1 et 03.1, pour que « matelas à
    # langer » n'aille pas en literie ni « bavoir » en vêtement. Elle nomme l'article et
    # jamais « bébé » seul : un body en coton pour nouveau-né est un vêtement (03.1).
    ("13.2", r"porte.bebes?|baby carriers?|baby sling|echarpe de portage|poussettes?|strollers?|\bpram\b|pushchair|"
             r"sieges? auto (bebe|enfant)|(baby|infant|child|children|toddler|newborn) .{0,18}(car|safety) seat|car seat for (baby|infant|newborn|child)|booster seat|"
             r"baby feeding (set|tableware|storage)|coffret repas (bebe|enfant)|"
             r"biberons?|(baby|feeding) bottles?|bottle warmer|chauffe.biberon|sterilisateur (de |pour )?biberons?|bottle sterili[sz]er|tetines?|"
             r"tire.lait|breast ?pumps?|bavoirs?|\bbibs?\b|"
             r"\bpotty\b|pot de toilette|reducteur de (toilette|wc)|(entrainement|apprentissage) a la proprete|"
             r"trotteurs?|baby walkers?|youpala|berceaux?|\bmoise\b|couffin|\bcribs?\b|\bcradle|bassinet|carry.cots?|"
             r"parcs? (pour )?(bebe|enfant)|playpen|lit parapluie|baby .{0,20}beds?\b|baby cots?\b|lits? (de |pour )bebe|chaises? hautes?|high chairs?|"
             r"(matelas|table) a langer|changing (mat|table|pad)|\balese|urine mat|tapis d.eveil|baby gym|"
             r"barriere de securite (bebe|enfant)|baby gate|cache.prises?"),
    ("09.1", r"console|playstation|xbox|nintendo|manette|gamepad|appareil photo|\bcamera\b|drone|\bpiano\b|guitare|guitar"),
    ("08.1", r"smartphone|telephone|\bphone|iphone|tablette|\btablet\b|\bipad|ordinateur|laptop|pc portable|imprimante|printer|routeur|router|modem|chargeur|charger|power ?bank|ecouteurs|earbuds|earphones|headphones|casque audio|cable usb|usb.c|cle usb|flash drive|disque dur|hard drive|carte memoire|memory card|smartwatch|montre connectee|\btv\b|televiseur|television|barre de son|soundbar|enceinte|speaker|haut.?parleurs?|\bhifi\b|hi.fi|radio (fm|reveil|portable)|poste radio|amplificateur audio|platine (vinyle|disque|dj)|turntable|microphones?|home cinema|decodeur|projecteur|projector|souris|\bmouse\b|clavier|keyboard|\becran\b|monitor"),
    ("09.2", r"ballon|football|basket.ball|yoga|halteres|dumbbell|velo d.appartement|tapis de course|treadmill|jouets?|\btoys?\b|puzzle|poupee|\bdoll|lego|jeu de societe|board game|corde a sauter|"
             # Matériel de sport. « boxe » porte des frontières de mot : sans elles, elle
             # attraperait les « boxers », qui sont des sous-vêtements (03.1).
             r"foam rollers?|rouleaux? de massage|balles? de massage|speedball|\bkarate\b|\bboxe\b|boxing (gloves|bag)|"
             r"raquettes?|\brackets?\b|tapis de yoga|resistance bands?|elastiques? de resistance|banc de musculation|"
             r"appareils? de (fitness|musculation)|equipements? de (fitness|musculation)|protege.dents|velo elliptique|rameur"),
    ("09.7", r"cahiers?|\bstylos?|\bpens?\b|crayons?|pencils?|\blivres?\b|\bbooks?\b|papeterie|stationery|classeur|agenda|ramette|papier a4|a4 paper"),
    ("09.3", r"croquettes|pet food|litiere|graines a semer|engrais|fertili[sz]er|pot de fleur"),
    ("05.3", r"refrigerateur|frigo|fridge|refrigerator|congelateur|freezer|machine a laver|washing machine|lave.linge|climatiseur|air condition|cuisiniere|cooker|gaziniere|\bfour\b|\boven|micro.?ondes|microwave|mixeur|blender|robot (de )?cuisine|food processor|fer a repasser|\biron\b|ventilateur|\bfan\b|bouilloire|kettle|friteuse|fryer|grille.pain|toaster|aspirateur|vacuum|plaque (electrique|de cuisson)|hotplate|cafetiere|coffee maker|extracteur de jus|juicer|rechaud"),
    ("05.4", r"marmite|casserole|\bpoele\b|frying pan|service de table|assiettes?|\bplates\b|\bverres?\b|tasses?|\bmugs?\b|couverts|cutlery|ustensiles?|thermos|bouteille isotherme|tupperware|boite de conservation|boites? a the|tea box|theiere|teapot|"
             # Contenants de transport et de rangement : gourdes, boîtes à déjeuner,
             # bacs. Ce sont des ustensiles de ménage (05.4), non de la bagagerie.
             r"gourdes?|shakers?|lunch ?box|lunch bags?|boites? a (lunch|dejeuner)|bento|"
             r"boites? de rangement|storage box(es)?|bacs? de stockage|paniers? de rangement"),
    ("05.2", r"\bdraps?\b|bed ?sheets?|housse|couette|duvet|oreillers?|pillows?|serviettes? de bain|towels?|rideaux?|curtains?|\bnappe|tablecloth|couverture|blanket"),
    ("05.1", r"matelas|mattress|canape|\bsofa|\blit\b|bed frame|armoire|wardrobe|chaises?|chairs?|\btables?\b|\bbureau\b|\bdesk\b|etagere|shelf|\btapis\b|carpet|\brugs?\b|"
             # Articles d'ameublement : un cadre photo ou un miroir décoratif meuble la
             # pièce, il ne sert pas la table — d'où 05.1 et non 05.4. Le miroir de
             # maquillage reste en 13.1, dont la règle est examinée plus haut.
             r"cadres? photo|(photo|picture) frames?|miroirs? (mural|decoratif|sur pied|de salle de bain)|(wall|decorative|full.length) mirrors?|decoration murale|wall (decor|art|sticker)|stickers? mura(l|ux)|porte.manteaux?|portemanteau|coat rack|"
             r"tableaux? (decoratifs?|deco|mura(l|ux))|tableau decoration|art mural|wall paintings?|peintures? murales?"),
    ("05.5", r"perceuse|\bdrill|tournevis|screwdriver|\boutils?\b|\btools?\b|ampoules?|\bbulbs?\b|\blampe|torche|flashlight|rallonge|multiprise|extension (cord|socket)|tondeuse a gazon|lawn mower|groupe electrogene|generator|stabilisateur|stabili[sz]er|panneau solaire|solar panel|"
             # Quincaillerie de porte et calfeutrage. « coupe-vent » est volontairement
             # absent : sur Jumia il désigne des cagoules et des coupe-vent de ski.
             r"butees? de porte|door stoppers?|bas de portes?|boudin (de porte|contre les courants)|joints? de porte|coupe.froid|weather ?strip|"
             r"loquets?|charnieres?|hinges?|serrures? (de porte|a cylindre|encastrable)|door locks?|cadenas|padlocks?|poignees? de porte|door handles?"),
    ("05.6", r"lessive|detergent|washing powder|liquide vaisselle|dishwashing|eau de javel|bleach|\bjavel|nettoyant|cleaner|desinfectant|disinfectant|insecticide|serpilliere|\bmop\b|\bbalai|broom|eponges?|sponge|sacs? poubelle|garbage bags?|assouplissant|softener|desodorisant|air freshener|allumettes|\bmatches\b|bougies?|candles?"),
    ("04.5", r"bouteille de gaz|gas cylinder|charbon|charcoal|petrole lampant|kerosene"),
    ("13.2", r"\bmontres?\b|\bwatch(es)?\b|bijoux|jewel|bracelet|collier|necklace|\bbague\b|boucles d.oreilles|earrings|sac a main|handbag|valise|suitcase|portefeuille|wallet|lunettes de soleil|sunglasses|sac a dos|backpack"),
    ("03.2", r"chaussures?|\bshoes?\b|baskets|sneakers?|sandales?|sandals?|escarpins|\bbottes?\b|\bboots?\b|mocassins|\btongs\b|slippers|claquettes|pointure"),
    ("03.1", r"t.?shirt|chemise|\bshirt|\brobe\b|\bdress|\bjeans?\b|pantalon|trousers|\bpants\b|\bjupe|skirt|\bveste|jacket|\bpull\b|sweater|hoodie|\bsweat|\bshorts?\b|boxer|culotte|soutien.gorge|\bbra\b|chaussettes|socks|pyjama|\bpagne|\bwax\b|boubou|abaya|survetement|tracksuit|lingerie|maillot|"
             # Accessoires d'habillement (03.1.3) et layette. Ils manquaient : « casquette »
             # et « ceinture » dominaient les noms non classés. « cap » seul est écarté —
             # c'est aussi un bouchon et un cache d'objectif ; « ceinture de sécurité »
             # l'est aussi, elle appartient au véhicule.
             r"casquettes?|baseball cap|bonnets?|cagoules?|balaclava|chapeaux?|\bhats?\b|echarpes?|\bscarf|scarves|"
             # « gants » est volontairement absent : d'une part « gants?\b » attrapait
             # « élé-gant » (488 noms sur 536), d'autre part les 203 gants réellement
             # vendus sont de cuisine, de travail, de sport ou en nitrile — pas de
             # l'habillement. Mieux vaut les laisser non classés que les y forcer.
             r"ceintures?(?! de securite| de maintien| abdominale| lombaire)|cravates?|bodysuits?|rompers?|onesie|barboteuse|grenouillere|"
             # Frontière indispensable sur « collant » : sans elle, 175 des 180
             # correspondances étaient des papiers peints « auto-collants ».
             r"leggings?|\bcollants?\b|calecons?"),
    ("02.1", r"\bbieres?\b|\bbeers?\b|\bvins?\b|\bwine|whisky|vodka|liqueur|champagne|\brhum|\brum\b|\bgin\b|cognac"),
    ("02.2", r"cigarettes?|\btabac|tobacco|chicha|shisha"),
    ("01.2.5", r"\beau (minerale|de source|plate)|mineral water|spring water|bottled water"),
    ("01.2.6", r"boissons? gazeuses?|\bsoda|soft drink|\bcola\b|limonade|lemonade|energy drink|boisson energisante|\bmalt\b|bissap|ginger drink"),
    ("01.2.1", r"\bjus\b|juice|nectar"),
    ("01.2.2", r"\bcafe\b|coffee|nescafe|espresso"),
    # « thé » normalisé donne « the », qui est aussi l'article anglais : sur 89 produits
    # classés en thé, 71 l'étaient par un « the » de phrase (« Fits To The Size Of The
    # Car »). On exige donc une tournure de boisson, et « tea » reste admis seul.
    ("01.2.3", r"^the\b|\bthes\b|\bthe (vert|noir|blanc|glace|citron|menthe|nature|en sachets?)|sachets? de the|\btea\b|infusions?\b|tisane|kinkeliba"),
    ("01.2.4", r"cacao|cocoa|chocolat en poudre|poudre cacaotee|\bmilo\b|ovaltine|ovomaltine|bournvita"),
    ("01.1.3", r"sardines?|\bthon\b|\btuna|poissons?|\bfish|maquereau|mackerel|crevettes|shrimp|anchois"),
    ("01.1.2", r"viande|\bmeat|corned ?beef|poulet|chicken|\bboeuf|\bbeef|saucisses?|sausages?|jambon|\bham\b|mouton|\blamb\b"),
    # Frontières de mot sur « beurre » et « butter » : sans elles, « Butterfly Baby
    # Potty » et les pendentifs papillon tombaient dans les corps gras.
    ("01.1.5", r"huiles?\b|\boils?\b|\bbeurre\b|\bbutter\b|margarine|\bghee|saindoux"),
    ("01.1.4", r"\blait\b|\bmilk|yaourt|yoghurt|yogurt|fromage|cheese|\boeufs?\b|\beggs?\b|creme fraiche|evaporated|\blaban"),
    ("01.1.8", r"\bsucre|\bsugar|chocolat|chocolate|bonbons?|candy|sweets|confiture|\bjam\b|\bmiel\b|honey|ice cream|chewing"),
    ("01.1.7", r"tomates?|tomato|oignons?|onions?|haricots?|\bbeans\b|lentilles|lentils|\bpois\b|\bpeas\b|pommes? de terre|potato|manioc|cassava|igname|\byams?\b|plantain|legumes|vegetables|\bail\b|garlic|gombo|attieke|\bgari\b|garri"),
    ("01.1.6", r"\bfruits?\b|bananes?|banana|\bdattes|arachides?|peanuts?|\bnoix\b|\bnuts\b|amandes|almonds|raisins secs|mangues?"),
    ("01.1.1", r"\briz\b|\brice\b|spaghetti|\bpates\b|pasta|macaroni|farine|flour|semoule|semolina|couscous|\bmais\b|maize|\bcorn\b|cereales?|cereal|avoine|\boats\b|biscuits?|crackers|\bpain\b|bread|nouilles|noodles|indomie|fonio|\bmil\b|millet|sorgho|vermicelle"),
    ("01.1.9", r"\bsel\b|\bsalt\b|bouillon|\bcubes?\b|maggi|epices?|spices?|poivre|pepper|piment|mayonnaise|ketchup|moutarde|mustard|vinaigre|vinegar|\bsauce|levure|yeast|soupe|\bsoup|condiments?"),
]
_RULES = [(c, re.compile(p)) for c, p in RULES]

CATEGORY_RULES: list[tuple[str, str]] = [
    ("01", r"epicerie|supermarche|supermarket|grocer|alimentation|\bfood\b|boissons|beverage|drinks|laitier|dairy|"
           r"conserves?|cereales|\briz\b|huiles|condiments|sucre|snacks|petit.dejeuner|breakfast"),
    ("13", r"beaute|beauty|hygiene|soins|personal care|sante|health|bebe|baby|puericulture"),
    ("08", r"telephone|phone|tablette|tablet|electronique|electronic|informatique|computing|ordinateur|computer|\btv\b|audio"),
    ("05", r"maison|\bhome\b|cuisine|kitchen|electromenager|appliance|bureau|office|meuble|furniture|bricolage|diy"),
    ("03", r"\bmode\b|fashion|vetement|clothing|chaussure|shoe"),
    ("09", r"sport|loisir|jeux|gaming|jouet|toy|livre|book|papeterie|stationery|jardin|garden|animaux|pet"),
    ("07", r"\bauto|moto|automobile|vehicule|car accessories"),
]
_CAT_RULES = [(c, re.compile(p)) for c, p in CATEGORY_RULES]

# Divisions et groupes où un prix au kilo ou au litre a un sens
MEASURABLE_PREFIXES = ("01", "02", "05.6", "07.2", "13.1")


def classify_rules(name: str, category: str = "") -> tuple[Optional[str], Optional[str]]:
    """(code COICOP, mot-clé déclencheur) à partir du nom, puis de la catégorie Jumia."""
    for text in (norm_text(name), norm_text(f"{name} {category}")):
        for code, rx in _RULES:
            m = rx.search(text)
            if m:
                return code, m.group(0)
    return None, None


def category_division(name: str, slug: str = "") -> Optional[str]:
    text = norm_text(f"{name} {slug.replace('-', ' ')}")
    for div, rx in _CAT_RULES:
        if rx.search(text):
            return div
    code, _ = classify_rules(name, "")
    return division_of(code)


# --------------------------------------------------------------------------------------
# Quantités et prix unitaires
# --------------------------------------------------------------------------------------
MEASURE_RX = re.compile(r"(\d+(?:[.,]\d+)?)\s*(kgs?|kilos?|grammes?|gr|g|litres?|liters?|ltr|l|ml|cl)\b", re.I)
PACK_RX = [
    re.compile(r"(?:pack|lot|boite|carton|paquet|set|bundle) de (\d+)(?!\s*(?:[.,]\d+)?\s*(?:kgs?|g|gr|l|ml|cl|litres?|grammes?)\b)", re.I),
    re.compile(r"\b(\d+)\s*(?:x|×|\*)\s*\d", re.I),
    re.compile(r"\bx\s?(\d+)\b", re.I),
    re.compile(r"\b(\d+)\s*(?:sachets?|rouleaux|rolls?|couches|diapers|comprimes|tablets|capsules|gelules|pieces|pcs|"
               r"unites|units|cubes|canettes|cans|bouteilles|bottles|pots|boites)\b", re.I),
]
UNIT_FACTORS = {"kg": ("kg", 1.0), "kgs": ("kg", 1.0), "kilo": ("kg", 1.0), "kilos": ("kg", 1.0),
                "g": ("kg", 0.001), "gr": ("kg", 0.001), "gramme": ("kg", 0.001), "grammes": ("kg", 0.001),
                "l": ("l", 1.0), "ltr": ("l", 1.0), "litre": ("l", 1.0), "litres": ("l", 1.0),
                "liter": ("l", 1.0), "liters": ("l", 1.0), "ml": ("l", 0.001), "cl": ("l", 0.01)}


def is_measurable(code: Optional[str]) -> bool:
    return bool(code) and str(code).startswith(MEASURABLE_PREFIXES)


def extract_quantity(name: str, code: Optional[str] = None) -> dict:
    """'Eau minérale 1,5L - Pack de 6' → {'quantity': 9.0, 'unit': 'l', 'pack_count': 6}."""
    text = norm_text(name).replace(",", ".")
    # Les ',' décimales sont ramenées à '.' ; on retire les séparateurs de milliers éventuels
    pack = 1
    for rx in PACK_RX:
        m = rx.search(text)
        if m:
            n = int(m.group(1))
            if 1 < n <= 1000:
                pack = n
                break
    if not is_measurable(code):
        return {"quantity": float(pack), "unit": "unité", "pack_count": pack}
    m = MEASURE_RX.search(text)
    if m:
        val = float(m.group(1))
        unit, f = UNIT_FACTORS[m.group(2).lower()]
        # « 2 x 5 kg » : le multiplicateur est déjà dans pack ; « 5kg x 2 » aussi
        return {"quantity": round(val * f * pack, 6), "unit": unit, "pack_count": pack}
    return {"quantity": float(pack), "unit": "unité", "pack_count": pack}


# --------------------------------------------------------------------------------------
# Marques
# --------------------------------------------------------------------------------------
GENERIC = {"generic", "generique", "no brand", "sans marque", "other", "autre", "autres", "oem", ""}


def normalize_brand(brand: Optional[str], name: str = "") -> str:
    b = (brand or "").strip()
    if norm_text(b) in GENERIC:
        return "Generic"
    b = re.sub(r"\s+", " ", b)
    return b if any(c.isupper() for c in b[1:]) else b.title()


# --------------------------------------------------------------------------------------
# Enrichissement par LLM
# --------------------------------------------------------------------------------------
VALID_CODES = set(COICOP_CODES) | set(COICOP_DIVISIONS)


class ItemEnrichment(BaseModel):
    id: str
    coicop: str
    quantity: Optional[float] = Field(default=None, ge=0)
    unit: Optional[Literal["kg", "g", "l", "ml", "cl", "unit", "unité"]] = None
    pack_count: Optional[int] = Field(default=1, ge=1, le=10000)
    brand: Optional[str] = None
    confidence: float = Field(default=0.5, ge=0, le=1)

    @field_validator("coicop")
    @classmethod
    def _valid(cls, v):
        v = v.strip()
        if v not in VALID_CODES and division_of(v) not in COICOP_DIVISIONS:
            raise ValueError(f"code COICOP inconnu : {v}")
        return v


class EnrichmentBatch(BaseModel):
    items: list[ItemEnrichment]


PROMPT_LANGUES = ("fr", "en")


def system_prompt(langue: str = "fr") -> str:
    """Le prompt système, en français ou en anglais.

    Le carnet français envoie le français, le carnet anglais l'anglais : les
    deux versions disent exactement la même chose, et la liste des codes
    autorisés est la même, seuls les libellés changent. Le schéma de
    validation reste identique : un code hors liste est refusé quelle que soit
    la langue dans laquelle le modèle a raisonné."""
    langue = (langue or "fr").lower()[:2]
    if langue not in PROMPT_LANGUES:
        raise ValueError("langue de prompt inconnue : {!r} (attendu fr ou en)".format(langue))
    if langue == "en":
        codes = "\n".join(f"- {k}: {v}" for k, v in COICOP_CODES_EN.items())
        divisions = "\n".join(f"- {k}: {v}" for k, v in COICOP_DIVISIONS_EN.items())
        return f"""You are a consumer price statistician. For each product sold online in Africa,
you return its COICOP 2018 class, its net content, the number of units in the pack and its normalised brand.

Allowed codes (as fine as possible):
{codes}
If no fine code fits, use the division:
{divisions}

Rules:
- "quantity" and "unit" describe the content of ONE unit (e.g. "Water 1.5L - Pack of 6" -> 1.5, "l", pack_count 6).
- Units: kg, g, l, ml, cl, or "unit" for counted objects (phone, nappy, sachet...).
- Dosages (1000mg), storage capacities (128GB), power ratings (350W) and screen sizes are not quantities.
- "brand": proper brand name (usual capitalisation); "Generic" if none.
- "confidence" between 0 and 1.
Answer only in JSON: {{"items": [{{"id": "...", "coicop": "...", "quantity": 1.5, "unit": "l",
"pack_count": 6, "brand": "...", "confidence": 0.9}}]}} with one element per product, in the same order."""
    codes = "\n".join(f"- {k} : {v}" for k, v in COICOP_CODES.items())
    divisions = "\n".join(f"- {k} : {v}" for k, v in COICOP_DIVISIONS.items())
    return f"""Tu es statisticien des prix à la consommation. Pour chaque produit vendu en ligne en Afrique,
tu renvoies sa classe COICOP 2018, son contenu net, le nombre d'unités du lot et sa marque normalisée.

Codes autorisés (le plus fin possible) :
{codes}
Si aucun code fin ne convient, utilise la division :
{divisions}

Règles :
- « quantity » et « unit » décrivent le contenu d'UNE unité (ex. « Eau 1,5L - Pack de 6 » → 1.5, "l", pack_count 6).
- Unités : kg, g, l, ml, cl, ou "unit" pour les objets comptés (téléphone, couche, sachet…).
- Les dosages (1000mg), capacités de stockage (128Go), puissances (350W) et tailles d'écran ne sont pas des quantités.
- « brand » : nom de marque propre (majuscules d'usage) ; "Generic" si aucune.
- « confidence » entre 0 et 1.
Réponds uniquement en JSON : {{"items": [{{"id": "...", "coicop": "...", "quantity": 1.5, "unit": "l",
"pack_count": 6, "brand": "...", "confidence": 0.9}}]}} avec un élément par produit, dans le même ordre."""


def user_prompt(batch: pd.DataFrame) -> str:
    items = [{"id": str(r.sku), "name": r.name, "brand_raw": r.brand or "", "category": r.category_name or ""}
             for r in batch.itertuples()]
    return json.dumps({"products": items}, ensure_ascii=False)


def rules_handler(system: str, user: str) -> str:
    """Réponse « LLM » produite par les règles : même format, sans réseau."""
    products = json.loads(user)["products"]
    out = []
    for p in products:
        code, _ = classify_rules(p["name"], p.get("category", ""))
        code = code or "13"
        q = extract_quantity(p["name"], code)
        unit = {"kg": "kg", "l": "l"}.get(q["unit"], "unit")
        per_unit = q["quantity"] / q["pack_count"] if unit != "unit" else 1
        out.append({"id": p["id"], "coicop": code, "quantity": round(per_unit, 6), "unit": unit,
                    "pack_count": q["pack_count"], "brand": normalize_brand(p.get("brand_raw"), p["name"]),
                    "confidence": 0.6 if code != "13" else 0.2})
    return json.dumps({"items": out}, ensure_ascii=False)


def _to_base(q: Optional[float], unit: Optional[str], pack: Optional[int]) -> tuple[Optional[float], str]:
    pack = pack or 1
    if unit in ("kg", "g"):
        return (q or 0) * (0.001 if unit == "g" else 1) * pack or None, "kg"
    if unit in ("l", "ml", "cl"):
        return (q or 0) * {"l": 1, "ml": 0.001, "cl": 0.01}[unit] * pack or None, "l"
    return float(pack), "unité"


def enrich(products: pd.DataFrame, client, batch_size: int = 25, max_items: int = 600,
           min_confidence: float = 0.5, progress: bool = True, langue: str = "fr") -> pd.DataFrame:
    """Ajoute coicop_rules, coicop_llm, coicop (final), quantités, prix unitaire et marque."""
    df = products.copy()
    rules = [classify_rules(n, c) for n, c in zip(df["name"].fillna(""), df["category_name"].fillna(""))]
    df["coicop_rules"] = [r[0] for r in rules]
    df["mot_clé"] = [r[1] for r in rules]
    df["coicop_llm"] = None
    df["llm_confidence"] = np.nan
    df["llm_provider"] = None
    df["brand_llm"] = None
    df["qty_llm"] = np.nan
    df["unit_llm"] = None

    todo = df.head(max_items) if client is not None else df.iloc[0:0]
    sysmsg = system_prompt(langue)
    batches = [todo.iloc[i:i + batch_size] for i in range(0, len(todo), batch_size)]
    for b in tqdm(batches, desc="Enrichissement LLM", disable=not progress or not batches):
        try:
            res, meta = client.complete_json(sysmsg, user_prompt(b), EnrichmentBatch, task="classification")
        except Exception as e:
            log.warning("Lot non enrichi : %s", e)
            continue
        by_id = {it.id: it for it in res.items}
        for idx, r in b.iterrows():
            it = by_id.get(str(r["sku"]))
            if not it:
                continue
            q, u = _to_base(it.quantity, it.unit, it.pack_count)
            df.loc[idx, ["coicop_llm", "llm_confidence", "llm_provider", "brand_llm", "qty_llm", "unit_llm"]] = [
                it.coicop, it.confidence, meta["provider"], it.brand, q, u]

    use_llm = df["coicop_llm"].notna() & (df["llm_confidence"] >= min_confidence)
    df["coicop"] = np.where(use_llm, df["coicop_llm"], df["coicop_rules"])
    df["coicop_source"] = np.where(use_llm, "llm (" + df["llm_provider"].fillna("?").astype(str) + ")",
                                   np.where(df["coicop_rules"].notna(), "règles", "non classé"))
    # Indice de catégorie en dernier recours (division seule)
    miss = df["coicop"].isna() & df["division_hint"].notna()
    df.loc[miss, "coicop"] = df.loc[miss, "division_hint"]
    df.loc[miss, "coicop_source"] = "catégorie"
    df["division"] = df["coicop"].map(division_of)

    qs = [extract_quantity(n, c) for n, c in zip(df["name"].fillna(""), df["coicop"])]
    df["qty_rules"] = [q["quantity"] for q in qs]
    df["unit_rules"] = [q["unit"] for q in qs]
    df["pack_count"] = [q["pack_count"] for q in qs]
    measurable = df["coicop"].map(is_measurable)
    llm_ok = df["qty_llm"].notna() & df["unit_llm"].isin(["kg", "l"]) & measurable
    df["quantity"] = np.where(llm_ok, df["qty_llm"], df["qty_rules"])
    df["unit"] = np.where(llm_ok, df["unit_llm"], df["unit_rules"])
    df["unit_price"] = df["price"] / df["quantity"].where(df["quantity"] > 0)
    df["brand_norm"] = [b if isinstance(b, str) and b else normalize_brand(r, n)
                        for b, r, n in zip(df["brand_llm"], df["brand"], df["name"])]
    return df


# --------------------------------------------------------------------------------------
# Doublons : un même article vendu par plusieurs vendeurs
# --------------------------------------------------------------------------------------
STOP = {"de", "du", "la", "le", "les", "des", "et", "a", "au", "pour", "avec", "en", "the", "of", "and", "for",
        "with", "pack", "lot", "boite"}


def _tokens(name: str, brand: str) -> set:
    t = set(norm_text(name).replace(",", ".").split()) - STOP - set(norm_text(brand).split())
    return {w for w in t if not re.fullmatch(r"[\d.]+", w)}


def find_duplicates(df: pd.DataFrame, threshold: float = 0.75) -> pd.DataFrame:
    """Regroupe les annonces d'un même article (même marque, classe, contenu ; noms proches)."""
    out = df.copy()
    out["cluster_id"] = out["sku"].astype(str)
    key = (out["brand_norm"].fillna("").str.lower() + "|" + out["coicop"].fillna("") + "|"
           + out["quantity"].round(3).astype(str) + "|" + out["unit"].fillna(""))
    for _, g in out.groupby(key):
        if len(g) < 2 or g["brand_norm"].iloc[0] == "Generic":
            continue
        idx = list(g.index)
        toks = {i: _tokens(out.at[i, "name"], out.at[i, "brand_norm"]) for i in idx}
        parent = {i: i for i in idx}

        def find(i):
            while parent[i] != i:
                parent[i] = parent[parent[i]]
                i = parent[i]
            return i

        for a_i, a in enumerate(idx):
            for b in idx[a_i + 1:]:
                ta, tb = toks[a], toks[b]
                if ta and tb and len(ta & tb) / len(ta | tb) >= threshold:
                    parent[find(b)] = find(a)
        for i in idx:
            out.at[i, "cluster_id"] = str(out.at[find(i), "sku"])
    out["cluster_size"] = out.groupby("cluster_id")["sku"].transform("size")
    return out


# --------------------------------------------------------------------------------------
# Validation humaine
# --------------------------------------------------------------------------------------


def validation_sample(df: pd.DataFrame, n: int = 60, seed: int = 0) -> pd.DataFrame:
    """Échantillon stratifié par division à faire annoter (colonne coicop_humain vide)."""
    g = df.groupby("division", group_keys=False)
    per = max(1, n // max(1, df["division"].nunique()))
    s = g.apply(lambda x: x.sample(min(len(x), per), random_state=seed))
    cols = ["sku", "name", "brand", "category_name", "coicop_rules", "coicop_llm", "coicop"]
    s = s[cols].copy()
    s["coicop_humain"] = ""
    return s.reset_index(drop=True)


def cohen_kappa(a: pd.Series, b: pd.Series) -> float:
    labels = sorted(set(a) | set(b))
    cm = pd.crosstab(a, b).reindex(index=labels, columns=labels, fill_value=0).values
    n = cm.sum()
    if n == 0:
        return float("nan")
    po = np.trace(cm) / n
    pe = (cm.sum(0) * cm.sum(1)).sum() / n ** 2
    return float((po - pe) / (1 - pe)) if pe < 1 else 1.0


def agreement_report(df: pd.DataFrame, truth: str, preds: list[str]) -> tuple[pd.DataFrame, dict]:
    """Taux d'accord (classe et division) et kappa de Cohen ; matrices de confusion par division."""
    rows, mats = [], {}
    base = df[df[truth].notna() & (df[truth].astype(str) != "")]
    for p in preds:
        d = base[base[p].notna()]
        if d.empty:
            continue
        t_div, p_div = d[truth].map(division_of), d[p].map(division_of)
        rows.append({"classificateur": p, "n": len(d),
                     "accord_code": round((d[truth] == d[p]).mean() * 100, 1),
                     "accord_division": round((t_div == p_div).mean() * 100, 1),
                     "kappa_division": round(cohen_kappa(t_div, p_div), 3)})
        mats[p] = pd.crosstab(t_div.rename("référence"), p_div.rename("prédit"))
    return pd.DataFrame(rows), mats
