# -*- coding: utf-8 -*-
"""Classer en COICOP par plongements multilingues (embeddings).

Pourquoi cette méthode
----------------------
Les règles reconnaissent des mots ; elles sont aveugles à une langue ou à un
vocabulaire qu'elles n'ont pas prévu. Le modèle de langue lit, mais coûte, a
des quotas et ne rend pas deux fois la même réponse. Entre les deux, un modèle
de plongements multilingue place « Cric hydraulique », « Hydraulic trolley
jack » et « رافعة هيدروليكية » au même endroit d'un espace vectoriel, tourne en
local, ne coûte rien à l'appel et donne le même résultat à chaque exécution.

Comment elle classe
-------------------
* Chaque classe COICOP reçoit un **prototype** : son libellé en français et en
  anglais, suivi des mots-clés de la règle correspondante. Le prototype est
  encodé une fois.
* Chaque produit est encodé (libellé, puis rayon si demandé) et rattaché à la
  classe dont le prototype est le plus proche en similarité cosinus. La
  similarité est la **confiance**, et l'écart avec la deuxième classe la
  **marge** : deux seuils permettent de ne pas classer ce qui est trop loin ou
  trop ambigu, pour que la couverture reste une mesure honnête.
* Des **références annotées** peuvent s'ajouter aux prototypes : un produit
  proche d'un exemple annoté prend son code. Plus l'échantillon annoté grandit,
  plus la méthode se rapproche d'un plus-proches-voisins supervisé.

Le modèle est chargé à la demande : `sentence-transformers` n'est pas une
dépendance du moteur, et son absence rend la méthode « indisponible », pas le
carnet cassé. Un `encoder` injectable permet de tester la logique sans modèle.
"""
from __future__ import annotations

import logging
import re
import time
from typing import Callable, Iterable, Optional

import numpy as np
import pandas as pd

from .config import COICOP_CODES

log = logging.getLogger("jumia_cpi.embeddings")

# Modèles proposés dans le carnet. Tous multilingues, tous sur Hugging Face.
MODELES = {
    "intfloat/multilingual-e5-large": "le plus précis des e5, 560 M de paramètres, ~2,2 Go",
    "BAAI/bge-m3": "très bon en multilingue, 100+ langues dont l'arabe, ~2,2 Go",
    "intfloat/multilingual-e5-base": "compromis vitesse/précision, ~1,1 Go",
    "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2": "léger et rapide sur CPU, ~470 Mo",
}
MODELE_PAR_DEFAUT = "intfloat/multilingual-e5-large"

# Libellés anglais des classes, pour que le prototype parle les deux langues
# des sites Jumia. Les libellés français viennent de config.COICOP_CODES.
LIBELLES_EN = {
    "01.1.1": "Cereals and cereal products: rice, bread, pasta, flour, biscuits",
    "01.1.2": "Meat: beef, chicken, lamb, sausages, ham",
    "01.1.3": "Fish and seafood: sardines, tuna, shrimp, mackerel",
    "01.1.4": "Milk, dairy products and eggs: milk, yoghurt, cheese, butter-free dairy",
    "01.1.5": "Oils and fats: cooking oil, butter, margarine, ghee",
    "01.1.6": "Fruits and nuts: bananas, mangoes, peanuts, dates, almonds",
    "01.1.7": "Vegetables, tubers and pulses: tomatoes, onions, beans, potatoes, cassava, plantain",
    "01.1.8": "Sugar, confectionery and desserts: sugar, chocolate, candy, jam, honey, ice cream",
    "01.1.9": "Ready-made food and other food products: salt, spices, bouillon cubes, sauces, soups, baby food",
    "01.2.1": "Fruit and vegetable juices: juice, nectar",
    "01.2.2": "Coffee: ground coffee, instant coffee, espresso capsules",
    "01.2.3": "Tea and infusions: tea bags, green tea, herbal infusions",
    "01.2.4": "Cocoa drinks: cocoa powder, chocolate drink powder",
    "01.2.5": "Water: bottled mineral water, spring water",
    "01.2.6": "Soft drinks: soda, cola, lemonade, energy drinks, malt drinks",
    "02.1": "Alcoholic beverages: beer, wine, whisky, vodka, rum, gin",
    "02.2": "Tobacco: cigarettes, shisha tobacco",
    "03.1": "Clothing: shirts, dresses, jeans, trousers, jackets, underwear, socks, fabrics",
    "03.2": "Footwear: shoes, sneakers, sandals, boots, slippers",
    "04.5": "Electricity, gas and other fuels: gas cylinder, charcoal, kerosene",
    "05.1": "Furniture and furnishings: mattress, sofa, bed, wardrobe, chairs, tables, carpets",
    "05.2": "Household textiles: bed sheets, duvets, pillows, towels, curtains, blankets",
    "05.3": "Household appliances: fridge, freezer, washing machine, cooker, microwave, blender, iron, fan, kettle, vacuum cleaner",
    "05.4": "Glassware, tableware and kitchen utensils: pots, pans, plates, glasses, cups, cutlery, thermos, food containers",
    "05.5": "Tools and equipment for house and garden: drill, screwdriver, tools, light bulbs, lamps, torches, extension cords, generators, solar panels",
    "05.6": "Goods for routine household maintenance: detergent, washing powder, dishwashing liquid, bleach, cleaner, insecticide, mop, broom, sponges, bin bags, candles",
    "06.1": "Medicines and health products: face masks, vitamins, supplements, tablets, thermometer, blood pressure monitor, bandages, condoms, paracetamol",
    "07.2": "Operation of personal transport equipment: engine oil, lubricants, tyres, car battery, spark plugs, car parts",
    "08.1": "Information and communication equipment: smartphone, phone, tablet, laptop, computer, printer, router, charger, power bank, earphones, headphones, USB cable, memory card, smartwatch, TV, speaker, soundbar, projector, mouse, keyboard, monitor",
    "09.1": "Durable recreational goods: game console, playstation, camera, drone, piano, guitar",
    "09.2": "Other recreational items and sports equipment: football, yoga mat, dumbbells, treadmill, toys, puzzle, dolls, board games",
    "09.3": "Gardens, plants and pets: pet food, cat litter, seeds, fertiliser, flower pots",
    "09.7": "Newspapers, books and stationery: notebooks, pens, pencils, books, stationery, A4 paper",
    "13.1": "Personal care: shampoo, soap, shower gel, toothpaste, toothbrush, deodorant, perfume, lotion, body cream, shea butter, make-up, razor, sanitary towels, diapers, wipes, toilet paper, hair dryer, clippers",
    "13.2": "Personal effects: watches, jewellery, bracelets, necklaces, handbags, suitcases, wallets, sunglasses, backpacks, baby carriers, strollers",
}


def _mots_cles_des_regles(code: str, maximum: int = 40) -> list[str]:
    """Les mots-clés lisibles de la règle d'un code, débarrassés de la syntaxe regex."""
    from .classification import RULES

    mots = []
    for c, motif in RULES:
        if c != code:
            continue
        for morceau in motif.split("|"):
            propre = re.sub(r"\\b|\\s|\(\?:|[()?^$\[\]{}*+.]", " ", morceau)
            propre = re.sub(r"\s+", " ", propre).strip()
            if len(propre) >= 3 and re.search(r"[a-z]", propre) and propre not in mots:
                mots.append(propre)
    return mots[:maximum]


def texte_prototype(code: str) -> str:
    """Le texte long qui représente une classe : libellé FR, libellé EN, mots-clés."""
    parties = [COICOP_CODES.get(code, code)]
    if code in LIBELLES_EN:
        parties.append(LIBELLES_EN[code])
    mots = _mots_cles_des_regles(code)
    if mots:
        parties.append("Exemples : " + ", ".join(mots))
    return ". ".join(parties)


def textes_prototypes(code: str) -> list[str]:
    """Plusieurs textes courts par classe, plutôt qu'un seul long.

    Mesuré le 28/10/2026 sur le jeu de référence avec un petit modèle : un
    prototype unique qui concatène quarante mots-clés se brouille — « Riz
    parfumé Kora » tombait dans les plats préparés — et donnait 56 % de
    justesse. Un prototype par mot-clé, et la classe prend le meilleur de ses
    prototypes : le libellé court du produit rencontre un texte aussi court."""
    libelle = COICOP_CODES.get(code, code)
    textes = [libelle]
    if code in LIBELLES_EN:
        textes.append(LIBELLES_EN[code])
    for mot in _mots_cles_des_regles(code):
        textes.append("{} ({})".format(mot, libelle))
    return textes


def _est_e5(nom: str) -> bool:
    return "e5" in nom.lower()


class EmbeddingClassifier:
    """Classe des libellés par proximité avec des prototypes de classes COICOP.

    `encoder` : fonction `list[str] -> np.ndarray` (lignes normalisées ou non).
    Sans `encoder`, le modèle `sentence-transformers` nommé est chargé à la
    première utilisation.
    """

    def __init__(self, model_name: str = MODELE_PAR_DEFAUT, encoder: Optional[Callable] = None,
                 device: Optional[str] = None, batch_size: int = 64,
                 min_similarite: float = 0.0, min_marge: float = 0.0,
                 avec_rayon: bool = False, codes: Optional[Iterable[str]] = None):
        self.model_name = model_name
        self._encoder = encoder
        self._modele = None
        self.device = device
        self.batch_size = batch_size
        self.min_similarite = min_similarite
        self.min_marge = min_marge
        self.avec_rayon = avec_rayon
        self.codes = list(codes) if codes else list(COICOP_CODES)
        self._proto: Optional[np.ndarray] = None
        self._proto_codes: list[str] = []
        self._ref: Optional[np.ndarray] = None
        self._ref_codes: list[str] = []
        self.temps_chargement: Optional[float] = None
        self.dimension: Optional[int] = None

    # --- disponibilité ---------------------------------------------------------
    def disponible(self) -> tuple[bool, str]:
        if self._encoder is not None:
            return True, "encodeur fourni"
        try:
            import sentence_transformers  # noqa: F401
        except ImportError:
            return False, ("le paquet sentence-transformers n'est pas installé "
                           "(pip install sentence-transformers)")
        return True, "modèle {}".format(self.model_name)

    def _charger(self):
        if self._encoder is not None:
            return
        from sentence_transformers import SentenceTransformer

        debut = time.perf_counter()
        self._modele = SentenceTransformer(self.model_name, device=self.device)
        self.temps_chargement = time.perf_counter() - debut
        self.dimension = self._modele.get_sentence_embedding_dimension()
        log.info("modèle %s chargé en %.1f s (dimension %s)", self.model_name,
                 self.temps_chargement, self.dimension)

    def encode(self, textes: list[str], role: str = "query") -> np.ndarray:
        """Vecteurs unitaires. Les modèles e5 attendent un préfixe « query: » /
        « passage: » ; les autres non."""
        self._charger()
        if _est_e5(self.model_name) and self._encoder is None:
            # Tâche symétrique (texte court contre texte court) : e5 recommande
            # le même préfixe « query: » des deux côtés.
            textes = ["query: {}".format(t) for t in textes]
        if self._encoder is not None:
            vecteurs = np.asarray(self._encoder(textes), dtype=float)
        else:
            vecteurs = np.asarray(self._modele.encode(
                textes, batch_size=self.batch_size, normalize_embeddings=True,
                show_progress_bar=False), dtype=float)
        normes = np.linalg.norm(vecteurs, axis=1, keepdims=True)
        normes[normes == 0] = 1.0
        return vecteurs / normes

    # --- prototypes et références ---------------------------------------------
    def prototypes(self) -> np.ndarray:
        """Une ligne par prototype ; `_proto_codes` donne la classe de chaque ligne."""
        if self._proto is None:
            textes, codes = [], []
            for c in self.codes:
                for t in textes_prototypes(c):
                    textes.append(t)
                    codes.append(c)
            self._proto_codes = codes
            self._proto = self.encode(textes, role="passage")
        return self._proto

    def ajouter_references(self, libelles: list[str], codes: list[str]) -> int:
        """Des produits déjà annotés : ils comptent comme des prototypes supplémentaires."""
        paires = [(str(l), str(c)) for l, c in zip(libelles, codes)
                  if l is not None and c is not None and str(c).strip()]
        if not paires:
            return 0
        vecteurs = self.encode([l for l, _ in paires], role="query")
        self._ref = vecteurs if self._ref is None else np.vstack([self._ref, vecteurs])
        self._ref_codes.extend(c for _, c in paires)
        return len(paires)

    # --- classification -------------------------------------------------------
    def classify(self, noms: Iterable[str], rayons: Optional[Iterable[str]] = None,
                 index=None) -> pd.DataFrame:
        """Pour chaque libellé : code, confiance (cosinus), second code et marge."""
        noms = [str(n) if n is not None else "" for n in noms]
        if self.avec_rayon and rayons is not None:
            rayons = [str(r) if r is not None and str(r) != "nan" else "" for r in rayons]
            textes = [("{} — {}".format(n, r) if r else n) for n, r in zip(noms, rayons)]
        else:
            textes = noms
        if not textes:
            return pd.DataFrame(columns=["coicop", "confiance", "second", "marge"])
        matrice = self.prototypes()
        codes = list(self._proto_codes)
        if self._ref is not None:
            matrice = np.vstack([matrice, self._ref])
            codes = codes + self._ref_codes
        produits = self.encode(textes, role="query")
        sims = produits @ matrice.T                       # cosinus : tout est unitaire
        # Une classe vaut le meilleur de ses prototypes (et de ses références).
        classes = sorted(set(codes))
        colonnes = {c: [j for j, k in enumerate(codes) if k == c] for c in classes}
        par_classe = np.column_stack([sims[:, cols].max(axis=1) for c, cols in colonnes.items()])
        ordre = np.argsort(-par_classe, axis=1)
        lignes = []
        for i in range(len(textes)):
            code1 = classes[ordre[i, 0]]
            sim1 = float(par_classe[i, ordre[i, 0]])
            if len(classes) > 1:
                code2 = classes[ordre[i, 1]]
                sim2 = float(par_classe[i, ordre[i, 1]])
                marge = sim1 - sim2
            else:
                code2, marge = None, sim1
            garde = sim1 >= self.min_similarite and marge >= self.min_marge
            lignes.append({"coicop": code1 if garde else None, "confiance": round(sim1, 4),
                           "second": code2, "marge": round(marge, 4)})
        return pd.DataFrame(lignes, index=index)

    def valider_croise(self, noms: Iterable[str], codes: Iterable[str], plis: int = 5,
                       rayons: Optional[Iterable[str]] = None, graine: int = 7, index=None) -> pd.DataFrame:
        """Prototypes + références annotées, mesurés **sans fuite** : chaque produit
        est classé avec, pour seules références, les produits des autres plis.

        C'est ce que vaudrait la méthode une fois un échantillon annoté
        disponible — la mesure qui compte pour décider, puisque le zéro-tir ne
        fait que reconnaître des libellés de classes. Mesuré le 28/10/2026 sur
        le jeu de référence du projet avec multilingual-e5-base : 54 % de
        justesse en zéro-tir, 94 % avec les références en cinq plis."""
        noms = [str(n) if n is not None else "" for n in noms]
        codes = [str(c) if c is not None else "" for c in codes]
        if self.avec_rayon and rayons is not None:
            rayons = [str(r) if r is not None and str(r) != "nan" else "" for r in rayons]
            textes = [("{} — {}".format(n, r) if r else n) for n, r in zip(noms, rayons)]
        else:
            textes = noms
        n = len(textes)
        if n == 0:
            return pd.DataFrame(columns=["coicop", "confiance", "second", "marge"])
        proto = self.prototypes()
        vecteurs = self.encode(textes, role="query")
        attribution = np.random.default_rng(graine).integers(0, max(1, plis), size=n)
        annotes = np.array([bool(c.strip()) for c in codes])
        lignes = [None] * n
        for k in range(max(1, plis)):
            test = np.where(attribution == k)[0]
            if len(test) == 0:
                continue
            ref = np.where((attribution != k) & annotes)[0]
            matrice = np.vstack([proto, vecteurs[ref]]) if len(ref) else proto
            etiquettes = list(self._proto_codes) + [codes[i] for i in ref]
            classes = sorted(set(etiquettes))
            colonnes = {c: [j for j, e in enumerate(etiquettes) if e == c] for c in classes}
            sims = vecteurs[test] @ matrice.T
            par_classe = np.column_stack([sims[:, cols].max(axis=1) for cols in colonnes.values()])
            ordre = np.argsort(-par_classe, axis=1)
            for rang, i in enumerate(test):
                code1, sim1 = classes[ordre[rang, 0]], float(par_classe[rang, ordre[rang, 0]])
                if len(classes) > 1:
                    code2, sim2 = classes[ordre[rang, 1]], float(par_classe[rang, ordre[rang, 1]])
                    marge = sim1 - sim2
                else:
                    code2, marge = None, sim1
                garde = sim1 >= self.min_similarite and marge >= self.min_marge
                lignes[i] = {"coicop": code1 if garde else None, "confiance": round(sim1, 4),
                             "second": code2, "marge": round(marge, 4)}
        return pd.DataFrame(lignes, index=index)

    def describe(self) -> dict:
        ok, raison = self.disponible()
        return {"modèle": self.model_name, "disponible": ok, "détail": raison,
                "dimension": self.dimension, "chargement_s": self.temps_chargement,
                "prototypes": len(self._proto_codes), "classes": len(set(self._proto_codes)),
                "références": len(self._ref_codes),
                "seuil_similarité": self.min_similarite, "seuil_marge": self.min_marge}
