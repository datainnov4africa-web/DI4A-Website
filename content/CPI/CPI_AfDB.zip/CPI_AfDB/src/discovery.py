"""Étape 1 : découverte des sites Jumia nationaux.

Deux sources sont croisées :
  * un registre interne (`config.CANDIDATE_SITES`) qui inclut les pays quittés, pour documenter
    leur statut ;
  * les pages publiques de Jumia (page « Locations » du site corporate, sélecteur de pays),
    analysées pour repérer tout domaine `jumia.*` absent du registre.
"""
from __future__ import annotations

import logging
import re

import pandas as pd
from bs4 import BeautifulSoup

from .config import CANDIDATE_SITES, CORPORATE_URLS, DOMAIN_PATTERN, Site
from .fetch import Fetcher, RobotsDisallowed

log = logging.getLogger("jumia_cpi.discovery")

STATUS_LABELS = {
    "active": "Actif selon Jumia",
    "exited": "Retrait annoncé",
    "historical": "Activité suspendue (historique)",
    "discovered": "Découvert automatiquement",
    "synthetic": "Site synthétique",
}


def scan_corporate_pages(fetcher: Fetcher, urls=CORPORATE_URLS) -> tuple[dict, list[dict]]:
    """Retourne {domaine: texte du lien} et le journal des pages consultées."""
    found: dict[str, str] = {}
    journal = []
    for url in urls:
        try:
            r = fetcher.get(url)
        except RobotsDisallowed as e:
            journal.append({"page": url, "statut": "interdit par robots.txt", "domaines": 0})
            log.info(str(e))
            continue
        if not r.ok:
            journal.append({"page": url, "statut": f"échec ({r.status or r.error})", "domaines": 0})
            continue
        soup = BeautifulSoup(r.text, "lxml")
        n0 = len(found)
        for a in soup.find_all("a", href=True):
            m = DOMAIN_PATTERN.search(a["href"])
            if m and m.group(1).lower() not in ("jumia.com",):
                found.setdefault(m.group(1).lower(), a.get_text(" ", strip=True))
        for m in DOMAIN_PATTERN.finditer(soup.get_text(" ")):
            d = m.group(1).lower()
            if d != "jumia.com":
                found.setdefault(d, "")
        journal.append({"page": url, "statut": f"HTTP {r.status}", "domaines": len(found) - n0})
    return found, journal


def discover_sites(fetcher: Fetcher, extra_sites: tuple[Site, ...] = (), scan: bool = True) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Construit le registre des sites (un pays par ligne) et le journal de découverte."""
    sites = list(CANDIDATE_SITES) + list(extra_sites)
    known = {s.domain for s in sites}
    corporate, journal = ({}, [])
    if scan:
        corporate, journal = scan_corporate_pages(fetcher)
    for dom, label in corporate.items():
        if dom not in known:
            tld = dom.split(".")[-1].upper()
            sites.append(Site(tld, "", label or tld, label or tld, dom, "?", "?", ("?",), "discovered",
                              "Domaine trouvé sur les pages publiques de Jumia"))
            known.add(dom)
    rows = []
    for s in sites:
        d = s.to_dict()
        d["cité_par_jumia"] = s.domain in corporate
        d["statut_attendu"] = STATUS_LABELS.get(s.status_hint, s.status_hint)
        rows.append(d)
    df = pd.DataFrame(rows)
    order = ["iso2", "iso3", "country_fr", "domain", "url", "currency", "currency_symbol", "languages",
             "status_hint", "statut_attendu", "cité_par_jumia", "note", "country_en"]
    return df[order], pd.DataFrame(journal)
