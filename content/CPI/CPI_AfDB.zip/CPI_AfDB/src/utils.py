"""Outils transverses : journalisation, secrets, analyse des prix affichés, environnement."""
from __future__ import annotations

import logging
import math
import os
import re
import sys
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

LOG_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"


def setup_logging(log_file: Optional[Path] = None, level: int = logging.INFO) -> logging.Logger:
    """Journal dans un fichier (détaillé) et à l'écran (avertissements seulement)."""
    root = logging.getLogger("jumia_cpi")
    root.setLevel(logging.DEBUG)
    for h in list(root.handlers):
        root.removeHandler(h)
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.WARNING)
    console.setFormatter(logging.Formatter("⚠️ %(message)s"))
    root.addHandler(console)
    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setLevel(level)
        fh.setFormatter(logging.Formatter(LOG_FORMAT))
        root.addHandler(fh)
    root.propagate = False
    return root


def in_colab() -> bool:
    return "google.colab" in sys.modules


def now_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------------------------
# Secrets : variable d'environnement → secret Colab → fichier .env → saisie masquée
# --------------------------------------------------------------------------------------


def _read_dotenv(path: Path) -> dict:
    out = {}
    if not path.exists():
        return out
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def get_secret(name: str, ask: bool = False, search_dirs: tuple = (".", "..")) -> Optional[str]:
    """Retourne la valeur d'un secret sans jamais l'afficher ni l'écrire sur disque."""
    v = os.environ.get(name)
    if v:
        return v
    try:  # Colab : icône 🔑 « Secrets »
        from google.colab import userdata  # type: ignore

        v = userdata.get(name)
        if v:
            return v
    except Exception:
        pass
    for d in search_dirs:
        v = _read_dotenv(Path(d) / ".env").get(name)
        if v:
            return v
    if ask:
        try:
            from getpass import getpass

            v = getpass(f"{name} (saisie masquée, laisser vide pour ignorer) : ").strip()
            return v or None
        except Exception:
            return None
    return None


def mask(secret: Optional[str]) -> str:
    if not secret:
        return "—"
    return secret[:3] + "…" + f"({len(secret)} caractères)"


# --------------------------------------------------------------------------------------
# Texte et prix
# --------------------------------------------------------------------------------------


def strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def norm_text(s: Optional[str]) -> str:
    if not s:
        return ""
    s = strip_accents(str(s)).lower()
    s = re.sub(r"[^a-z0-9.,%/ ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


_NUM = re.compile(r"\d[\d\s,.  ']*")


def parse_number(raw: str) -> Optional[float]:
    """'4,500' → 4500 ; '1.234,50' → 1234.5 ; '1,234.50' → 1234.5 ; '12 500' → 12500."""
    s = re.sub(r"[\s  ']", "", raw.strip())
    s = s.strip(".,")
    if not s:
        return None
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        head, _, tail = s.rpartition(",")
        # virgule décimale si 1 ou 2 chiffres après la dernière virgule et une seule virgule
        if len(tail) in (1, 2) and s.count(",") == 1:
            s = head + "." + tail
        else:
            s = s.replace(",", "")
    elif "." in s:
        head, _, tail = s.rpartition(".")
        if len(tail) == 3 and s.count(".") >= 1 and len(head.replace(".", "")) <= 3 * (s.count(".") + 1):
            # '12.500' : séparateur de milliers (usage francophone)
            s = s.replace(".", "")
    try:
        v = float(s)
    except ValueError:
        return None
    return v if math.isfinite(v) else None


def parse_price(text) -> Optional[float]:
    """Premier montant d'un prix affiché ('4,500 FCFA - 6,000 FCFA' → 4500)."""
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text) if math.isfinite(float(text)) and float(text) > 0 else None
    m = _NUM.search(str(text))
    if not m:
        return None
    v = parse_number(m.group(0))
    return v if v and v > 0 else None


def parse_percent(text) -> Optional[float]:
    if text is None:
        return None
    m = re.search(r"(\d+(?:[.,]\d+)?)\s*%", str(text))
    return float(m.group(1).replace(",", ".")) if m else None


def slug_from_url(url: str) -> str:
    from urllib.parse import urlsplit

    p = urlsplit(url).path.strip("/")
    return p.split("/")[0] if p else ""


SKU_FROM_URL = re.compile(r"-(\d{5,})\.html")


def sku_from_url(url: str) -> Optional[str]:
    m = SKU_FROM_URL.search(url or "")
    return m.group(1) if m else None
