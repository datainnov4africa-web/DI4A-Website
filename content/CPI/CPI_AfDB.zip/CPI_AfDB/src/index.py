"""Étape 5 : indices de prix à partir des relevés en ligne.

Chaîne de calcul (manuel IPC FMI/OIT/Eurostat, chapitres sur les agrégats élémentaires et les
données web) :

1. **Prix mensuel** de chaque produit (SKU) : moyenne géométrique des relevés du mois.
2. **Agrégat élémentaire** = classe COICOP (ou groupe) du pays.
3. **Appariement** (matched model) : seuls les produits observés deux mois de suite entrent
   dans le relatif ; les entrées et sorties de catalogue sont comptées.
4. **Imputation** d'une absence passagère (≤ `max_gap` mois) par l'évolution moyenne des
   produits appariés de la même classe, pour que le retour du produit soit comparé au bon prix.
5. **Relatifs aberrants** (hors [1/3 ; 3]) écartés.
6. **Indice élémentaire chaîné** : Jevons (moyenne géométrique des relatifs, la formule
   recommandée), Dutot et Carli pour comparaison.
7. **Agrégation** : moyenne arithmétique pondérée (indice de Young) des agrégats, puis des
   divisions avec les pondérations de l'IPC national.
8. **Option multilatérale** : GEKS (bilatéraux Jevons ou Törnqvist) sur la fenêtre complète,
   transitif et sans dérive de chaînage.
"""
from __future__ import annotations

import logging
from typing import Optional

import numpy as np
import pandas as pd

from .config import COICOP_SHORT, division_of

log = logging.getLogger("jumia_cpi.index")

METHODS = ("jevons", "dutot", "carli")


# --------------------------------------------------------------------------------------
# Préparation
# --------------------------------------------------------------------------------------


def _geomean(s: pd.Series) -> float:
    s = s[s > 0]
    return float(np.exp(np.log(s).mean())) if len(s) else np.nan


def monthly_prices(obs: pd.DataFrame, price_concept: str = "posted", level: str = "coicop") -> pd.DataFrame:
    """Un prix par produit et par mois.

    price_concept = "posted" : prix affiché (promotions comprises) ;
                    "regular" : prix barré quand il existe (prix hors promotion)."""
    df = obs[(obs["price"] > 0) & obs[level].notna()].copy()
    df["period"] = pd.to_datetime(df["collect_date"]).dt.to_period("M").astype(str)
    df["promo"] = df["old_price"].notna() & (df["old_price"] > df["price"])
    df["p"] = df["price"] if price_concept == "posted" else np.where(df["promo"], df["old_price"], df["price"])
    df["ea"] = df[level]
    df["q_proxy"] = pd.to_numeric(df.get("n_ratings"), errors="coerce").fillna(0) + 1
    m = df.groupby(["ea", "sku", "period"], as_index=False).agg(
        p=("p", _geomean), promo=("promo", "mean"), n_obs=("p", "size"), q_proxy=("q_proxy", "max"))
    m["division"] = m["ea"].map(division_of)
    return m


# --------------------------------------------------------------------------------------
# Formules bilatérales
# --------------------------------------------------------------------------------------


def bilateral(pa: pd.Series, pb: pd.Series, method: str = "jevons", q: Optional[pd.Series] = None) -> float:
    if len(pa) == 0:
        return np.nan
    r = pb / pa
    if method == "jevons":
        return float(np.exp(np.log(r).mean()))
    if method == "dutot":
        return float(pb.sum() / pa.sum())
    if method == "carli":
        return float(r.mean())
    if method == "tornqvist":
        q = (q if q is not None else pd.Series(1.0, index=pa.index)).reindex(pa.index).fillna(1.0)
        sa = pa * q / (pa * q).sum()
        sb = pb * q / (pb * q).sum()
        return float(np.exp((0.5 * (sa + sb) * np.log(r)).sum()))
    raise ValueError(method)


# --------------------------------------------------------------------------------------
# Indices élémentaires chaînés
# --------------------------------------------------------------------------------------


def chained_elementary(m: pd.DataFrame, periods: list[str], methods=METHODS, bounds=(1 / 3, 3.0),
                       min_matched: int = 3, max_gap: int = 2, impute: bool = True) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Indices chaînés par agrégat élémentaire. Retourne (indices longs, diagnostics)."""
    lo, hi = bounds
    out, diag = [], []
    for ea, g in m.groupby("ea"):
        wide = g.pivot_table(index="sku", columns="period", values="p").reindex(columns=periods)
        filled = wide.copy()
        gap = pd.Series(0, index=wide.index)
        levels = {k: 100.0 for k in methods}
        first = wide.columns[wide.notna().any()].min() if wide.notna().any().any() else None
        for t, per in enumerate(periods):
            if t == 0 or first is None or per <= first:
                for k in methods:
                    out.append({"ea": ea, "period": per, "method": k, "index": 100.0 if first and per >= first else np.nan})
                continue
            a, b = filled[periods[t - 1]], wide[per]
            both = a.notna() & b.notna()
            r = b[both] / a[both]
            keep = r[(r >= lo) & (r <= hi)].index
            n = len(keep)
            enough = n >= min_matched
            rel_j = bilateral(a[keep], b[keep], "jevons") if enough else 1.0
            for k in methods:
                rel = bilateral(a[keep], b[keep], k) if enough else 1.0
                levels[k] *= rel
                out.append({"ea": ea, "period": per, "method": k, "index": levels[k]})
            imp = pd.Series(False, index=wide.index)
            if impute:
                missing = a.notna() & b.isna()
                ahead = wide[periods[t + 1:t + 1 + max_gap]].notna().any(axis=1) if t + 1 < len(periods) else pd.Series(False, index=wide.index)
                imp = missing & ahead & (gap < max_gap)
                filled.loc[imp, per] = a[imp] * rel_j
            gap = np.where(imp, gap + 1, 0)
            gap = pd.Series(gap, index=wide.index)
            logr = np.log(r.loc[keep]) if n else pd.Series(dtype=float)
            diag.append({"ea": ea, "period": per, "appariés": n, "entrées": int((b.notna() & a.isna()).sum()),
                         "sorties": int((a.notna() & b.isna() & ~imp).sum()), "imputés": int(imp.sum()),
                         "aberrants": int(len(r) - n), "relatif_jevons": rel_j, "suffisant": enough,
                         "dispersion_log": float(logr.std()) if n > 1 else np.nan,
                         "part_variations": float((logr.abs() > 1e-9).mean()) if n else np.nan})
    return pd.DataFrame(out), pd.DataFrame(diag)


def geks_elementary(m: pd.DataFrame, periods: list[str], bilateral_method: str = "jevons",
                    min_matched: int = 3) -> pd.DataFrame:
    """GEKS sur toute la fenêtre : P(0,t) = Π_l [P(0,l)·P(l,t)]^(1/T). Transitif par construction.

    Pour le Törnqvist, la « quantité » est approchée par le nombre d'avis (+1) : un indicateur de
    popularité, faute de quantités vendues. C'est une approximation documentée."""
    rows = []
    T = len(periods)
    for ea, g in m.groupby("ea"):
        wide = g.pivot_table(index="sku", columns="period", values="p").reindex(columns=periods)
        q = g.groupby("sku")["q_proxy"].max()
        P = np.full((T, T), np.nan)
        for s in range(T):
            P[s, s] = 1.0
            for t in range(s + 1, T):
                both = wide.iloc[:, s].notna() & wide.iloc[:, t].notna()
                if both.sum() >= min_matched:
                    v = bilateral(wide.iloc[:, s][both], wide.iloc[:, t][both], bilateral_method, q)
                    P[s, t], P[t, s] = v, 1 / v
        logs = []
        for t in range(T):
            terms = [np.log(P[0, l]) + np.log(P[l, t]) for l in range(T)
                     if np.isfinite(P[0, l]) and np.isfinite(P[l, t])]
            logs.append(np.mean(terms) if terms else np.nan)
        idx = np.exp(np.array(logs)) * 100
        for per, v in zip(periods, idx):
            rows.append({"ea": ea, "period": per, "method": f"geks-{bilateral_method}", "index": v})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------------------
# Agrégation
# --------------------------------------------------------------------------------------


def _chain_mean(wide: pd.DataFrame) -> pd.Series:
    """Indice chaîné : relatif = moyenne simple des relatifs des séries présentes deux mois de suite.
    Une série qui apparaît en cours de route n'introduit donc aucun saut artificiel."""
    level, out = None, []
    for t in range(len(wide)):
        if level is None:
            level = 100.0 if wide.iloc[t].notna().any() else None
            out.append(level if level is not None else np.nan)
            continue
        rel = (wide.iloc[t] / wide.iloc[t - 1]).dropna()
        level *= float(rel.mean()) if len(rel) else 1.0
        out.append(level)
    return pd.Series(out, index=wide.index)


def aggregate(ea_idx: pd.DataFrame, weights: dict, method: str = "jevons") -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Divisions (chaînage des agrégats élémentaires, poids égaux) puis ensemble (indice de Young
    chaîné avec les pondérations nationales).

    Retourne (indices par division + « Ensemble », poids utilisés, contributions mensuelles)."""
    d = ea_idx[ea_idx["method"] == method].copy()
    d["division"] = d["ea"].map(division_of)
    periods = sorted(d["period"].unique())
    div_levels = {}
    for div, g in d.groupby("division"):
        wide = g.pivot_table(index="period", columns="ea", values="index", dropna=False).reindex(periods)
        div_levels[div] = _chain_mean(wide)
    wide = pd.DataFrame(div_levels).reindex(periods)
    present = [c for c in wide.columns if wide[c].notna().any()]
    w = {k: float(weights.get(k, 0) or 0) for k in present}
    if sum(w.values()) <= 0:
        w = {k: 1.0 for k in present}
    covered = {k: v for k, v in w.items() if v > 0}
    total = sum(covered.values())
    wdf = pd.DataFrame({"division": list(covered), "poids_national": [weights.get(k, np.nan) for k in covered],
                        "poids_normalisé": [v / total for v in covered.values()]})

    level, all_levels, contrib = 100.0, [100.0], []
    for t in range(1, len(periods)):
        prev, cur = wide.iloc[t - 1], wide.iloc[t]
        ok = [k for k in covered if pd.notna(prev.get(k)) and pd.notna(cur.get(k))]
        denom = sum(covered[k] * prev[k] for k in ok)
        if not ok or denom <= 0:
            all_levels.append(level)
            continue
        rel_all = sum(covered[k] * cur[k] for k in ok) / denom
        for k in ok:
            contrib.append({"period": periods[t], "division": k, "libellé": f"{k} {COICOP_SHORT.get(k, '')}",
                            "contribution_pp": covered[k] * (cur[k] - prev[k]) / denom * 100})
        level *= rel_all
        all_levels.append(level)
    wide["Ensemble"] = all_levels
    long = wide.reset_index(names="period").melt(id_vars="period", var_name="série", value_name="index")
    long["libellé"] = long["série"].map(lambda s: "Ensemble" if s == "Ensemble" else f"{s} {COICOP_SHORT.get(s, '')}")
    return long, wdf, pd.DataFrame(contrib)


def rebase(long: pd.DataFrame, ref: str, col: str = "série") -> pd.DataFrame:
    out = long.copy()
    base = out[out["period"] == ref].set_index(col)["index"]
    out["index"] = out.apply(lambda r: r["index"] / base.get(r[col], np.nan) * 100 if r[col] in base else np.nan, axis=1)
    return out


def inflation(long: pd.DataFrame, col: str = "série") -> pd.DataFrame:
    out = long.sort_values([col, "period"]).copy()
    g = out.groupby(col)["index"]
    out["mensuelle_%"] = (g.pct_change(fill_method=None) * 100).round(2)
    out["annuelle_%"] = (g.pct_change(12, fill_method=None) * 100).round(2)
    return out


# --------------------------------------------------------------------------------------
# Indicateurs complémentaires
# --------------------------------------------------------------------------------------


def promo_stats(obs: pd.DataFrame) -> pd.DataFrame:
    df = obs[obs["price"] > 0].copy()
    df["period"] = pd.to_datetime(df["collect_date"]).dt.to_period("M").astype(str)
    df["promo"] = df["old_price"].notna() & (df["old_price"] > df["price"])
    df["profondeur"] = np.where(df["promo"], 1 - df["price"] / df["old_price"], np.nan)
    g = df.groupby(["division", "period"]).agg(observations=("sku", "size"), part_promo=("promo", "mean"),
                                                remise_moyenne=("profondeur", "mean")).reset_index()
    g["part_promo"] = (g["part_promo"] * 100).round(1)
    g["remise_moyenne"] = (g["remise_moyenne"] * 100).round(1)
    g["libellé"] = g["division"].map(lambda d: f"{d} {COICOP_SHORT.get(d, '')}")
    return g


def unit_price_dispersion(obs: pd.DataFrame) -> pd.DataFrame:
    """Coefficient de variation des prix au kilo/litre par classe et par mois."""
    if not {"unit", "unit_price", "coicop"} <= set(obs.columns):
        return pd.DataFrame()
    df = obs[obs["unit"].isin(["kg", "l"]) & (obs["unit_price"] > 0)].copy()
    df["period"] = pd.to_datetime(df["collect_date"]).dt.to_period("M").astype(str)
    g = df.groupby(["coicop", "unit", "period"])["unit_price"].agg(["count", "median", "mean", "std"]).reset_index()
    g["cv_%"] = (g["std"] / g["mean"] * 100).round(1)
    return g[g["count"] >= 3]


def compute_all(obs: pd.DataFrame, weights: dict, reference: str = "", min_matched: int = 3,
                bounds=(1 / 3, 3.0), max_gap: int = 2) -> dict:
    """Toute l'étape 5 en un appel : renvoie un dictionnaire de tables prêtes à tracer."""
    m = monthly_prices(obs, "posted")
    periods = sorted(m["period"].unique())
    if len(periods) < 2:
        return {"periods": periods, "ready": False, "monthly": m}
    ref = reference if reference in periods else periods[0]
    ea_idx, diag = chained_elementary(m, periods, bounds=bounds, min_matched=min_matched, max_gap=max_gap)
    geks_j = geks_elementary(m, periods, "jevons", min_matched)
    geks_t = geks_elementary(m, periods, "tornqvist", min_matched)
    all_ea = pd.concat([ea_idx, geks_j, geks_t], ignore_index=True)

    by_method, weights_used, contrib = {}, None, None
    for meth in ["jevons", "dutot", "carli", "geks-jevons", "geks-tornqvist"]:
        long, wdf, ctb = aggregate(all_ea, weights, meth)
        by_method[meth] = long
        if meth == "jevons":
            weights_used, contrib = wdf, ctb
    jev = by_method["jevons"]

    # Prix hors promotion : effet des promotions sur l'indice
    m_reg = monthly_prices(obs, "regular")
    reg_idx, _ = chained_elementary(m_reg, periods, methods=("jevons",), bounds=bounds,
                                    min_matched=min_matched, max_gap=max_gap)
    reg_long, _, _ = aggregate(reg_idx, weights, "jevons")

    comp = []
    for meth, long in by_method.items():
        e = rebase(long, ref)
        e = e[e["série"] == "Ensemble"].assign(méthode=meth)
        comp.append(e)
    e_reg = rebase(reg_long, ref)
    comp.append(e_reg[e_reg["série"] == "Ensemble"].assign(méthode="jevons (prix hors promo)"))

    main = inflation(rebase(jev, ref))
    return {
        # `weights` est la pondération **demandée** ; `weights_used` celle que
        # l'agrégation a pu appliquer. L'écart entre les deux est ce qui permet
        # de dire sur combien de divisions l'indice d'ensemble repose vraiment.
        "ready": True, "periods": periods, "reference": ref, "monthly": m, "ea_indices": all_ea,
        "diagnostics": diag, "indices": main, "weights": dict(weights),
        # Le mois de base demandé, pour qu'on puisse dire qu'il n'a pas été
        # retenu plutôt que de rebaser en silence sur un autre.
        "reference_demandee": reference,
        "weights_used": weights_used, "contributions": contrib,
        "method_comparison": pd.concat(comp, ignore_index=True), "promo": promo_stats(obs),
        "dispersion": unit_price_dispersion(obs),
    }
