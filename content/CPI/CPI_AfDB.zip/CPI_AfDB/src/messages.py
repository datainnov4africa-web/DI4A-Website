"""Interprétations générées à partir des données et messages clés avec niveau de confiance.

Chaque fonction lit des tableaux produits par le pipeline et renvoie des phrases : rien n'est
écrit à l'avance. Les niveaux de confiance suivent des règles explicites (nombre de produits,
de mois, couverture des pondérations, accord des classificateurs, accord avec l'IPC officiel).
"""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd

from .config import COICOP_SHORT


def _fmt(x, d=1, signed=False) -> str:
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "n.d."
    s = f"{x:+.{d}f}" if signed else f"{x:.{d}f}"
    return s.replace(".", ",")


def _int(n) -> str:
    return f"{int(n):,}".replace(",", " ")


# --------------------------------------------------------------------------------------
# Interprétations par étape
# --------------------------------------------------------------------------------------


def interpret_discovery(reg: pd.DataFrame, journal: pd.DataFrame) -> list[str]:
    n = len(reg)
    cited = int(reg["cité_par_jumia"].sum())
    hist = reg[reg["status_hint"].isin(["exited", "historical"])]
    new = reg[reg["status_hint"] == "discovered"]
    out = [f"Le registre compte **{n} domaines** ; **{cited}** sont cités sur les pages publiques de Jumia "
           f"consultées ({', '.join(journal['page']) if len(journal) else 'aucune page consultée'})."]
    if len(hist):
        out.append(f"{len(hist)} domaines correspondent à des pays quittés ou suspendus "
                   f"({', '.join(hist['country_fr'])}) : ils restent dans le registre pour documenter leur statut.")
    if len(new):
        out.append(f"⚠️ {len(new)} domaine(s) absent(s) du registre ont été trouvés : {', '.join(new['domain'])}. "
                   "Complétez leur devise et leur langue dans `config.py` avant de les collecter.")
    else:
        out.append("Aucun domaine inconnu n'a été trouvé : le registre est à jour par rapport aux pages consultées.")
    return out


def interpret_validation(val: pd.DataFrame) -> list[str]:
    counts = val["verdict"].value_counts()
    act = val[val["verdict"] == "active"]
    out = [f"**{counts.get('active', 0)} sites actifs**, {counts.get('restricted', 0)} restreints et "
           f"{counts.get('closed', 0)} fermés ou redirigés."]
    if len(act) and act["temps_ms"].notna().any():
        slow = act.sort_values("temps_ms").iloc[-1]
        out.append(f"Temps de réponse médian des sites actifs : {_int(act['temps_ms'].median())} ms "
                   f"(le plus lent : {slow['domain']}, {_int(slow['temps_ms'])} ms).")
    mism = val[(val["status_hint"] == "active") & (val["verdict"] != "active")]
    if len(mism):
        out.append("Écarts avec le statut annoncé par Jumia : "
                   + "; ".join(f"{r.domain} → {r.raison}" for r in mism.itertuples())
                   + ". Un site « restreint » ne doit pas être contourné : demandez un accès à Jumia.")
    closed_ok = val[(val["status_hint"].isin(["exited", "historical"])) & (val["verdict"] == "closed")]
    if len(closed_ok):
        out.append(f"Les retraits annoncés sont confirmés pour {len(closed_ok)} domaine(s).")
    return out


def interpret_collection(products: pd.DataFrame, pages: pd.DataFrame, stats: dict, panel: pd.DataFrame) -> list[str]:
    out = []
    n_dates = panel["collect_date"].nunique() if len(panel) else 0
    out.append(f"Relevé du jour : **{_int(len(products))} produits** distincts dans "
               f"{products['category_slug'].nunique() if len(products) else 0} catégories, "
               f"pour {_int(stats.get('requêtes', 0))} requêtes ({_int(stats.get('cache', 0))} servies par le cache, "
               f"{_int(stats.get('reprises', 0))} reprises après erreur).")
    if len(products):
        meth = products["parse_method"].value_counts(normalize=True).mul(100).round(0)
        out.append("Méthodes d'extraction : " + ", ".join(f"{k} {v:.0f} %" for k, v in meth.items()) + ".")
        promo = (products["old_price"].notna() & (products["old_price"] > products["price"])).mean() * 100
        out.append(f"{_fmt(promo, 0)} % des produits affichent un prix barré : un indice calculé sur les prix "
                   "affichés intègre donc les promotions (voir l'étape 5).")
    blocked = pages[pages["statut"].str.contains("robots", na=False)] if len(pages) else pages
    if len(blocked):
        out.append(f"{len(blocked)} page(s) ignorée(s) car interdites par robots.txt : la collecte s'est arrêtée comme prévu.")
    out.append(f"Le panel contient **{n_dates} relevé(s)** datés ; il faut au moins deux mois distincts pour calculer "
               "une variation de prix, et treize pour un glissement annuel.")
    return out


def interpret_classification(enr: pd.DataFrame, report: Optional[pd.DataFrame], usage: pd.DataFrame,
                             synthetic: bool) -> list[str]:
    src = enr["coicop_source"].value_counts(normalize=True).mul(100)
    out = ["Origine du code COICOP retenu : " + ", ".join(f"{k} {v:.0f} %" for k, v in src.items()) + "."]
    both = enr[enr["coicop_llm"].notna() & enr["coicop_rules"].notna()]
    if len(both):
        agree = (both["coicop_llm"].str[:2] == both["coicop_rules"].str[:2]).mean() * 100
        out.append(f"Le LLM et les règles s'accordent sur la division pour {_fmt(agree, 0)} % des produits ; "
                   "les désaccords sont les premiers à faire vérifier par un humain.")
    unit = enr["unit"].isin(["kg", "l"]).mean() * 100
    out.append(f"{_fmt(unit, 0)} % des produits ont un contenu en kg ou en litres, donc un prix unitaire comparable.")
    dup = (enr.get("cluster_size", pd.Series(dtype=int)) > 1).sum()
    if dup:
        out.append(f"{_int(dup)} annonces appartiennent à des groupes de doublons (même article, vendeurs différents).")
    if report is not None and len(report):
        best = report.sort_values("accord_division", ascending=False).iloc[0]
        out.append(f"Contre l'annotation de référence ({_int(best['n'])} produits), l'accord par division atteint "
                   f"{_fmt(best['accord_division'], 1)} % (kappa {_fmt(best['kappa_division'], 2)}).")
        if synthetic:
            out.append("⚠️ En mode test, les règles ont été écrites en connaissant le catalogue synthétique : cet accord "
                       "est optimiste. Sur un vrai site, seule une annotation humaine mesure la qualité.")
    if len(usage):
        tok = int(usage["jetons_entrée"].sum() + usage["jetons_sortie"].sum())
        prov = ", ".join(usage["fournisseur"].unique())
        out.append(f"Appels LLM : {_int(usage['appels'].sum())} ({prov}), {_int(tok)} jetons consommés.")
    return out


def interpret_index(res: dict) -> list[str]:
    ind = res["indices"]
    e = ind[ind["série"] == "Ensemble"].sort_values("period")
    last = e.iloc[-1]
    # « Jumia » était exact quand une seule source nourrissait l'indice. Depuis
    # que les relevés institutionnels et les loyers l'alimentent aussi, le mot
    # attribue à une place de marché des prix qu'elle n'a pas publiés.
    out = [f"Indice d'ensemble en {last['period']} : **{_fmt(last['index'], 1)}** "
           f"(base 100 = {res['reference']}), soit {_fmt(last['index'] - 100, 1, True)} % depuis la base."]
    if pd.notna(last.get("mensuelle_%")):
        out.append(f"Variation sur le dernier mois : {_fmt(last['mensuelle_%'], 2, True)} %.")
    if pd.notna(last.get("annuelle_%")):
        out.append(f"Glissement annuel : **{_fmt(last['annuelle_%'], 1, True)} %**.")
    divs = ind[(ind["série"] != "Ensemble") & (ind["period"] == last["period"])].sort_values("index")
    # Une division sans indice figure dans la table avec une case vide, et
    # `sort_values` range les cases vides en dernier : sans ce filtre, la
    # « plus forte hausse » désignait une division qui n'a pas d'indice du
    # tout, avec « n.d. » pour valeur.
    divs = divs[divs["index"].notna()]
    if len(divs) >= 2:
        hi, lo = divs.iloc[-1], divs.iloc[0]
        out.append(f"La plus forte hausse depuis la base concerne {hi['libellé']} ({_fmt(hi['index'] - 100, 1, True)} %), "
                   f"la plus faible {lo['libellé']} ({_fmt(lo['index'] - 100, 1, True)} %).")
    c = res["contributions"]
    if len(c):
        tot = c.groupby("libellé")["contribution_pp"].sum().sort_values()
        out.append(f"Sur toute la période, {tot.index[-1]} contribue le plus à la hausse ({_fmt(tot.iloc[-1], 2, True)} pp).")
    mc = res["method_comparison"]
    fin = mc[mc["period"] == last["period"]].set_index("méthode")["index"]
    if {"carli", "jevons"} <= set(fin.index):
        out.append(f"Le Carli chaîné finit à {_fmt(fin['carli'], 1)} contre {_fmt(fin['jevons'], 1)} pour le Jevons : "
                   "l'écart illustre la dérive à la hausse du Carli quand les prix montent et descendent (promotions), "
                   "raison pour laquelle le manuel IPC le déconseille.")
    if "geks-tornqvist" in fin.index:
        out.append(f"Le GEKS-Törnqvist (multilatéral, sans dérive de chaînage) donne {_fmt(fin['geks-tornqvist'], 1)}.")
    if "jevons (prix hors promo)" in fin.index:
        gap = fin["jevons"] - fin["jevons (prix hors promo)"]
        out.append(f"Écart entre prix affichés et prix hors promotion : {_fmt(gap, 2, True)} point(s).")
    d = res["diagnostics"]
    weak = d[~d["suffisant"]]
    if len(weak):
        out.append(f"{len(weak)} couple(s) classe-mois ont moins de produits appariés que le minimum : l'indice y est "
                   "reconduit, ces classes sont fragiles.")
    # Sur quoi l'indice d'ensemble repose-t-il **réellement** ? Une division
    # peut porter des relevés sans porter d'indice : il lui faut des produits
    # appariés d'un mois sur l'autre, et un seul mois de collecte n'en donne
    # aucun. Quand il ne reste qu'une division, « indice d'ensemble » est un
    # titre trompeur — au Ghana et au Nigeria, il ne décrit que les produits
    # alimentaires. Le dire est le minimum ; l'ignorer serait publier un indice
    # alimentaire sous le nom d'un indice général.
    # Un mois de base absent des relevés est remplacé sans bruit par le
    # premier mois disponible. Le niveau de l'indice en dépend entièrement :
    # le lecteur doit savoir sur quoi il est basé.
    voulue = (res.get("reference_demandee") or "").strip()
    if voulue and voulue != res["reference"]:
        out.append(
            f"Le mois de base demandé, {voulue}, n'existe pas dans ces relevés : "
            f"l'indice est basé sur {res['reference']}, le premier mois disponible.")

    demandes = res.get("weights") or {}
    if demandes:
        portantes = set(divs["série"].astype(str)) if len(divs) else set()
        absentes = sorted(set(map(str, demandes)) - portantes)
        if absentes:
            total = sum(demandes.values()) or 1
            part = sum(v for k, v in demandes.items()
                       if str(k) in portantes) / total
            out.append(
                f"**L'indice d'ensemble ne repose que sur {len(portantes)} division(s)** "
                f"sur les {len(demandes)} pondérées : {', '.join(absentes)} n'ont pas "
                "assez de produits appariés d'un mois sur l'autre pour porter un indice. "
                f"Il ne couvre donc que {part:.0%} du panier pondéré"
                + (", et ce qu'il mesure n'est pas l'ensemble de la consommation."
                   if len(portantes) <= 1 else "."))
    return out


def interpret_comparison(stats: dict, source: str) -> list[str]:
    if not stats or stats.get("n", 0) < 3:
        return [stats.get("message", "Pas de comparaison possible.") if stats else "Pas d'IPC officiel disponible."]
    out = [f"Sur {stats['n']} mois communs ({source}), l'indice Jumia varie de {_fmt(stats['variation_jumia_%'], 1, True)} % "
           f"contre {_fmt(stats['variation_officielle_%'], 1, True)} % pour l'IPC officiel."]
    if stats.get("corr_mensuelle") is not None:
        out.append(f"Corrélation des variations mensuelles : {_fmt(stats['corr_mensuelle'], 2)} ; même sens de variation "
                   f"{_fmt(stats['même_signe_%'], 0)} % des mois ; écart absolu moyen {_fmt(stats['écart_absolu_moyen_pp'], 2)} pp.")
    if stats.get("meilleur_décalage") not in (None, 0):
        k = stats["meilleur_décalage"]
        out.append(f"La corrélation est la plus forte avec un décalage de {abs(k)} mois "
                   f"({'Jumia en avance' if k > 0 else 'Jumia en retard'}) : à confirmer sur une série plus longue.")
    return out


# --------------------------------------------------------------------------------------
# Messages clés
# --------------------------------------------------------------------------------------


def key_messages(ctx: dict) -> list[dict]:
    """ctx : n_products, n_periods, coverage_pct, weights_source, agreement_div, comparison,
    last_yoy, last_mom, top_contrib, promo_gap, carli_gap, synthetic."""
    msgs = []
    n, T = ctx.get("n_products", 0), ctx.get("n_periods", 0)

    if T < 2:
        msgs.append({"titre": "Panel en construction", "confiance": "faible",
                     "texte": f"{_int(n)} produits relevés sur {T} période : relancez la collecte chaque mois pour obtenir "
                              "des variations de prix.",
                     "motif": "Un seul relevé ne permet aucune comparaison temporelle."})
        return msgs

    conf = "élevée" if (n >= 1000 and T >= 13 and ctx.get("weights_source") == "national") else \
        "moyenne" if (n >= 200 and T >= 6) else "faible"
    reasons = [f"{_int(n)} produits", f"{T} mois", f"pondérations : {ctx.get('weights_source')}"]
    infl = ctx.get("last_yoy")
    txt = (f"Glissement annuel de {_fmt(infl, 1, True)} % sur les prix en ligne." if infl is not None
           else f"Hausse cumulée de {_fmt(ctx.get('cum'), 1, True)} % depuis la base.")
    msgs.append({"titre": "Inflation mesurée en ligne", "texte": txt, "confiance": conf,
                 "motif": ", ".join(reasons)})

    if ctx.get("top_contrib"):
        lab, val = ctx["top_contrib"]
        msgs.append({"titre": "Principal moteur", "confiance": conf,
                     "texte": f"{lab} explique {_fmt(val, 2, True)} point(s) de la hausse cumulée.",
                     "motif": "Contributions exactes d'un indice de Young chaîné ; dépend des pondérations."})

    cov = ctx.get("coverage_pct")
    if cov is not None:
        c = "élevée" if cov >= 60 else "moyenne" if cov >= 35 else "faible"
        msgs.append({"titre": "Représentativité", "confiance": c,
                     "texte": f"Les divisions observées couvrent {_fmt(cov, 0)} % des pondérations de l'IPC national ; "
                              "logement, transports publics, éducation et services restent hors champ.",
                     "motif": "Le commerce en ligne vend surtout des biens, pas des services."})

    cmp = ctx.get("comparison") or {}
    if cmp.get("corr_mensuelle") is not None:
        r = cmp["corr_mensuelle"]
        c = "élevée" if r >= 0.6 and cmp["n"] >= 12 else "moyenne" if r >= 0.3 else "faible"
        msgs.append({"titre": "Cohérence avec l'IPC officiel", "confiance": c,
                     "texte": f"Corrélation mensuelle de {_fmt(r, 2)} avec l'IPC officiel sur {cmp['n']} mois ; écart cumulé "
                              f"{_fmt(cmp['variation_jumia_%'] - cmp['variation_officielle_%'], 1, True)} point(s).",
                     "motif": "Mesure la capacité de l'indice en ligne à suivre (ou devancer) l'IPC officiel."})

    if ctx.get("agreement_div") is not None:
        a = ctx["agreement_div"]
        msgs.append({"titre": "Qualité de la classification", "confiance": "élevée" if a >= 90 else "moyenne" if a >= 75 else "faible",
                     "texte": f"{_fmt(a, 0)} % d'accord par division avec l'annotation de référence.",
                     "motif": "Un produit mal classé fausse l'agrégat élémentaire dans lequel il tombe."
                              + (" Mode test : accord optimiste." if ctx.get("synthetic") else "")})

    if ctx.get("carli_gap") is not None:
        msgs.append({"titre": "Choix de formule", "confiance": "élevée",
                     "texte": f"Le Carli chaîné s'écarte de {_fmt(ctx['carli_gap'], 1, True)} point(s) du Jevons : la formule "
                              "Jevons (ou un GEKS) est retenue, conformément au manuel IPC.",
                     "motif": "Résultat mécanique, indépendant de la représentativité."})

    if ctx.get("weights_source") != "national":
        msgs.append({"titre": "Pondérations à remplacer", "confiance": "faible",
                     "texte": "Les pondérations utilisées ne sont pas celles de l'IPC national : l'indice d'ensemble est "
                              "illustratif. Renseignez WEIGHTS_CSV.",
                     "motif": "Les poids déterminent l'indice d'ensemble et les contributions."})
    if ctx.get("synthetic"):
        for m in msgs:
            m["motif"] += " — données synthétiques (mode test)."
    return msgs
