"""Couche LLM unique pour Ollama (local), Groq et Gemini, avec repli automatique.

* Chaque fournisseur est appelé par son API REST (pas de SDK à installer).
* Les réponses sont demandées en JSON, puis validées par un schéma Pydantic.
* Une réponse invalide ou une erreur fait passer au fournisseur suivant ; en dernier recours,
  le fournisseur « rules » (règles déterministes, sans réseau) garantit un résultat.
* Toutes les réponses sont mises en cache (SQLite) : relancer le notebook ne coûte rien.
* Les jetons consommés sont comptés ; le coût est calculé si vous renseignez les tarifs
  dans `config.LLM_PRICING`.
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
import sqlite3
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import pandas as pd
from pydantic import BaseModel, ValidationError

from .config import LLM_DEFAULT_MODELS, LLM_PRICING

log = logging.getLogger("jumia_cpi.llm")


class LLMError(Exception):
    """args : (message, statut HTTP ou None, délai Retry-After en secondes ou None)."""


def _retry_after(r) -> Optional[float]:
    """Délai demandé par le serveur sur un 429, s'il le dit ; None sinon."""
    headers = getattr(r, "headers", None) or {}
    try:
        valeur = headers.get("Retry-After") or headers.get("retry-after")
    except AttributeError:
        return None
    try:
        return float(valeur) if valeur is not None else None
    except (TypeError, ValueError):
        return None


def _api_detail(r) -> str:
    """Message d'erreur renvoyé par l'API, s'il y en a un ; sinon chaîne vide.

    « HTTP 404 » ne dit rien ; « models/gemini-2.5-flash is not found for API
    version v1beta » dit tout. Les trois fournisseurs renvoient ce message dans
    un objet `error`."""
    try:
        corps = r.json()
    except Exception:
        return ""
    err = corps.get("error") if isinstance(corps, dict) else None
    msg = (err.get("message") or err.get("status") or "") if isinstance(err, dict) else (err or "")
    return re.sub(r"\s+", " ", str(msg)).strip()[:160]


def _http_error(prefix: str, r) -> LLMError:
    detail = _api_detail(r)
    texte = f"{prefix} HTTP {r.status_code}" + (f" ({detail})" if detail else "")
    return LLMError(texte, r.status_code, _retry_after(r))


@dataclass
class LLMResult:
    text: str
    provider: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    latency: float = 0.0
    cached: bool = False


def _http():
    import requests

    return requests


def strip_fences(text: str) -> str:
    t = text.strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", t, re.S)
    if m:
        t = m.group(1).strip()
    if not t.startswith(("{", "[")):
        i = min([x for x in (t.find("{"), t.find("[")) if x >= 0], default=-1)
        if i >= 0:
            t = t[i:]
    return t


# --------------------------------------------------------------------------------------
# Fournisseurs
# --------------------------------------------------------------------------------------


class Provider:
    name = "base"

    def __init__(self, http=None, timeout: float = 60.0):
        self.http = http or _http()
        self.timeout = timeout

    def available(self) -> tuple[bool, str]:
        raise NotImplementedError

    def list_models(self) -> list[str]:
        return []

    def complete(self, system: str, user: str, model: str) -> LLMResult:
        raise NotImplementedError

    def resolve_model(self, requested: str = "") -> str:
        if requested:
            return requested
        prefs = LLM_DEFAULT_MODELS.get(self.name, [])
        try:
            listed = self.list_models()
        except Exception:
            listed = []
        for m in prefs:
            if not listed or m in listed:
                return m
        return listed[0] if listed else (prefs[0] if prefs else "")


class OllamaProvider(Provider):
    name = "ollama"

    def __init__(self, host: str = "http://localhost:11434", **kw):
        super().__init__(**kw)
        self.host = host.rstrip("/")

    def list_models(self) -> list[str]:
        r = self.http.get(f"{self.host}/api/tags", timeout=5)
        r.raise_for_status()
        return [m["name"] for m in r.json().get("models", [])]

    def available(self) -> tuple[bool, str]:
        try:
            models = self.list_models()
        except Exception:
            return False, f"serveur Ollama introuvable sur {self.host}"
        return (True, f"{len(models)} modèle(s) local(aux)") if models else (False, "aucun modèle téléchargé (ollama pull …)")

    def resolve_model(self, requested: str = "") -> str:
        listed = []
        try:
            listed = self.list_models()
        except Exception:
            pass
        if requested:
            return requested
        for m in LLM_DEFAULT_MODELS["ollama"]:
            if m in listed:
                return m
        return listed[0] if listed else LLM_DEFAULT_MODELS["ollama"][0]

    def complete(self, system, user, model) -> LLMResult:
        t0 = time.perf_counter()
        r = self.http.post(f"{self.host}/api/chat", timeout=self.timeout * 3, json={
            "model": model, "stream": False, "format": "json", "options": {"temperature": 0},
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]})
        if r.status_code >= 400:
            raise _http_error("Ollama", r)
        d = r.json()
        return LLMResult(d["message"]["content"], self.name, model, d.get("prompt_eval_count", 0) or 0,
                         d.get("eval_count", 0) or 0, time.perf_counter() - t0)


class GroqProvider(Provider):
    name = "groq"
    base = "https://api.groq.com/openai/v1"

    def __init__(self, api_key: Optional[str], **kw):
        super().__init__(**kw)
        self.api_key = api_key

    def _h(self):
        return {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

    def available(self) -> tuple[bool, str]:
        return (True, "clé API trouvée") if self.api_key else (False, "clé GROQ_API_KEY absente")

    def list_models(self) -> list[str]:
        r = self.http.get(f"{self.base}/models", headers=self._h(), timeout=10)
        r.raise_for_status()
        ids = [m["id"] for m in r.json().get("data", [])]
        # Groq liste aussi ses modèles de transcription (whisper), de synthèse
        # vocale (orpheus, tts) et de filtrage (guard) : aucun ne répond à
        # /chat/completions en JSON. Les proposer ferait échouer l'essai.
        exclus = ("whisper", "guard", "orpheus", "tts")
        return [i for i in ids if not any(x in i.lower() for x in exclus)]

    def complete(self, system, user, model) -> LLMResult:
        t0 = time.perf_counter()
        r = self.http.post(f"{self.base}/chat/completions", headers=self._h(), timeout=self.timeout, json={
            "model": model, "temperature": 0, "response_format": {"type": "json_object"},
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]})
        if r.status_code >= 400:
            raise _http_error("Groq", r)
        d = r.json()
        u = d.get("usage") or {}
        return LLMResult(d["choices"][0]["message"]["content"], self.name, model, u.get("prompt_tokens", 0),
                         u.get("completion_tokens", 0), time.perf_counter() - t0)


class GeminiProvider(Provider):
    name = "gemini"
    base = "https://generativelanguage.googleapis.com/v1beta"

    def __init__(self, api_key: Optional[str], **kw):
        super().__init__(**kw)
        self.api_key = api_key

    def _h(self):
        return {"x-goog-api-key": self.api_key or "", "Content-Type": "application/json"}

    def available(self) -> tuple[bool, str]:
        return (True, "clé API trouvée") if self.api_key else (False, "clé GEMINI_API_KEY absente")

    def list_models(self) -> list[str]:
        r = self.http.get(f"{self.base}/models", headers=self._h(), params={"pageSize": 200}, timeout=10)
        r.raise_for_status()
        return [m["name"].removeprefix("models/") for m in r.json().get("models", [])
                if "generateContent" in m.get("supportedGenerationMethods", [])]

    def complete(self, system, user, model) -> LLMResult:
        t0 = time.perf_counter()
        r = self.http.post(f"{self.base}/models/{model}:generateContent", headers=self._h(), timeout=self.timeout,
                           json={"systemInstruction": {"parts": [{"text": system}]},
                                 "contents": [{"role": "user", "parts": [{"text": user}]}],
                                 "generationConfig": {"temperature": 0, "responseMimeType": "application/json"}})
        if r.status_code >= 400:
            raise _http_error("Gemini", r)
        d = r.json()
        parts = d["candidates"][0]["content"]["parts"]
        u = d.get("usageMetadata") or {}
        return LLMResult("".join(p.get("text", "") for p in parts), self.name, model,
                         u.get("promptTokenCount", 0), u.get("candidatesTokenCount", 0), time.perf_counter() - t0)


class RulesProvider(Provider):
    """Dernier recours sans réseau : délègue à une fonction déterministe (règles du projet).

    `handler(system, user) -> str` reçoit la même consigne qu'un LLM et renvoie du JSON."""

    name = "rules"

    def __init__(self, handler: Optional[Callable[[str, str], str]] = None):
        self.handler = handler

    def available(self):
        return (True, "règles déterministes (hors ligne)") if self.handler else (False, "aucune règle fournie")

    def resolve_model(self, requested=""):
        return "règles-v1"

    def complete(self, system, user, model) -> LLMResult:
        if not self.handler:
            raise LLMError("pas de règles")
        return LLMResult(self.handler(system, user), self.name, model, 0, 0, 0.0)


# --------------------------------------------------------------------------------------
# Client
# --------------------------------------------------------------------------------------


class LLMClient:
    def __init__(self, preferred: str = "groq", model: str = "", keys: Optional[dict] = None,
                 ollama_host: str = "http://localhost:11434", cache_path: Optional[Path] = None,
                 rules_handler: Optional[Callable[[str, str], str]] = None, http=None, fallback: bool = True,
                 max_retries: int = 4, sleep=time.sleep, max_wait: float = 60.0,
                 models: Optional[dict] = None):
        keys = keys or {}
        self.sleep = sleep
        self.max_retries = max_retries
        self.max_wait = max_wait            # au-delà, un 429 vaut « quota atteint », pas « réessayer »
        all_providers = {
            "ollama": OllamaProvider(ollama_host, http=http),
            "groq": GroqProvider(keys.get("groq"), http=http),
            "gemini": GeminiProvider(keys.get("gemini"), http=http),
        }
        order = [preferred] if preferred in all_providers else []
        if fallback or not order:
            order += [p for p in ("groq", "gemini", "ollama") if p not in order]
        self.providers: list[Provider] = [all_providers[p] for p in order]
        self.providers.append(RulesProvider(rules_handler))
        self.preferred = preferred
        self.requested_model = model
        # Un modèle demandé par fournisseur ("" = choix automatique). `model`
        # seul, l'ancienne forme, vaut pour le fournisseur préféré.
        self.requested_models: dict[str, str] = {k: str(v).strip() for k, v in (models or {}).items()
                                                 if str(v or "").strip()}
        if model and preferred in all_providers:
            self.requested_models.setdefault(preferred, model)
        # Ce que le carnet affiche sur le choix des modèles : demandé mais absent
        # de la liste, remplacé par tel autre…
        self.model_notes: dict[str, str] = {}
        # Fournisseurs écartés par l'essai de démarrage (`probe`) : modèle
        # introuvable, clé refusée, réponse non JSON — avec la raison.
        self.rejected: dict[str, str] = {}
        self.usage: list[dict] = []
        self._models: dict[str, str] = {}
        self._status: dict[str, tuple[bool, str]] = {}
        # Fournisseurs mis de côté pour le reste de la session : quota atteint
        # (HTTP 429 malgré les reprises). Sans cela, chaque lot ré-essayait le
        # fournisseur épuisé — trois appels et douze secondes perdus par lot,
        # pour finir de toute façon chez le suivant.
        self.exhausted: dict[str, str] = {}
        self.cache_path = cache_path
        if cache_path:
            Path(cache_path).parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(cache_path) as con:
                con.execute("CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, provider TEXT, model TEXT, "
                            "response TEXT, created REAL)")

    # état ------------------------------------------------------------------------------
    def _available(self, p: Provider, cached: bool = False) -> tuple[bool, str]:
        """Disponibilité d'un fournisseur, quota épuisé compris."""
        if p.name in self.exhausted:
            return False, self.exhausted[p.name]
        if p.name in self.rejected:
            return False, self.rejected[p.name]
        if cached and p.name in self._status:
            return self._status[p.name]
        ok, why = p.available()
        self._status[p.name] = (ok, why)
        return ok, why

    def _next_after(self, p: Provider) -> str:
        """Nom du prochain fournisseur encore utilisable après `p`."""
        suivants = self.providers[self.providers.index(p) + 1:]
        for q in suivants:
            if self._available(q, cached=True)[0]:
                return q.name
        return "aucun"

    def status(self) -> pd.DataFrame:
        rows = []
        for p in self.providers:
            ok, why = self._available(p)
            model = ""
            if ok:
                model = self._model_for(p)
            rows.append({"fournisseur": p.name, "disponible": "✅" if ok else "—", "modèle": model, "détail": why,
                         "rang": len(rows) + 1})
        return pd.DataFrame(rows)

    def _model_for(self, p: Provider) -> str:
        if p.name not in self._models:
            req = self.requested_models.get(p.name, "")
            if req:
                # Le modèle demandé est confronté à la liste du fournisseur,
                # quand elle est consultable. Un nom retiré du catalogue ne
                # fait pas échouer la session : on le remplace et on le dit.
                try:
                    listes = p.list_models()
                except Exception:
                    listes = []
                if listes and req not in listes:
                    auto = p.resolve_model("")
                    self.model_notes[p.name] = (
                        "le modèle demandé « {} » n'est pas dans la liste de {} ({} modèle(s) "
                        "proposés) : « {} » est employé à la place".format(req, p.name, len(listes), auto))
                    log.warning("LLM %s : %s", p.name, self.model_notes[p.name])
                    req = ""
            self._models[p.name] = p.resolve_model(req)
        return self._models[p.name]

    def _provider(self, name: str) -> Optional[Provider]:
        return next((q for q in self.providers if q.name == name), None)

    def is_available(self, name: str) -> bool:
        p = self._provider(name)
        return bool(p) and self._available(p, cached=True)[0]

    def model_of(self, name: str) -> str:
        p = self._provider(name)
        return self._model_for(p) if p else ""

    @property
    def active_provider(self) -> str:
        for p in self.providers:
            if self._available(p, cached=True)[0]:
                return p.name
        return "aucun"

    # essai de démarrage ----------------------------------------------------------------
    PROBE_SYSTEM = "Tu réponds uniquement par un objet JSON, sans texte autour."
    PROBE_USER = 'Réponds exactement par l\'objet JSON {"ok": true}.'
    # Ce qu'un catalogue annonce et qui n'est pas un modèle de dialogue texte,
    # ou qui change trop vite pour un menu : synthèse vocale, image, vidéo,
    # agents, plongements, versions d'essai.
    HORS_MENU = ("tts", "image", "imagen", "veo", "computer-use", "deep-research", "antigravity",
                 "embedding", "aqa", "audio", "live", "robotics", "-exp", "preview", "guard", "whisper",
                 "orpheus")

    def set_model(self, name: str, model: str) -> None:
        """Impose le modèle d'un fournisseur (choisi dans un menu après essai)."""
        if model:
            self._models[name] = model
            self.rejected.pop(name, None)
            self.model_notes.pop(name, None)

    def _essayer(self, p: Provider, model: str) -> tuple[bool, str, Optional[int]]:
        """Un appel d'essai : (ok, détail, statut HTTP)."""
        t0 = time.perf_counter()
        try:
            res = p.complete(self.PROBE_SYSTEM, self.PROBE_USER, model)
        except Exception as e:
            status = e.args[1] if len(e.args) > 1 else None
            return False, (str(e.args[0]) if e.args else type(e).__name__), status
        try:
            json.loads(strip_fences(res.text))
        except json.JSONDecodeError:
            return False, "ne répond pas en JSON", None
        return True, "répond en JSON en {:.1f} s".format(time.perf_counter() - t0), None

    def candidates(self, name: str, max_probe: int = 8) -> pd.DataFrame:
        """Les modèles d'un fournisseur qui répondent vraiment avec la clé présente.

        Le catalogue est interrogé, filtré (dialogue texte, versions stables),
        ordonné (modèle demandé, préférences du projet, puis le reste), et
        chaque candidat reçoit un appel d'essai, jusqu'à `max_probe`. Un
        catalogue annonce aussi des modèles fermés aux nouveaux comptes ou
        retirés : seule la colonne « essai » fait foi. Un 429 arrête l'essai,
        le quota vaut pour tous les modèles du fournisseur."""
        colonnes = ["modèle", "essai", "détail"]
        p = self._provider(name)
        if p is None:
            return pd.DataFrame(columns=colonnes)
        ok, why = self._available(p, cached=True)
        if not ok:
            return pd.DataFrame([{"modèle": "", "essai": "—", "détail": why}], columns=colonnes)
        try:
            listes = p.list_models()
        except Exception as e:
            listes = []
            log.warning("LLM %s : catalogue illisible (%s) — essai des modèles par défaut", name, e)
        prefs = LLM_DEFAULT_MODELS.get(name, [])
        demande = self.requested_models.get(name, "")
        ordre = ([demande] if demande else []) \
            + [m for m in prefs if not listes or m in listes] \
            + sorted(m for m in listes if m not in prefs and not any(x in m.lower() for x in self.HORS_MENU))
        vus, a_essayer = set(), []
        for m in ordre:
            if m and m not in vus:
                vus.add(m)
                a_essayer.append(m)
        rows = []
        for m in a_essayer[:max_probe]:
            reussi, detail, status = self._essayer(p, m)
            rows.append({"modèle": m, "essai": "✅" if reussi else "❌", "détail": detail})
            if status == 429:
                self.exhausted[name] = "quota atteint (HTTP 429) dès l'essai — mis de côté pour la session"
                log.warning("LLM %s : %s", name, self.exhausted[name])
                break
        ecartes = len(a_essayer) - min(len(a_essayer), max_probe)
        if ecartes > 0:
            rows.append({"modèle": "…", "essai": "", "détail": "{} autre(s) modèle(s) non essayé(s)".format(ecartes)})
        return pd.DataFrame(rows, columns=colonnes)

    def probe(self) -> pd.DataFrame:
        """Un appel d'essai par fournisseur disponible : le modèle existe-t-il, et répond-il en JSON ?

        Un fournisseur qui échoue ici est mis de côté avec la raison, au lieu de
        faire échouer chaque lot de la classification. Un 429 à l'essai vaut
        quota atteint, comme en cours de route. Le cache n'est pas consulté :
        l'essai doit toucher le service, c'est son objet."""
        rows = []
        for p in self.providers:
            if p.name == "rules":
                continue
            ok, why = self._available(p, cached=True)
            if not ok:
                rows.append({"fournisseur": p.name, "modèle": "", "essai": "—", "détail": why})
                continue
            model = self._model_for(p)
            t0 = time.perf_counter()
            try:
                res = p.complete(self.PROBE_SYSTEM, self.PROBE_USER, model)
            except Exception as e:
                status = e.args[1] if len(e.args) > 1 else None
                msg = str(e.args[0]) if e.args else type(e).__name__
                if status == 429:
                    raison = "quota atteint (HTTP 429) dès l'essai — mis de côté pour la session"
                    self.exhausted[p.name] = raison
                    log.warning("LLM %s : %s", p.name, raison)
                    rows.append({"fournisseur": p.name, "modèle": model, "essai": "❌", "détail": raison})
                    continue
                # Le fournisseur suggère parfois lui-même le remplaçant : « no
                # longer available to new users. Please update your code to use
                # models/gemini-3.5-flash-lite ». On le prend au mot, une fois.
                autres = [m for m in re.findall(r"models/([A-Za-z0-9][\w.\-]*)", msg) if m != model]
                suggere = autres[0] if autres else None
                if suggere:
                    try:
                        res = p.complete(self.PROBE_SYSTEM, self.PROBE_USER, suggere)
                        json.loads(strip_fences(res.text))
                    except Exception:
                        suggere = None
                if suggere:
                    note = ("le modèle « {} » a été refusé ({}) ; « {} », proposé par le fournisseur, "
                            "répond et est employé à la place".format(model, msg, suggere))
                    self._models[p.name] = suggere
                    self.model_notes[p.name] = note
                    log.warning("LLM %s : %s", p.name, note)
                    rows.append({"fournisseur": p.name, "modèle": suggere, "essai": "✅",
                                 "détail": "remplace « {} » : {}".format(model, msg)})
                    continue
                raison = "essai du modèle « {} » échoué : {}".format(model, msg)
                self.rejected[p.name] = raison
                log.warning("LLM %s : %s", p.name, raison)
                rows.append({"fournisseur": p.name, "modèle": model, "essai": "❌", "détail": raison})
                continue
            try:
                json.loads(strip_fences(res.text))
            except json.JSONDecodeError:
                raison = "le modèle « {} » ne répond pas en JSON".format(model)
                self.rejected[p.name] = raison
                log.warning("LLM %s : %s", p.name, raison)
                rows.append({"fournisseur": p.name, "modèle": model, "essai": "❌", "détail": raison})
                continue
            rows.append({"fournisseur": p.name, "modèle": model, "essai": "✅",
                         "détail": "répond en JSON en {:.1f} s".format(time.perf_counter() - t0)})
        return pd.DataFrame(rows, columns=["fournisseur", "modèle", "essai", "détail"])

    # cache -----------------------------------------------------------------------------
    def _key(self, provider, model, system, user) -> str:
        return hashlib.sha256(f"{provider}|{model}|{system}|{user}".encode()).hexdigest()

    def _cache_get(self, key) -> Optional[str]:
        if not self.cache_path:
            return None
        with sqlite3.connect(self.cache_path) as con:
            row = con.execute("SELECT response FROM cache WHERE key=?", (key,)).fetchone()
        return row[0] if row else None

    def _cache_put(self, key, provider, model, text) -> None:
        if not self.cache_path:
            return
        with sqlite3.connect(self.cache_path) as con:
            con.execute("INSERT OR REPLACE INTO cache VALUES (?,?,?,?,?)", (key, provider, model, text, time.time()))

    # appel -----------------------------------------------------------------------------
    def complete_json(self, system: str, user: str, schema: Optional[type[BaseModel]] = None,
                      task: str = "") -> tuple[object, dict]:
        errors = []
        for p in self.providers:
            ok, why = self._available(p, cached=True)
            if not ok:
                continue
            quota_atteint = False
            model = self._model_for(p)
            key = self._key(p.name, model, system, user)
            cached = self._cache_get(key)
            for attempt in range(self.max_retries + 1):
                try:
                    if cached is not None:
                        res = LLMResult(cached, p.name, model, cached=True)
                    else:
                        res = p.complete(system, user, model)
                    data = json.loads(strip_fences(res.text))
                    obj = schema.model_validate(data) if schema else data
                    if cached is None:
                        self._cache_put(key, p.name, model, res.text)
                    self.usage.append({"tâche": task, "fournisseur": p.name, "modèle": model,
                                       "jetons_entrée": res.prompt_tokens, "jetons_sortie": res.completion_tokens,
                                       "latence_s": round(res.latency, 2), "cache": res.cached, "ok": True})
                    return obj, {"provider": p.name, "model": model, "cached": res.cached}
                except (json.JSONDecodeError, ValidationError) as e:
                    errors.append(f"{p.name}: réponse invalide ({type(e).__name__})")
                    cached = None
                    break  # même consigne → même erreur probable : fournisseur suivant
                except Exception as e:
                    status = e.args[1] if len(e.args) > 1 else None
                    retry_after = e.args[2] if len(e.args) > 2 else None
                    errors.append(f"{p.name}: {type(e).__name__} {e.args[0] if e.args else ''}")
                    if status == 429:
                        # Quota par minute : le serveur dit combien attendre
                        # (Retry-After), on attend cela, plusieurs fois s'il le
                        # faut. Un Retry-After long (quota journalier) ne vaut
                        # pas la peine d'être attendu : on change de fournisseur.
                        attendre = float(retry_after) if retry_after else float(2 ** (attempt + 2))
                        if attempt < self.max_retries and attendre <= self.max_wait:
                            self.sleep(attendre)
                            continue
                        quota_atteint = True
                    break
            self.usage.append({"tâche": task, "fournisseur": p.name, "modèle": model, "jetons_entrée": 0,
                               "jetons_sortie": 0, "latence_s": 0, "cache": False, "ok": False})
            if quota_atteint:
                detail = re.sub(r"^\w+: LLMError ", "", errors[-1]) if errors else ""
                self.exhausted[p.name] = ("quota atteint — mis de côté pour le reste de la session"
                                          + (" ({})".format(detail) if detail else ""))
                log.warning("LLM %s : quota atteint — les lots suivants passent à « %s »",
                            p.name, self._next_after(p))
            else:
                log.warning("LLM %s indisponible pour « %s » : %s — passage au suivant", p.name, task,
                            errors[-1] if errors else "?")
        raise LLMError("Aucun fournisseur n'a produit de réponse valide : " + " | ".join(errors))

    def usage_summary(self) -> pd.DataFrame:
        if not self.usage:
            return pd.DataFrame(columns=["fournisseur", "modèle", "appels", "depuis_cache", "échecs",
                                         "jetons_entrée", "jetons_sortie", "coût_usd"])
        u = pd.DataFrame(self.usage)
        g = u.groupby(["fournisseur", "modèle"]).agg(
            appels=("ok", "size"), depuis_cache=("cache", "sum"), échecs=("ok", lambda s: int((~s).sum())),
            jetons_entrée=("jetons_entrée", "sum"), jetons_sortie=("jetons_sortie", "sum")).reset_index()

        def cost(r):
            price = LLM_PRICING.get(r["fournisseur"])
            if price is None:
                return None
            return round(r["jetons_entrée"] / 1e6 * price[0] + r["jetons_sortie"] / 1e6 * price[1], 4)

        g["coût_usd"] = g.apply(cost, axis=1)
        return g


def start_ollama_in_colab(model: str = "qwen2.5:7b", host: str = "http://localhost:11434",
                          attente_s: float = 90.0) -> dict:
    """Installe et lance Ollama dans Colab (GPU conseillé), puis télécharge le modèle.

    Rend ``{"ok": bool, "modèle": str, "détail": str}``. Chaque étape est
    vérifiée. L'ancienne version enchaînait trois commandes sans regarder leur
    résultat, dormait cinq secondes et rendait la main : quand le serveur
    n'était pas prêt, le carnet concluait « serveur introuvable » sans pouvoir
    dire pourquoi, et la sortie des commandes n'apparaissait nulle part.
    """
    import shutil

    import requests

    def _run(cmd: str, timeout: float) -> tuple[int, list[str]]:
        try:
            r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return 124, ["délai dépassé ({} s)".format(int(timeout))]
        lignes = (r.stdout + "\n" + r.stderr).strip().splitlines()
        return r.returncode, [l for l in lignes if l.strip()][-6:]

    def _pret() -> bool:
        try:
            return requests.get(f"{host}/api/tags", timeout=3).status_code == 200
        except Exception:
            return False

    etapes = []
    if not shutil.which("ollama"):
        # Le script d'installation décompresse une archive zstd, et l'image
        # Colab n'a pas l'outil : « This version requires zstd for extraction »,
        # vu le 27/10/2026. On l'installe d'abord (Colab tourne en root).
        if not shutil.which("zstd"):
            code, sortie = _run("apt-get install -y -qq zstd || (apt-get update -qq && apt-get install -y -qq zstd)", 600)
            etapes.append("zstd : code {}".format(code))
            if not shutil.which("zstd"):
                return {"ok": False, "modèle": model,
                        "détail": "zstd n'a pas pu être installé — " + " / ".join(etapes + sortie)}
        code, sortie = _run("curl -fsSL https://ollama.com/install.sh | sh", 900)
        etapes.append("installation : code {}".format(code))
        if not shutil.which("ollama"):
            return {"ok": False, "modèle": model,
                    "détail": "installation échouée — " + " / ".join(etapes + sortie)}
    else:
        etapes.append("ollama déjà installé")

    if not _pret():
        subprocess.Popen("nohup ollama serve > /tmp/ollama.log 2>&1 &", shell=True)
        debut = time.time()
        while time.time() - debut < attente_s and not _pret():
            time.sleep(2)
        if not _pret():
            try:
                journal = Path("/tmp/ollama.log").read_text(errors="replace").strip().splitlines()[-6:]
            except Exception:
                journal = []
            return {"ok": False, "modèle": model,
                    "détail": "le serveur ne répond pas sur {} après {:.0f} s — {}".format(
                        host, attente_s, " / ".join(journal) or "journal vide")}
    etapes.append("serveur prêt")

    try:
        presents = [m.get("name", "") for m in requests.get(f"{host}/api/tags", timeout=5).json().get("models", [])]
    except Exception:
        presents = []
    if model in presents or (":" not in model and model + ":latest" in presents):
        etapes.append("modèle {} déjà présent".format(model))
    else:
        code, sortie = _run(f"ollama pull {model}", 3600)
        etapes.append("téléchargement de {} : code {}".format(model, code))
        if code != 0:
            return {"ok": False, "modèle": model, "détail": " / ".join(etapes + sortie)}
    return {"ok": True, "modèle": model, "détail": " ; ".join(etapes)}
