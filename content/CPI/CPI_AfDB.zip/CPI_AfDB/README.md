# Jumia → Indice des prix à la consommation

Pipeline reproductible qui transforme les sites **Jumia** d'Afrique en source de données de prix pour la
statistique officielle : **découverte** des sites nationaux → **validation** de leur accessibilité → **collecte
responsable** → **classification COICOP 2018 par LLM** (Ollama, Groq, Gemini) → **indices de prix** (Jevons, GEKS)
→ **comparaison avec l'IPC officiel** → **rapport HTML autonome**.

- **Entrée** : un pays (`CI`, `NG`, `KE`, `MA`, `EG`, `GH`, `SN`, `UG`) et quelques paramètres.
- **Sortie** : un panel Parquet de relevés datés, des indices par division COICOP et d'ensemble, des messages clés
  avec niveau de confiance, des exports CSV/Parquet et un rapport HTML d'un seul fichier.
- **Mode test** : tout le notebook s'exécute **hors ligne** sur un site Jumia synthétique (pays fictif `XT`) qui
  reproduit la structure des vrais sites et une année de relevés mensuels. Toutes les sorties de ce mode portent
  la mention « données synthétiques ».

---

## Démarrage rapide

**Google Colab** : seul le **carnet 3** y tourne. Déposez le dossier du projet dans `/content/` (volet Fichiers),
ou copiez-le dans Google Drive et montez Drive ; la première cellule le reconnaît à son contenu et installe
les paquets manquants.

**Les carnets 1 et 2 doivent tourner sur le poste de l'institut.** Ils interrogent des sites web : depuis Colab,
le trafic part des adresses de Google, et votre institution ne peut pas répondre d'une requête qu'elle n'a pas
émise. Le 13/10/2026, dix des quatorze sites Jumia testés depuis Colab ont répondu par un refus. Les deux carnets
détectent Colab et s'y arrêtent en l'expliquant.

**En local** :

```bash
.\preparer.bat                # Windows ; Linux et macOS : bash preparer.sh
cp .env.example .env          # clés Groq / Gemini (facultatif)
.\.venv\Scripts\jupyter lab   # Linux et macOS : .venv/bin/jupyter lab
```

Ouvrez les carnets dans l'ordre : **1** (Jumia), **2** (autres sources), **3** (analyse). Dans les carnets 1
et 2, renseignez `CONTACT_EMAIL` et choisissez le pays ; le carnet 3 lit de lui-même les archives qu'ils
écrivent dans `sorties/outputs/`. Avant toute collecte réelle, remplacez `PROJECT_URL` dans `src/config.py`
par l'adresse de votre projet : elle part dans le User-Agent envoyé au site.

---

## Le processus en 7 étapes

| Étape | Ce qui est fait | Résultat |
|---|---|---|
| **1 · Découverte** | registre interne (y compris pays quittés : Algérie, Tunisie, Afrique du Sud, Cameroun, Tanzanie, Rwanda) croisé avec la page « Locations » de group.jumia.com et le sélecteur de jumia.com | registre pays · ISO2/ISO3 · URL · devise · langue |
| **2 · Validation** | robots.txt, statut HTTP, redirections, temps de réponse, certificat TLS, présence d'un catalogue | tableau ✅ actif / ⚠️ restreint / ❌ fermé, carte, sélecteur `ipywidgets` |
| **3 · Collecte** | arborescence des catégories, pages de liste (40 produits), fiches produit sur échantillon ; 3 méthodes d'extraction (`__STORE__` JSON, attributs `data-gtm-*`, texte des cartes) ; reprise après interruption | partition Parquet `country=XX/collect_date=AAAA-MM-JJ`, requêtes DuckDB |
| **4 · Enrichissement** | classe COICOP 2018, contenu net et prix unitaire, marque normalisée, doublons entre vendeurs ; règles + LLM, validation humaine (accord, kappa, matrice de confusion) | produits enrichis, échantillon à annoter |
| **5 · Indices** | prix mensuel géométrique, modèle apparié, imputation des absences courtes, relatifs aberrants écartés ; Jevons (Dutot, Carli pour comparaison), GEKS-Jevons et GEKS-Törnqvist ; Young chaîné avec pondérations nationales | indices, inflation mensuelle et annuelle, contributions, promotions, dispersion |
| **6 · Comparaison** | IPC officiel (fichier de l'institut national ou Banque mondiale), corrélations, décalages, biais | statistiques d'écart, tableau des biais |
| **7 · Restitution** | messages clés générés à partir des données, niveau de confiance motivé | exports, manifeste, rapport HTML autonome |

## Architecture

```
jumia-cpi/
├── notebooks/             # 6 carnets : collecte Jumia, autres sources, analyse — en FR et EN
├── src/                   # 24 modules
│   ├── config.py          # registre des sites, paramètres, COICOP 2018, modèles LLM par défaut
│   ├── fetch.py           # HTTP poli : robots.txt (RFC 9309), rythme, reprises, Retry-After, cache disque
│   ├── discovery.py       # étape 1
│   ├── validation.py      # étape 2
│   ├── scraper.py         # étape 3 : catégories, pages de liste, fiches produit, points de contrôle
│   ├── storage.py         # Parquet partitionné + DuckDB
│   ├── llm.py             # LLMClient : Ollama, Groq, Gemini, repli, cache SQLite, jetons
│   ├── classification.py  # étape 4 : règles, quantités, marques, doublons, schémas Pydantic, accord
│   ├── index.py           # étape 5 : Jevons, Dutot, Carli, GEKS, Young chaîné, contributions
│   ├── official.py        # étape 6 : IPC officiel, Banque mondiale, biais
│   ├── messages.py        # interprétations et messages clés avec niveau de confiance
│   ├── viz.py             # encadrés, schéma du pipeline, tableaux, figures Plotly
│   ├── export.py          # CSV/Parquet, manifeste, rapport HTML
│   ├── pipeline.py        # assemblage commun aux carnets et aux scripts
│   ├── panel.py           # lecture et fusion des archives ; tris de cohérence avant tout calcul
│   ├── loyers.py          # étape 3 bis : annonces de location, division 04
│   ├── pam.py             # relevés du Programme alimentaire mondial
│   ├── officiel.py        # sources institutionnelles : séries, tarifs, indices
│   ├── orchestration_officielle.py  # quelle source pour quel pays, et dans quel ordre
│   ├── evaluation.py      # banc d'essai : précision, rappel, couverture des méthodes
│   ├── sortie.py          # classeurs Excel lisibles à côté des archives
│   ├── fixture.py         # site Jumia synthétique hors ligne (mode test)
│   └── utils.py           # journal, secrets, analyse des prix affichés
├── scripts/               # 15 outils de campagne : collecte, pondérations, inventaire, livraison, vérification
│   └── obsoletes/         # anciens générateurs de carnets, conservés pour mémoire (voir leur LISEZ-MOI)
├── tests/                 # 258 tests pytest répartis en 14 fichiers
├── paniers/               # paniers par pays et pondérations officielles (CI, SN, UG)
├── data/exemple/          # jeu de démonstration du carnet 3 ; data/templates/ : modèles vierges
├── docs/                  # guides Word et présentations, chacun avec son générateur ; livraison/ : LISEZ-MOI de CPI_AfDB
├── requirements.txt / .env.example / .gitignore
```

## Fournisseurs LLM

| Fournisseur | Configuration | Remarque |
|---|---|---|
| **Groq** | secret `GROQ_API_KEY` | rapide ; modèle par défaut `openai/gpt-oss-120b` (premier du catalogue dans l'ordre de préférence) |
| **Gemini** | secret `GEMINI_API_KEY` | modèle par défaut `gemini-2.5-flash` |
| **Ollama** | serveur local (`ollama serve`, `ollama pull qwen2.5:7b`) ; sur Colab : cellule 6.0 | gratuit, données gardées en local |
| **Règles** | aucune | dernier recours déterministe, toujours disponible |

**Cascade.** Le carnet 3 (`MODELE = "cascade"`, réglage livré) démarre avec Groq. Quand un fournisseur répond
HTTP 429 malgré les reprises (Retry-After respecté jusqu'à 60 s), il est mis de côté pour le reste de la session
et les lots suivants passent au fournisseur d'après : Groq → Gemini → Ollama → règles. Une clé absente est sautée.
Le tableau « Appels par fournisseur », en fin de classification, dit qui a classé quoi.

**Des menus qui ne proposent que les modèles accessibles.** Les menus figés d'un formulaire Colab ne peuvent pas
savoir ce qu'un fournisseur accepte aujourd'hui. La cellule « Modèles accessibles » du carnet 3 lit donc les clés,
interroge chaque catalogue, écarte ce qui n'est pas un modèle de dialogue texte (synthèse vocale, image, agents,
versions d'essai), fait **un appel d'essai par candidat** (`LLMClient.candidates`, 8 au plus par fournisseur) et
construit un menu déroulant avec les seuls modèles qui ont répondu, le tableau des essais montrant pourquoi les
autres ont été écartés. La cellule « Classification » reprend le choix, le réessaie (`LLMClient.probe`) et affiche
le fournisseur employé et ses relais. Pour Ollama, `MODELE_OLLAMA` désigne le modèle à télécharger sur Colab. Les
catalogues bougent : le 26/10/2026, Groq ne proposait plus les llama-3.x et Gemini fermait les 2.5 aux nouveaux comptes.

**Le banc d'essai compare quatre méthodes.** Règles, **plongements multilingues** (`src/embeddings.py` : chaque
classe COICOP a un prototype, libellé français et anglais plus les mots-clés de sa règle ; chaque libellé est
rattaché à la classe la plus proche en cosinus, avec une confiance et une marge ; des références annotées peuvent
s'ajouter aux prototypes), modèle de langue, et mixte. Le modèle de plongements est local et sans quota
(`MODELE_EMBEDDINGS`, par défaut `intfloat/multilingual-e5-large` ; `BAAI/bge-m3`, `multilingual-e5-base` ou
`paraphrase-multilingual-MiniLM-L12-v2` pour un CPU modeste). `sentence-transformers` s'installe à la demande
depuis le carnet et n'est pas une dépendance du moteur : sans lui, la méthode est « indisponible », pas le carnet cassé.
Deux lignes dans le tableau : `embeddings`, zéro-tir par prototypes, et `embeddings_voisins`, prototypes plus
produits annotés comme références en validation croisée à cinq plis, sans fuite. Mesuré le 28/10/2026 sur le jeu
de référence synthétique avec `multilingual-e5-base` : 54 % de justesse par classe en zéro-tir (73 % par division),
94 % avec les références (97 % par division). Le zéro-tir ne fait que reconnaître des libellés de classes ; la
méthode vaut par l'échantillon annoté qu'on lui donne.

**Le prompt du modèle existe en deux langues** (`classification.system_prompt("fr" | "en")`, réglé par
`Settings.prompt_lang`) : le carnet français envoie le français, le carnet anglais l'anglais, même liste de codes
et même schéma de validation. La cellule « Classification » affiche, dans un encadré repliable, le message système
réellement envoyé et le premier lot de produits tel qu'il part.

Les secrets sont lus dans cet ordre : variable d'environnement → Secrets Colab (🔑) → `.env` → saisie masquée.
Ils ne sont jamais affichés ni écrits. Si `MODEL_NAME` est vide, le client interroge la liste des modèles du
fournisseur et retient le premier modèle disponible de sa liste de préférence (`config.LLM_DEFAULT_MODELS`) :
un modèle retiré n'arrête pas le pipeline. Les réponses sont validées par Pydantic et mises en cache dans
`outputs/<ISO3>/llm_cache.sqlite`. Pour un suivi des coûts en dollars, renseignez les tarifs dans
`config.LLM_PRICING`.

## Collecte responsable

- **robots.txt d'abord** : chaque URL est vérifiée (jokers `*`, ancre `$`, règle la plus longue). La politique
  publiée par Jumia autorise la collecte par un robot qui s'identifie avec son propriétaire et un contact, sous
  200 requêtes par minute ; elle interdit notamment la recherche (`/catalog/`, `q=`), les filtres et tris, les
  pages `/mlp-*` et les chemins de profondeur ≥ 3.
- **Identification** : User-Agent `JumiaCPI-Research/1.0 (+URL du projet; contact: …)` ; `CONTACT_EMAIL` est
  obligatoire en mode `live`.
- **Rythme** : 2 s entre requêtes par défaut (≤ 30 requêtes/min), délai exponentiel sur 429/5xx.
- **Pas de contournement** : un site protégé est classé « restreint » et n'est pas collecté.
- **Aucune donnée personnelle**, usage statistique non commercial. Relisez les conditions d'utilisation du site
  de chaque pays avant de diffuser des données brutes.

## Planifier un relevé mensuel

```bash
python scripts/collect.py --country CI --contact vous@institut.org --max-pages 10
# cron, le 15 de chaque mois à 6 h :
0 6 15 * * cd /chemin/jumia-cpi && .venv/bin/python scripts/collect.py --country CI --contact vous@institut.org
```

Chaque exécution ajoute un relevé daté au panel ; relancer le même jour reprend là où la collecte s'était arrêtée.
L'indice devient calculable dès la deuxième période, le glissement annuel au treizième mois.

## Tests

```bash
pytest -q                               # 258 tests : prix affichés, robots.txt, reprises, extraction, classification,
                                        # LLM simulés (Groq, Gemini, repli, cache), indices, comparaison, rapport
python scripts/verifier_notebooks.py    # les carnets : 3_analyse_FR et 3_analysis_EN en entier sur le jeu
                                        # d'exemple, 1_collecte_jumia_FR et 1_collect_jumia_EN jusqu'aux
                                        # paramètres ; aucune requête à Jumia, écriture dans verification/ seulement
```

La suite pytest complète tourne en une vingtaine de secondes (mesuré le 24/10/2026 : 258 tests, 16 s) ;
le harnais des carnets en quelques minutes.

Les six carnets se modifient directement. Les anciens générateurs
(`build_notebook.py`, `generer_notebooks.py`, `run_notebook_test.py` et leurs
fichiers de cellules) datent du temps d'un carnet unique puis de trois carnets
monolingues ; ils sont rangés dans `scripts/obsoletes/` et ne doivent plus être
exécutés.

Les tests d'indices vérifient que la chaîne retrouve l'inflation connue du site synthétique, que les
contributions s'additionnent exactement à la variation de l'ensemble et que le GEKS coïncide avec le Jevons en
l'absence de bruit.

## Limites

Les prix en ligne ne couvrent ni les services (logement, transports publics, éducation) ni les marchés
informels ; les acheteurs sont surtout urbains et connectés ; il n'y a pas de quantités vendues ; les prix barrés
peuvent être des références permanentes ; les gabarits HTML peuvent changer sans préavis (surveillez
`parse_method` et le nombre de produits par page) ; la classification LLM doit être validée par un échantillon
annoté. En mode test, l'accord de classification est optimiste, car les règles ont été écrites en connaissant le
catalogue synthétique. La carte des sites charge son fond de carte depuis le CDN de Plotly : elle demande une
connexion Internet, le reste du rapport HTML fonctionne hors ligne. Voir la section 10 du notebook.

## Références

- Cavallo, A. et Rigobon, R. (2016). The Billion Prices Project: Using Online Prices for Measurement and Research. *Journal of Economic Perspectives* 30(2), 151-178.
- Cavallo, A. (2017). Are Online and Offline Prices Similar? *American Economic Review* 107(1), 283-303.
- FMI, OIT, OCDE, Eurostat, CEE-ONU, Banque mondiale (2020). *Consumer Price Index Manual: Concepts and Methods*.
- Eurostat (2020). *Guide on Multilateral Methods in the HICP* ; *Practical Guidelines on Web Scraping for the HICP*.
- Nations Unies (2018). *COICOP 2018*. Statistical Papers, Series M, No. 99.
- Ivancic, L., Diewert, W. E. et Fox, K. J. (2011). Scanner data, time aggregation and the construction of price indexes. *Journal of Econometrics* 161(1), 24-35.
- IETF (2022). RFC 9309 : Robots Exclusion Protocol.

## Licence

Code : MIT. Les données collectées restent soumises aux conditions d'utilisation des sites Jumia.
