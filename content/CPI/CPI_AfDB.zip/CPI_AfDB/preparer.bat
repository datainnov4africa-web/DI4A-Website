@echo off
rem ---------------------------------------------------------------------------
rem  Prepare l'environnement du projet, depuis cmd.exe comme depuis PowerShell.
rem
rem  Pourquoi ce fichier existe
rem  --------------------------
rem  Dans cmd.exe, « .\preparer.ps1 » n'execute rien : cmd ne sait pas lancer un
rem  script PowerShell, il se contente d'OUVRIR le fichier avec l'application
rem  associee - le Bloc-notes. L'utilisateur voit son script s'afficher et croit
rem  qu'il s'est passe quelque chose.
rem
rem  Ce fichier .bat, lui, est executable par cmd. Il appelle PowerShell avec
rem  « -ExecutionPolicy Bypass », ce qui evite aussi le refus d'execution des
rem  scripts non signes - l'autre piege classique.
rem
rem  Usage, depuis n'importe quel terminal :
rem      preparer
rem      preparer -Recreer
rem      preparer -Python "C:\chemin\python.exe"
rem ---------------------------------------------------------------------------

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0preparer.ps1" %*
