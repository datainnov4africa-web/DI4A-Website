<#
    Prepare l'environnement Python du projet, quel que soit le terminal.

    Pourquoi ce script existe
    -------------------------
    `python -m venv .venv` depend de ce que `python` designe au moment ou on
    l'ecrit. Depuis une invite ou un environnement conda est actif - l'invite
    affiche alors « (CPI) » ou « (base) » - c'est le Python de conda qui cree
    l'environnement, et non celui qu'on croyait.

    Pire : `venv` **n'efface pas** un dossier existant. Relancer la commande sur
    un `.venv` deja peuple se contente de reecrire `pyvenv.cfg` et les
    lanceurs ; les paquets installes par l'interpreteur precedent restent en
    place. On obtient alors un melange - ici, un pip exigeant Python 3.10+
    execute par un Python 3.9 - et une trace illisible :

        TypeError: dataclass() got an unexpected keyword argument 'slots'

    Ce script choisit l'interpreteur explicitement et repart d'un dossier
    vide. Il ne depend d'aucun PATH et d'aucun environnement actif.

    Il installe les dependances du projet **et JupyterLab**, puis verifie que
    les paquets et le code s'importent : a la fin, l'environnement est pret a
    ouvrir les carnets, et il dit la commande exacte pour le faire.

    Usage :
        .\preparer.ps1                 # choisit le meilleur Python trouve
        .\preparer.ps1 -Python "C:\chemin\python.exe"
        .\preparer.ps1 -Recreer        # efface .venv et recommence

    Sous Linux et macOS : `bash preparer.sh`, qui fait la meme chose.
#>

[CmdletBinding()]
param(
    [string]$Python = "",
    [switch]$Recreer
)

$ErrorActionPreference = "Stop"
$racine = Split-Path -Parent $MyInvocation.MyCommand.Path
$venv = Join-Path $racine ".venv"
$exe = Join-Path $venv "Scripts\python.exe"

# Version minimale : celle du projet est 3.9, mais le pip moderne embarque par
# `ensurepip` exige 3.10. On vise donc 3.10 pour eviter le melange decrit
# ci-dessus.
$versionMinimale = [version]"3.10"

function Trouver-Python {
    $candidats = @()
    if ($Python) { $candidats += $Python }

    # `py -0p` liste les interpreteurs enregistres, hors conda.
    try {
        $liste = & py -0p 2>$null
        foreach ($ligne in $liste) {
            if ($ligne -match '([A-Za-z]:\\[^\s].*python\.exe)') { $candidats += $Matches[1] }
        }
    } catch {}

    $candidats += @(
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python310\python.exe"
    )

    foreach ($c in $candidats) {
        if (-not (Test-Path $c)) { continue }
        # On ecarte conda : son Python fonctionne, mais il entraine le defaut
        # d'environnement actif que ce script existe pour eviter.
        if ($c -match "anaconda|miniconda|\\envs\\") { continue }
        try {
            $v = & $c -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
            if ($v -and [version]$v -ge $versionMinimale) { return $c }
        } catch {}
    }
    return $null
}

Write-Host "=== Preparation de l'environnement ===" -ForegroundColor Cyan
Write-Host "Projet : $racine"

if ($env:CONDA_DEFAULT_ENV) {
    Write-Host ""
    Write-Host "Environnement conda actif : $env:CONDA_DEFAULT_ENV" -ForegroundColor Yellow
    Write-Host "Il est ignore : ce script choisit son interpreteur lui-meme."
}

$choisi = Trouver-Python
if (-not $choisi) {
    Write-Host ""
    Write-Host "Aucun Python $versionMinimale+ hors conda n'a ete trouve." -ForegroundColor Red
    Write-Host "Installez-en un depuis python.org, ou indiquez-le :"
    Write-Host '    .\preparer.ps1 -Python "C:\chemin\vers\python.exe"'
    exit 1
}
$version = & $choisi -c "import sys; print(sys.version.split()[0])"
Write-Host ""
Write-Host "Interpreteur : $choisi  (Python $version)"

if (Test-Path $venv) {
    $cfg = Join-Path $venv "pyvenv.cfg"
    $maison = if (Test-Path $cfg) { (Get-Content $cfg | Where-Object { $_ -like "home =*" }) -replace "home = ", "" } else { "" }
    $incoherent = $maison -and ((Split-Path -Parent $choisi) -ne $maison)
    if ($Recreer -or $incoherent) {
        if ($incoherent) {
            Write-Host ""
            Write-Host "Le .venv existant pointe vers un autre interpreteur :" -ForegroundColor Yellow
            Write-Host "    $maison"
            Write-Host "Un venv ne se reecrit pas en place : on le supprime et on recommence."
        }
        Remove-Item -Recurse -Force $venv
    } else {
        Write-Host "Environnement deja present et coherent."
    }
}

if (-not (Test-Path $venv)) {
    Write-Host ""
    Write-Host "Creation de .venv ..."
    & $choisi -m venv $venv
}

& $exe -c "import ssl, sys; print('venv  : Python', sys.version.split()[0], '|', ssl.OPENSSL_VERSION)"

Write-Host ""
Write-Host "Installation des paquets (quelques minutes la premiere fois) ..."
function Echec($message) {
    Write-Host ""
    Write-Host ">>> $message" -ForegroundColor Red
    Write-Host "    Le chemin du dossier est-il tres long (OneDrive, sous-dossiers) ?"
    Write-Host "    pip echoue alors sur certains paquets : deplacez le dossier plus"
    Write-Host "    pres de la racine (par exemple C:\CPI_AfDB) et relancez avec -Recreer."
    exit 1
}

& $exe -m pip install --quiet --upgrade pip
& $exe -m pip install --quiet -r (Join-Path $racine "requirements.txt")
if ($LASTEXITCODE -ne 0) { Echec "l'installation des dependances a echoue (voir les messages ci-dessus)." }
& $exe -m pip install --quiet pytest openpyxl jupyterlab
if ($LASTEXITCODE -ne 0) { Echec "l'installation de JupyterLab a echoue (voir les messages ci-dessus)." }

Write-Host ""
Write-Host "Verification ..."
& $exe -c "import pandas, duckdb, plotly, pyarrow, pydantic; print('  paquets : ok')"
if ($LASTEXITCODE -ne 0) { Echec "une bibliotheque ne s'importe pas." }
if (Test-Path (Join-Path $racine "src\pipeline.py")) {
    Push-Location $racine
    try { & $exe -B -c "import src.pipeline, src.index; print('  code    : ok')" }
    finally { Pop-Location }
    if ($LASTEXITCODE -ne 0) { Echec "le code du projet ne s'importe pas." }
}
$jup = Join-Path $venv "Scripts\jupyter.exe"
$versionJupyter = ""
if (Test-Path $jup) {
    $versionJupyter = (& $jup --version | Select-String "^jupyterlab\s*:" | Select-Object -First 1)
}
if (-not $versionJupyter -or "$versionJupyter" -match "not installed") {
    Echec "JupyterLab n'est pas installe dans .venv."
}
Write-Host "  $versionJupyter"

$n = (& $exe -m pip list --format=freeze | Measure-Object -Line).Lines
Write-Host ""
Write-Host "=== Pret : $n paquets ===" -ForegroundColor Green
Write-Host ""
Write-Host "Lancez JupyterLab depuis ce dossier :"
Write-Host "    .\.venv\Scripts\jupyter lab"
Write-Host ""
Write-Host "Pour verifier davantage (depot complet seulement) :"
Write-Host "    .\.venv\Scripts\python -m pytest -q"
Write-Host "    .\.venv\Scripts\python scripts\verifier_notebooks.py"
