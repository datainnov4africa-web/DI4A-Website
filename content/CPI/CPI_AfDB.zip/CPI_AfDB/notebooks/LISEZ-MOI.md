# Les trois notebooks

Un seul moteur, trois consoles, chacune en deux langues. Elles ne diffèrent que
par l'**origine des données** — jamais par la façon de calculer l'indice.

```
1_collecte_jumia_FR.ipynb           le site marchand        →  écrit une archive
2_collecte_autres_sources_FR.ipynb  les publications        →  écrit une archive
                                    institutionnelles
3_analyse_FR.ipynb                  TOUTES les archives     →  agrège, calcule, rapporte
```

Les versions anglaises portent des noms traduits, pas seulement suffixés :
`1_collect_jumia_EN`, `2_collect_other_sources_EN`, `3_analysis_EN`. Même
code, mêmes réglages, mêmes résultats.

Les deux collectes tournent **sur le poste de l'institut** ; l'analyse tourne où
l'on veut, Colab compris.

Le notebook 3 prend **plusieurs archives à la fois** — chemins séparés par des
points-virgules, ou un dossier entier. Les doublons sont écartés et comptés,
les types numériques rétablis, et mélanger deux pays est signalé : un indice
mesure un panier national.

## Pourquoi deux

La frontière est **physique, pas technique**. Collecter exige un point de
sortie que l'éditeur accepte ; calculer un indice n'exige rien.

Le 13/10/2026, ce pipeline a testé 14 sites Jumia depuis Google Colab : **dix
ont répondu HTTP 403, en 14 à 20 millisecondes**. Une requête partie d'un centre
de données vers Abidjan et revenue en 15 ms n'a jamais atteint un serveur
Jumia — elle a été refusée par le nœud CDN le plus proche, sur la seule base de
l'adresse de sortie. Les quatre marchés réellement fermés, eux, répondaient en
735 à 742 ms : eux avaient fait le trajet.

Le même jour, depuis un poste de travail, jumia.ci et jumia.sn ont servi
**11 358 lignes**.

Ce n'est pas réparable depuis Colab, et il ne faut pas essayer : le `robots.txt`
de Jumia vise nommément la parade — *« bots trying to use too many IPs to
increase performance may also be blocked »*.

## Pourquoi pas deux bases de code

Si chaque notebook portait sa copie de la formule, les deux divergeraient en
quelques semaines et personne ne saurait lequel croire. Les deux appellent donc
le même `src/`, et **l'indice est calculé par le même module des deux côtés**.

## Le fichier qui les relie

`panel_CI_2026-10-13.zip` — une archive unique, parce qu'on ne peut pas demander
à un collègue non technique de déposer trois fichiers dans le bon ordre. Elle
porte :

| | |
|---|---|
| `panel.parquet` | **la donnée** — types préservés, codes intacts |
| `panel_lisible.xlsx` | une copie pour l'œil, jamais relue par le programme |
| `manifeste.json` | la provenance : version du code, date, point de sortie, empreinte |

> **Ne faites pas transiter la donnée par Excel.** Sur un projet voisin, un
> classeur a typé un code de division en entier et un code de groupe en
> flottant, et une troncature a réduit **970 produits à 130** — silencieusement.
> Le compte restait plausible et l'indice se calculait.

Le notebook d'analyse accepte quand même un Parquet, un CSV ou un Excel nus : un
utilisateur dépose ce qu'il a sous la main, et lui répondre « mauvais format »
serait une mauvaise réponse. Il affiche alors ce qu'on y perd.

Sans manifeste, l'indice reste calculable — c'est sa **provenance** qui manque,
et une note méthodologique ne peut pas s'en passer.


## Le dossier est la seule dépendance

Les deux notebooks **ne lisent et n'écrivent rien hors de ce dossier**. Vous
pouvez le déplacer, le renommer, le copier sur une clé : tant qu'il est entier,
ils marchent.

La difficulté est qu'un notebook n'a pas de `__file__`. La première cellule
cherche donc sa racine par quatre pistes, de la plus fiable à la plus large :

1. `DOSSIER_PROJET`, si vous l'avez renseigné ;
2. `JPY_SESSION_NAME`, que Jupyter 7 et JupyterLab 3+ donnent ;
3. le répertoire courant du noyau, en remontant ;
4. un dossier de projet juste en dessous du répertoire courant.

Un dossier n'est retenu que s'il est **complet** — `src/pipeline.py`,
`src/index.py` et `requirements.txt` présents. Puis la cellule s'y place, de
sorte que les sorties aussi restent dedans.

Si rien n'est trouvé, le notebook affiche la consigne et le répertoire courant,
et vous renseignez `DOSSIER_PROJET`. Vérifié en déplaçant **et** en renommant le
dossier : les deux notebooks le retrouvent et tournent.


## Deux dossiers, et ils ne se mélangent pas

| Dossier | Qui écrit | Qui nettoie |
|---|---|---|
| `sorties/` | **les notebooks** — vos collectes, vos rapports | **personne**, jamais automatiquement |
| `verification/` | `scripts/verifier_notebooks.py` | lui seul |

Cette séparation vient d'une faute. Le 14/10/2026, le harnais de vérification
écrivait dans `sorties/` — le même dossier que les notebooks — et le nettoyage
qui le suivait a effacé une collecte de **8 021 produits** qui avait demandé
quarante minutes. `rm -rf` ne passe pas par la corbeille.

Trois protections en découlent :

1. le harnais **refuse de démarrer** si la redirection d'écriture n'est pas en
   place — mieux vaut ne pas vérifier que détruire ce qu'on vérifie ;
2. il contrôle **après coup** qu'aucun fichier n'a été écrit dans `sorties/`, au
   lieu de faire confiance à sa configuration ;
3. les notebooks de collecte **horodatent à la minute** et **refuse d'écraser** une
   archive existante : deux collectes le même jour sont deux relevés, pas une
   erreur de manipulation.

## Notebook 1 — collecte Jumia

Sur le poste de l'institut, avec un environnement Python dédié.

- **Cellule 1** vérifie avant d'installer. Si elle ne trouve pas d'environnement
  dédié, elle affiche les deux commandes à lancer et s'arrête — un
  `pip install` dans l'interpréteur du système casse ce qui marchait.
- **Cellule 2** mesure le point de sortie et **interrompt** le notebook si c'est
  un centre de données. C'est la cellule qui évite le diagnostic d'hier soir.
- **Cellule 4** requalifie le tableau de disponibilité : un 403 reçu d'un centre
  de données devient « ❔ indéterminé d'ici », et non « ⚠️ restreint ».

`CONTACT_EMAIL` est obligatoire et vérifié : le `robots.txt` de Jumia autorise
la collecte **à condition** que le robot s'identifie et donne un contact.
`PROJECT_URL`, dans `src/config.py`, est encore un gabarit — il part dans le
User-Agent envoyé au site, et le notebook le signale.


## Notebook 2 — les autres sources

Ce que l'e-commerce ne peut pas voir, là où les institutions le publient déjà.
Côte d'Ivoire et Sénégal.

| Source | Division | Nature |
|---|---|---|
| **OCPV** InfoPrix | 01 | prix de détail sur les **marchés réels** |
| **Sikafinance** | 01 | 80 produits, 6 villes |
| **ANARE-CI** | **04** | tarifs d'électricité administrés |
| **CRSE** | **04** | grille tarifaire, Sénégal |
| **ARTP / IPSM** | **08** | indice base 100 — **7,46 % du panier sénégalais** |

L'ARTP ne publie pas des prix mais un **indice déjà construit**. Il sort donc
dans un CSV séparé : le verser dans le panel reviendrait à calculer un indice
d'indices.

Mesuré en conditions réelles le 14/10/2026, Côte d'Ivoire : **2 764 relevés** —
2 391 de l'OCPV sur 40 marchés, 292 de Sikafinance sur 6 villes, 81 de l'ANARE.
Le panier passe de 5 à 6 divisions sur 13, et la division 01 est désormais
atteinte par **deux circuits**.

Quatre divisions restent sans aucune source — **07** transports, **10**
enseignement, **11** restauration, **12** assurances. Le notebook l'affiche au
lieu de le taire.

## Notebook 3 — analyse

Sur Colab, pour des collègues qui n'installeront jamais Python. Aucune ligne de
code à écrire, aucune trace d'erreur affichée : chaque problème est dit en
français avec ce qu'il faut faire.

Il ne va **jamais** sur un site marchand. Il ne travaille que sur des fichiers.

Un jeu de démonstration est fourni, de sorte que le notebook tourne dès la
première ouverture même si personne n'a encore déposé de fichier. Il sort du
simulateur de `src/fixture.py` : les prix ne sont ceux d'aucun marché, mais
**l'inflation y est connue d'avance**, ce qui permet de vérifier que le calcul
retrouve la bonne réponse. Une démonstration vérifiable, pas une illustration.

## Vérifier

```bash
python scripts/generer_exemple.py      # régénère le jeu de démonstration
python scripts/verifier_notebooks.py   # exécute les carnets, sans toucher à Jumia
pytest -q                              # la suite de tests, aucun accès à Jumia
```

Les six carnets se modifient **directement** dans JupyterLab. Ils étaient à
l'origine écrits par un générateur ; celui-ci n'a pas suivi le passage à six
carnets bilingues et il est rangé dans `scripts/obsoletes/` avec son LISEZ-MOI.

`verifier_notebooks.py` joue les deux carnets d'analyse (FR et EN) **en entier**
sur le jeu d'exemple — le parcours exact d'un collègue qui les ouvre pour la
première fois — et les deux carnets de collecte Jumia jusqu'aux paramètres,
au-delà desquels ils interrogeraient le site. Il n'écrit que dans
`verification/`, qu'il vide à chaque départ.

Cette vérification a trouvé trois défauts que `pytest` ne pouvait pas voir : une
clé `RES["overall"]` qui n'existe pas, un `viz.table` passé au rapport là où
il attend un DataFrame, et un IPC officiel d'exemple entièrement vide parce que
`config.DEFAULT_WEIGHTS` n'existe pas.
