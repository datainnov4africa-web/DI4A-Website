# CPI_AfDB — de quoi exécuter les trois carnets

Ce dossier contient **le strict nécessaire pour faire tourner les trois
carnets**, rien de plus. Il a été produit par
`scripts/preparer_livraison.py` du dépôt `jumia-cpi`, et la copie a été
vérifiée : un interpréteur lancé dans ce dossier importe les dix-neuf modules
que les carnets appellent.

## Démarrer

Le dossier est livré **sans environnement Python** (`.venv`) : il se construit
sur place, une fois, en une commande. Le seul prérequis est **Python 3.10 ou
plus** (python.org ; 3.12 validé).

```bash
# 1. vérifier Python
python --version                 # Windows  (ou : py -0p)
python3 --version                # macOS, Linux

# 2. construire l'environnement, depuis ce dossier (~3 min, ~550 Mo)
.\preparer.bat                   # Windows
bash preparer.sh                 # macOS, Linux

# 3. lancer JupyterLab, toujours depuis ce dossier, avec le Jupyter du projet
.\.venv\Scripts\jupyter lab      # Windows
.venv/bin/jupyter lab            # macOS, Linux
```

Le script de l'étape 2 choisit l'interpréteur lui-même (il ignore un
environnement conda actif), crée `.venv`, installe les dépendances **et
JupyterLab**, vérifie que tout s'importe, et affiche la commande de l'étape 3.
Ne tapez pas `jupyter lab` tout court : cela lancerait un autre Jupyter de la
machine, sans les bibliothèques du projet. Lancé depuis un autre dossier,
JupyterLab ne montre pas `notebooks/` et ne peut pas y remonter.

Dans JupyterLab, ouvrir `notebooks/` et suivre l'ordre : 1, puis 2, puis 3,
avec le noyau « Python 3 (ipykernel) ». Le guide `Guide_Execution_FR.docx`,
à côté de ce fichier (`Execution_Guide_EN.docx` en anglais), détaille chaque
étape, avec ce qu'il faut voir à l'écran et ce qui peut mal tourner.

## Où exécuter quoi

**Seul le carnet 3 tourne dans Google Colab.** Sa première cellule installe ce
qu'il faut, et il se contente de lire les archives déjà présentes dans
`sorties/outputs/`.

**Les carnets 1 et 2 doivent tourner sur le poste de l'institut.** Ils
interrogent des sites web : lancés depuis Colab, le trafic part des adresses de
Google, l'éditeur voit une requête qui ne vient pas de vous, et votre
institution ne peut pas répondre de ce qu'elle n'a pas émis. Ce n'est pas que
théorique — le 13/10/2026, dix des quatorze sites Jumia testés depuis Colab ont
répondu par un refus. Les deux carnets détectent Colab et s'y arrêtent en
l'expliquant.

### Le carnet 3 dans Colab

Il faut que ce dossier soit accessible depuis la machine de Google. Le plus
simple, et le seul qui survive à la fermeture de la session :

1. copiez **tout le dossier `CPI_AfDB`** dans votre Google Drive, à la racine
   (`MyDrive/CPI_AfDB`) ou à un niveau en dessous ;
2. ouvrez `notebooks/3_analyse_FR.ipynb` depuis Drive, avec Colab ;
3. exécutez la cellule « Installer et charger le code ». Elle demandera
   l'autorisation d'accéder à votre Drive, puis y trouvera le dossier toute
   seule.

Cette autorisation est nécessaire : **ouvrir un carnet depuis Drive ne monte pas
Drive.** Colab va chercher le fichier du carnet, mais le reste de votre Drive
lui reste invisible tant qu'on ne l'a pas demandé. Le carnet s'en charge, et
seulement s'il n'a pas trouvé le code ailleurs.

### Si Drive refuse de se monter

Le carnet affiche alors « Drive n'a pas pu être monté » et nomme les deux
causes habituelles. La première est la plus fréquente : **plusieurs comptes
Google dans le même navigateur**. L'adresse du carnet contient alors
`authuser=1` ou davantage ; Colab demande l'autorisation à un compte et le
navigateur répond avec un autre. Ouvrez Colab dans une fenêtre de navigation
privée, connectée au seul compte qui porte le dossier. La seconde : la fenêtre
d'autorisation a été bloquée — autorisez les fenêtres surgissantes pour
`colab.research.google.com`.

**La voie qui marche toujours, sans aucune autorisation :** glisser le dossier
`CPI_AfDB` dans `/content/` par le volet Fichiers à gauche. C'est à refaire à
chaque session, et il faut compter quelques minutes pour les 57 Mo, mais rien
ne peut la bloquer.

Le dossier est reconnu à son contenu, pas à son nom : il lui faut
`src/pipeline.py`, `src/index.py` et `requirements.txt`.

**Une seule copie dans le Drive.** Colab ne dit pas au carnet depuis quel
dossier il a été ouvert. S'il trouve plusieurs copies complètes du projet, il
s'arrête en les listant et demande le chemin de la bonne dans `DOSSIER_PROJET`
(cellule 1) ; avant cette protection, il prenait la première par ordre
alphabétique, et une vieille copie tournait à la place de la nouvelle. Le plus
simple reste de supprimer les copies inutiles.

Avant de lancer les carnets 1 et 2, renseigner une adresse de contact : copier
`.env.example` en `.env` et y mettre la vôtre. Ce n'est pas une politesse du
projet mais une condition de certaines sources — HDX HAPI refuse une requête
anonyme.

## Ce qu'il y a dans le dossier

| | contenu |
|---|---|
| `notebooks/` | les six carnets, trois étapes en deux langues |
| `src/` | les 24 modules du dispositif, plus `assets/africa_110m.json` |
| `sorties/outputs/` | **47 archives**, pour que le carnet 3 ait quoi lire |
| `paniers/` | les paniers des huit pays et les pondérations officielles de trois |
| `data/exemple/` | le jeu de démonstration et le banc d'essai |
| `preparer.bat`, `preparer.ps1` | construisent l'environnement sous Windows |
| `preparer.sh` | la même chose sous Linux et macOS |
| `requirements.txt` | les dépendances |
| `.env.example` | le gabarit de configuration |
| `README.md` | le document du dépôt complet — voir la réserve plus bas |
| `Guide_Execution_FR.docx`, `Execution_Guide_EN.docx` | le guide pas à pas, de la vérification de Python au rapport d'indice |

Les archives couvrent les huit pays : CI 7, SN 8, KE 7, NG 6, EG 5, MA 5, UG 5,
GH 4. Elles permettent d'exécuter le carnet 3 **tout de suite**, sans attendre
les heures que demandent les carnets 1 et 2.

`paniers/` et `data/exemple/` ne sont pas facultatifs : la configuration par
défaut du carnet 3 les lit. `PONDERATIONS = "auto"` y cherche
`ponderations_<PAYS>.csv`, et `BANC_ESSAI = "exemple"` le jeu de contrôle.
`paniers/PONDERATIONS-a-coller.md` donne les trois chaînes de pondération si
vous préférez les saisir.

## Ce qui n'y est pas, et pourquoi

**Les classeurs Excel de `sorties/excel/`** — environ 44 Mo. Aucun carnet ne les
lit : ce sont une copie lisible des archives, utile à l'œil humain, inutile au
code. Le carnet 3 lit les archives, dont le parquet est typé ; une relecture
Excel transformerait la division « 01 » en entier 1.

**`scripts/`, `tests/`, `docs/`** — outils de campagne, suite de tests et
présentations. Rien de tout cela n'est importé par un carnet.

**`.venv/`** — l'environnement se construit sur place par `preparer.bat` ou
`preparer.sh` (environ 550 Mo, 3 min). Il ne se partage pas : ses lanceurs portent le
chemin absolu de la machine qui l'a créé. Si vous transmettez ce dossier à
votre tour, ne joignez pas `.venv`.

## Une réserve sur `README.md`

Le `README.md` à la racine est celui du dépôt complet. Il décrit des dossiers
absents d'ici : `scripts/`, `tests/`, `docs/`. Ses sections sur l'installation
et sur la méthode restent valables ; celles qui renvoient à ces dossiers ne
s'appliquent pas à cette livraison.

## Si le carnet 3 ne trouve rien

Il filtre les archives sur le pays choisi en première cellule. Un pays sans
archive affiche un message explicite plutôt que de calculer sur rien. Les noms
portent le pays : `panel_CI_…`, `officiel_SN_…`.
